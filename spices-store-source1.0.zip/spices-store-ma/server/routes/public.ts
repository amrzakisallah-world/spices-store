import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db.ts';
import { rateLimit } from '../security.ts';
import { WEIGHT_OPTIONS } from '../../src/shared/types.ts';

export const publicRouter = Router();

// 1. Public store config (non-sensitive only)
publicRouter.get('/config', (_req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM store_settings').all() as Array<{
    key: string;
    value: string;
  }>;
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  res.json({
    store_name_ar: map.store_name_ar || 'بهارات اصلي',
    store_name_en: map.store_name_en || 'Baharat Asli',
    whatsapp_number: map.whatsapp_number || '',
    store_phone: map.store_phone || '',
    store_address: map.store_address || 'القاهرة، مصر',
    default_delivery_fee_piasters: Number(map.default_delivery_fee_piasters || 4500),
    free_delivery_threshold_piasters: Number(map.free_delivery_threshold_piasters || 60000),
  });
});

// 2. Public categories
publicRouter.get('/categories', (_req, res) => {
  const db = getDb();
  const categories = db
    .prepare(
      `SELECT c.*,
        (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1) as product_count
       FROM categories c
       WHERE c.is_active = 1
       ORDER BY c.sort_order ASC, c.id ASC`
    )
    .all();
  res.json({ categories });
});

// 3. Public catalog (products with category & primary image; never exposes internal cost_price_piasters!)
publicRouter.get('/products', (req, res) => {
  const db = getDb();
  const q = String(req.query.q || '').trim();
  const categorySlug = String(req.query.category || '').trim();
  const featuredOnly = req.query.featured === '1';

  let sql = `
    SELECT
      p.id, p.sku, p.slug, p.name_ar, p.name_en, p.category_id,
      c.name_ar as category_name_ar, c.name_en as category_name_en, c.slug as category_slug,
      p.description_ar, p.description_en, p.unit_label_ar, p.base_weight_grams,
      p.selling_price_piasters, p.stock_units, p.low_stock_threshold,
      p.is_active, p.is_featured, p.is_new, p.created_at, p.updated_at,
      (SELECT image_url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.is_primary DESC, pi.sort_order ASC LIMIT 1) as primary_image
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE p.is_active = 1
  `;
  const params: Array<string | number> = [];

  if (categorySlug && categorySlug !== 'all') {
    sql += ' AND c.slug = ?';
    params.push(categorySlug);
  }
  if (featuredOnly) {
    sql += ' AND p.is_featured = 1';
  }
  if (q) {
    sql += ' AND (p.name_ar LIKE ? OR p.name_en LIKE ? OR p.description_ar LIKE ? OR p.sku LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }

  sql += ' ORDER BY p.is_featured DESC, p.is_new DESC, p.id ASC';

  const products = db.prepare(sql).all(...params);
  res.json({ products });
});

// 4. Single product detail
publicRouter.get('/products/:id', (req, res) => {
  const db = getDb();
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'معرف المنتج غير صالح' });
    return;
  }

  const product = db
    .prepare(
      `SELECT
        p.id, p.sku, p.slug, p.name_ar, p.name_en, p.category_id,
        c.name_ar as category_name_ar, c.name_en as category_name_en,
        p.description_ar, p.description_en, p.unit_label_ar, p.base_weight_grams,
        p.selling_price_piasters, p.stock_units, p.low_stock_threshold,
        p.is_active, p.is_featured, p.is_new
      FROM products p
      JOIN categories c ON c.id = p.category_id
      WHERE p.id = ? AND p.is_active = 1`
    )
    .get(id) as Record<string, unknown> | undefined;

  if (!product) {
    res.status(404).json({ error: 'المنتج غير موجود' });
    return;
  }

  const images = db
    .prepare(
      'SELECT id, product_id, image_url, alt_text, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC'
    )
    .all(id);

  res.json({ product: { ...product, images } });
});

// 5. Public order creation with server-side price & stock enforcement + rate limiting
const createOrderSchema = z.object({
  customer_name: z.string().trim().min(2, 'يرجى إدخال الاسم بالكامل').max(120),
  customer_phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s]{8,20}$/, 'يرجى إدخال رقم هاتف صحيح'),
  delivery_area: z.string().trim().min(2, 'يرجى تحديد المنطقة أو المحافظة').max(120),
  delivery_address: z.string().trim().min(5, 'يرجى كتابة عنوان التوصيل بالتفصيل').max(400),
  delivery_notes: z.string().trim().max(400).optional().default(''),
  payment_method: z.enum(['cod', 'instapay', 'vodafone_cash', 'bank_transfer']).default('cod'),
  items: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        weight_grams: z.number().int().refine((w) => [125, 250, 500, 1000].includes(w), {
          message: 'وزن غير صالح',
        }),
        quantity: z.number().int().min(1).max(50),
      })
    )
    .min(1, 'السلة فارغة')
    .max(40),
  // Honeypot field to block automated spam bots
  website_url: z.string().optional(),
});

const orderRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 8,
  keyPrefix: 'public_order',
});

publicRouter.post('/orders', orderRateLimit, (req, res) => {
  if (req.body?.website_url) {
    res.status(400).json({ error: 'طلب غير صالح' });
    return;
  }

  const parsed = createOrderSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: parsed.error.issues[0]?.message || 'بيانات الطلب غير مكتملة',
      issues: parsed.error.issues,
    });
    return;
  }

  const data = parsed.data;
  const db = getDb();

  // Read delivery policy from store_settings
  const settingRows = db
    .prepare("SELECT key, value FROM store_settings WHERE key IN ('default_delivery_fee_piasters', 'free_delivery_threshold_piasters')")
    .all() as Array<{ key: string; value: string }>;
  const settingsMap = Object.fromEntries(settingRows.map((r) => [r.key, Number(r.value)]));
  const defaultDeliveryFee = settingsMap.default_delivery_fee_piasters ?? 4500;
  const freeThreshold = settingsMap.free_delivery_threshold_piasters ?? 60000;

  try {
    const result = db.transaction(() => {
      let subtotalPiasters = 0;
      let totalCostPiasters = 0;

      const preparedItems: Array<{
        product_id: number;
        product_name_ar: string;
        variant_label_ar: string;
        weight_grams: number;
        quantity: number;
        unit_price_piasters: number;
        unit_cost_piasters: number;
        line_total_piasters: number;
        line_cost_piasters: number;
        deductUnits: number;
        stockAfter: number;
      }> = [];

      const getProd = db.prepare(
        'SELECT id, name_ar, selling_price_piasters, cost_price_piasters, stock_units, is_active FROM products WHERE id = ?'
      );

      for (const reqItem of data.items) {
        const prod = getProd.get(reqItem.product_id) as
          | {
              id: number;
              name_ar: string;
              selling_price_piasters: number;
              cost_price_piasters: number;
              stock_units: number;
              is_active: number;
            }
          | undefined;

        if (!prod || !prod.is_active) {
          throw new Error(`المنتج رقم ${reqItem.product_id} غير متاح حالياً`);
        }

        const weightMeta = WEIGHT_OPTIONS.find((w) => w.grams === reqItem.weight_grams)!;
        const deductUnits = weightMeta.multiplier * reqItem.quantity;

        if (prod.stock_units < deductUnits) {
          throw new Error(
            `الكمية المطلوبة من "${prod.name_ar}" غير متوفرة حالياً في المخزون (المتاح ${prod.stock_units * 125} جم).`
          );
        }

        // Price and cost always computed server-side from DB!
        const unitPrice = prod.selling_price_piasters * weightMeta.multiplier;
        const unitCost = prod.cost_price_piasters * weightMeta.multiplier;
        const lineTotal = unitPrice * reqItem.quantity;
        const lineCost = unitCost * reqItem.quantity;

        subtotalPiasters += lineTotal;
        totalCostPiasters += lineCost;

        const stockAfter = prod.stock_units - deductUnits;
        db.prepare("UPDATE products SET stock_units = ?, updated_at = datetime('now') WHERE id = ?").run(
          stockAfter,
          prod.id
        );

        preparedItems.push({
          product_id: prod.id,
          product_name_ar: prod.name_ar,
          variant_label_ar: weightMeta.labelAr,
          weight_grams: reqItem.weight_grams,
          quantity: reqItem.quantity,
          unit_price_piasters: unitPrice,
          unit_cost_piasters: unitCost,
          line_total_piasters: lineTotal,
          line_cost_piasters: lineCost,
          deductUnits,
          stockAfter,
        });
      }

      const deliveryFee = subtotalPiasters >= freeThreshold ? 0 : defaultDeliveryFee;
      const totalPiasters = subtotalPiasters + deliveryFee;

      // Upsert customer
      const cleanPhone = data.customer_phone.replace(/\s+/g, '');
      const existingCust = db.prepare('SELECT id FROM customers WHERE phone = ?').get(cleanPhone) as
        | { id: number }
        | undefined;
      let customerId: number;
      if (existingCust) {
        customerId = existingCust.id;
        db.prepare(
          "UPDATE customers SET name = ?, area = ?, street_address = ?, updated_at = datetime('now') WHERE id = ?"
        ).run(data.customer_name, data.delivery_area, data.delivery_address, customerId);
      } else {
        const custRes = db
          .prepare('INSERT INTO customers (name, phone, area, street_address) VALUES (?, ?, ?, ?)')
          .run(data.customer_name, cleanPhone, data.delivery_area, data.delivery_address);
        customerId = Number(custRes.lastInsertRowid);
      }

      // Sequential order number + random tracking code
      const lastOrder = db.prepare('SELECT COALESCE(MAX(id), 0) as maxId FROM orders').get() as {
        maxId: number;
      };
      const seqNum = 1001 + lastOrder.maxId;
      const orderNumber = `OY-${seqNum}`;
      const randomPin = Math.floor(1000 + Math.random() * 9000);
      const trackingCode = `TRK-${seqNum}-${randomPin}`;

      const ordRes = db
        .prepare(
          `INSERT INTO orders (
            order_number, tracking_code, customer_id, customer_name, customer_phone,
            delivery_address, delivery_area, delivery_notes, status, payment_method, payment_status,
            subtotal_piasters, delivery_fee_piasters, delivery_actual_cost_piasters, discount_piasters,
            total_piasters, total_cost_piasters, paid_piasters, is_demo
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, 'unpaid', ?, ?, 0, 0, ?, ?, 0, 0)`
        )
        .run(
          orderNumber,
          trackingCode,
          customerId,
          data.customer_name,
          cleanPhone,
          data.delivery_address,
          data.delivery_area,
          data.delivery_notes,
          data.payment_method,
          subtotalPiasters,
          deliveryFee,
          totalPiasters,
          totalCostPiasters
        );

      const orderId = Number(ordRes.lastInsertRowid);

      const insertItem = db.prepare(`
        INSERT INTO order_items (
          order_id, product_id, product_name_ar, variant_label_ar, weight_grams,
          quantity, unit_price_piasters, unit_cost_piasters, line_total_piasters, line_cost_piasters
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertMov = db.prepare(`
        INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, reference_id, note)
        VALUES (?, 'sale', ?, ?, 'order', ?, ?)
      `);

      for (const pi of preparedItems) {
        insertItem.run(
          orderId,
          pi.product_id,
          pi.product_name_ar,
          pi.variant_label_ar,
          pi.weight_grams,
          pi.quantity,
          pi.unit_price_piasters,
          pi.unit_cost_piasters,
          pi.line_total_piasters,
          pi.line_cost_piasters
        );
        insertMov.run(
          pi.product_id,
          -pi.deductUnits,
          pi.stockAfter,
          orderId,
          `خصم بيع طلب ${orderNumber}`
        );
      }

      return {
        order_number: orderNumber,
        tracking_code: trackingCode,
        status: 'pending',
        subtotal_piasters: subtotalPiasters,
        delivery_fee_piasters: deliveryFee,
        total_piasters: totalPiasters,
        payment_method: data.payment_method,
      };
    })();

    res.status(201).json({ order: result });
  } catch (err) {
    res.status(400).json({
      error: err instanceof Error ? err.message : 'تعذر إتمام الطلب، يرجى المحاولة مرة أخرى',
    });
  }
});

// 6. Public Order Tracking Lookup (protected: requires order number/tracking code + phone last 4 or full phone so customer data isn't scraped)
publicRouter.get('/orders/track', (req, res) => {
  const code = String(req.query.code || '').trim().toUpperCase();
  const phone = String(req.query.phone || '').trim().replace(/\s+/g, '');

  if (!code || !phone) {
    res.status(400).json({ error: 'يرجى إدخال رقم الطلب ورقم الهاتف المستخدم في الطلب.' });
    return;
  }

  const db = getDb();
  const order = db
    .prepare(
      `SELECT id, order_number, tracking_code, customer_name, customer_phone,
              delivery_area, status, payment_method, payment_status,
              subtotal_piasters, delivery_fee_piasters, discount_piasters, total_piasters, paid_piasters,
              created_at, updated_at
       FROM orders
       WHERE (UPPER(order_number) = ? OR UPPER(tracking_code) = ?)`
    )
    .get(code, code) as
    | {
        id: number;
        order_number: string;
        tracking_code: string;
        customer_name: string;
        customer_phone: string;
        delivery_area: string;
        status: string;
        payment_method: string;
        payment_status: string;
        subtotal_piasters: number;
        delivery_fee_piasters: number;
        discount_piasters: number;
        total_piasters: number;
        paid_piasters: number;
        created_at: string;
        updated_at: string;
      }
    | undefined;

  if (!order) {
    res.status(404).json({ error: 'لم يتم العثور على طلب بهذا الرقم.' });
    return;
  }

  // Verify phone matches (full match or last 4 digits match for customer convenience while preventing open enumeration)
  const phoneMatches =
    order.customer_phone === phone ||
    (phone.length >= 4 && order.customer_phone.endsWith(phone.slice(-4)) && phone.length >= 8);

  if (!phoneMatches) {
    res.status(403).json({ error: 'رقم الهاتف غير مطابق لبيانات الطلب.' });
    return;
  }

  const items = db
    .prepare(
      `SELECT product_name_ar, variant_label_ar, weight_grams, quantity, unit_price_piasters, line_total_piasters
       FROM order_items WHERE order_id = ?`
    )
    .all(order.id);

  // Mask full phone for privacy on public lookup
  const maskedPhone =
    order.customer_phone.length > 4
      ? `${'*'.repeat(order.customer_phone.length - 4)}${order.customer_phone.slice(-4)}`
      : order.customer_phone;

  res.json({
    order: {
      ...order,
      customer_phone: maskedPhone,
      items,
    },
  });
});
