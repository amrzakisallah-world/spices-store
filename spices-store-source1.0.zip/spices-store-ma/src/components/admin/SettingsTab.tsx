import { useEffect, useState } from 'react';
import { Trash2, ShieldCheck, Save } from 'lucide-react';
import { api } from '../../lib/api';
import { fromPiasters, toPiasters } from '../../shared/types';

interface SettingsTabProps {
  onRefreshDashboard: () => void;
}

export function SettingsTab({ onRefreshDashboard }: SettingsTabProps) {
  const [storeNameAr, setStoreNameAr] = useState('بهارات اصلي');
  const [storeNameEn, setStoreNameEn] = useState('Baharat Asli');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [storePhone, setStorePhone] = useState('');
  const [storeAddress, setStoreAddress] = useState('');
  const [deliveryFeeEgp, setDeliveryFeeEgp] = useState('45');
  const [freeThresholdEgp, setFreeThresholdEgp] = useState('600');
  const [demoCounts, setDemoCounts] = useState({ orders: 0, expenses: 0, purchases: 0 });
  const [feedback, setFeedback] = useState('');

  // Password change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const loadSettings = async () => {
    const res = await api.getSettings();
    const s = res.settings;
    setStoreNameAr(s.store_name_ar || 'بهارات اصلي');
    setStoreNameEn(s.store_name_en || 'Baharat Asli');
    setWhatsappNumber(s.whatsapp_number || '');
    setStorePhone(s.store_phone || '');
    setStoreAddress(s.store_address || '');
    setDeliveryFeeEgp(String(fromPiasters(Number(s.default_delivery_fee_piasters || 4500))));
    setFreeThresholdEgp(String(fromPiasters(Number(s.free_delivery_threshold_piasters || 60000))));
    setDemoCounts(res.demoCounts);
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback('');
    await api.updateSettings({
      store_name_ar: storeNameAr,
      store_name_en: storeNameEn,
      whatsapp_number: whatsappNumber,
      store_phone: storePhone,
      store_address: storeAddress,
      default_delivery_fee_piasters: toPiasters(Number(deliveryFeeEgp)),
      free_delivery_threshold_piasters: toPiasters(Number(freeThresholdEgp)),
    });
    setFeedback('تم حفظ إعدادات المتجر والتوصيل والواتساب بنجاح.');
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback('');
    try {
      await api.changePassword(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setFeedback('تم تحديث كلمة مرور الإدارة بنجاح.');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر تحديث كلمة المرور');
    }
  };

  const handleClearDemo = async () => {
    await api.clearDemoData();
    setFeedback('تم حذف جميع الطلبات والمصروفات التجريبية والاحتفاظ بجميع المنتجات والموردين.');
    await loadSettings();
    onRefreshDashboard();
  };

  const hasDemo = demoCounts.orders + demoCounts.expenses + demoCounts.purchases > 0;

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-xl font-extrabold text-slate-900">إعدادات المتجر والأمان</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          تخصيص بيانات التواصل، رقم الواتساب، سياسة التوصيل، وكلمة مرور لوحة الإدارة.
        </p>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-slate-900 text-white text-xs font-semibold">
          {feedback}
        </div>
      )}

      <form
        onSubmit={handleSaveSettings}
        className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 text-xs"
      >
        <h3 className="text-sm font-bold text-slate-900">إعدادات المتجر والتوصيل والواتساب</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-bold text-slate-700 mb-1">اسم المتجر (عربي)</label>
            <input
              type="text"
              required
              value={storeNameAr}
              onChange={(e) => setStoreNameAr(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">اسم المتجر (إنجليزي)</label>
            <input
              type="text"
              dir="ltr"
              required
              value={storeNameEn}
              onChange={(e) => setStoreNameEn(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              رقم الواتساب (صيغة دولية بدون +، مثال: 201001234567)
            </label>
            <input
              type="text"
              dir="ltr"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              placeholder="201001234567"
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">رقم هاتف المتجر</label>
            <input
              type="text"
              dir="ltr"
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">رسوم التوصيل الافتراضية (ج.م)</label>
            <input
              type="number"
              min="0"
              required
              value={deliveryFeeEgp}
              onChange={(e) => setDeliveryFeeEgp(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">حد التوصيل المجاني (ج.م)</label>
            <input
              type="number"
              min="0"
              required
              value={freeThresholdEgp}
              onChange={(e) => setFreeThresholdEgp(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>
        </div>
        <div>
          <label className="block font-bold text-slate-700 mb-1">عنوان المتجر</label>
          <input
            type="text"
            value={storeAddress}
            onChange={(e) => setStoreAddress(e.target.value)}
            className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
          />
        </div>
        <button
          type="submit"
          className="min-h-[40px] px-5 py-2 rounded-lg bg-[#4E3119] text-white font-bold inline-flex items-center gap-1.5"
        >
          <Save className="w-4 h-4" />
          <span>حفظ الإعدادات</span>
        </button>
      </form>

      {/* Change Admin Password */}
      <form
        onSubmit={handleChangePassword}
        className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
      >
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-700" />
          <span>تغيير كلمة مرور لوحة الإدارة</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-bold text-slate-700 mb-1">كلمة المرور الحالية</label>
            <input
              type="password"
              required
              dir="ltr"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">كلمة المرور الجديدة (8 أحرف فأكثر)</label>
            <input
              type="password"
              required
              minLength={8}
              dir="ltr"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
            />
          </div>
        </div>
        <button
          type="submit"
          className="min-h-[40px] px-5 py-2 rounded-lg bg-slate-900 text-white font-bold"
        >
          تحديث كلمة المرور
        </button>
      </form>

      {/* Clear Demo Transactions */}
      {hasDemo && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div>
            <div className="font-bold text-amber-950 text-sm">تصفير البيانات التجريبية الافتتاحية</div>
            <p className="text-amber-900 mt-1">
              يوجد حالياً {demoCounts.orders} طلبات تجريبية و {demoCounts.expenses} مصروفات تجريبية. عند بدء التشغيل الفعلي يمكنك مسحها مع الإبقاء على كل المنتجات (37 صنف) والموردين.
            </p>
          </div>
          <button
            type="button"
            onClick={handleClearDemo}
            className="min-h-[40px] px-4 py-2 rounded-lg bg-red-700 hover:bg-red-800 text-white font-bold inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <Trash2 className="w-4 h-4" />
            <span>حذف البيانات التجريبية</span>
          </button>
        </div>
      )}
    </div>
  );
}
