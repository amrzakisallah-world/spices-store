import { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Wallet,
  Truck,
  Settings,
  LogOut,
  Store,
  Menu,
  X,
} from 'lucide-react';
import { api } from '../../lib/api';
import type { Category, DashboardSummary, OrderRecord, Product } from '../../shared/types';
import { OverviewTab } from './OverviewTab';
import { ProductsTab } from './ProductsTab';
import { OrdersTab } from './OrdersTab';
import { FinanceTab } from './FinanceTab';
import { SuppliersTab } from './SuppliersTab';
import { SettingsTab } from './SettingsTab';

interface AdminDashboardProps {
  user: { id: number; name: string; email: string; role: string };
  onLogout: () => void;
  onBackToStore: () => void;
}

type AdminTab = 'overview' | 'products' | 'orders' | 'finance' | 'suppliers' | 'settings';

const NAV_ITEMS: Array<{ id: AdminTab; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'overview', label: 'نظرة عامة والأرباح', icon: LayoutDashboard },
  { id: 'products', label: 'المنتجات والمخزون', icon: Package },
  { id: 'orders', label: 'الطلبات والمدفوعات', icon: ShoppingCart },
  { id: 'finance', label: 'المصروفات والتقارير', icon: Wallet },
  { id: 'suppliers', label: 'الموردين وأسعار الحراز', icon: Truck },
  { id: 'settings', label: 'إعدادات المتجر', icon: Settings },
];

export function AdminDashboard({ user, onLogout, onBackToStore }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [dashboard, setDashboard] = useState<DashboardSummary | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadAll = async () => {
    setLoading(true);
    setError('');
    try {
      const [dashRes, prodRes, catRes, ordRes] = await Promise.all([
        api.getDashboard(),
        api.getAdminProducts(),
        api.getAdminCategories(),
        api.getAdminOrders(),
      ]);
      setDashboard(dashRes);
      setProducts(prodRes.products);
      setCategories(catRes.categories);
      setOrders(ordRes.orders);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل بيانات لوحة التحكم');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleLogout = async () => {
    await api.logout();
    onLogout();
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b border-slate-200 px-4 h-14 flex items-center justify-between sticky top-0 z-30">
        <button
          type="button"
          onClick={() => setSidebarOpen(true)}
          className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg border border-slate-200"
          aria-label="فتح القائمة"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="font-bold text-sm text-[#4E3119]">إدارة بهارات اصلي</div>
        <button
          type="button"
          onClick={onBackToStore}
          className="text-xs font-bold text-[#4E3119] underline"
        >
          المتجر
        </button>
      </header>

      {/* Sidebar (260px desktop, drawer mobile) */}
      <aside
        className={`fixed lg:static inset-y-0 start-0 z-40 w-64 bg-white border-e border-slate-200 flex flex-col justify-between transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div>
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-9 h-9 rounded-lg overflow-hidden border border-slate-200 shrink-0 bg-[#4E3119]">
                <img
                  src="/assets/aistudio/1794952224250_777ef78c.jpg"
                  alt="بهارات اصلي"
                  className="w-full h-full object-cover scale-[1.35]"
                />
              </span>
              <div>
                <div className="text-sm font-extrabold text-[#4E3119]">بهارات اصلي</div>
                <div className="text-[11px] text-slate-500">نظام إدارة المتجر</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1.5 text-slate-500"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="p-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full min-h-[42px] px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 transition-colors ${
                    active
                      ? 'bg-[#4E3119] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-3 border-t border-slate-200 space-y-2 text-xs">
          <div className="px-2 py-1">
            <div className="font-bold text-slate-900">{user.name}</div>
            <div className="text-[11px] text-slate-500 truncate">{user.email}</div>
          </div>
          <button
            type="button"
            onClick={onBackToStore}
            className="w-full min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold flex items-center gap-2"
          >
            <Store className="w-4 h-4" />
            <span>عرض واجهة المتجر</span>
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full min-h-[38px] px-3 py-1.5 rounded-lg text-red-700 hover:bg-red-50 font-bold flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Backdrop for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
        {loading && !dashboard ? (
          <div className="py-20 text-center text-sm text-slate-500">
            جاري تحميل البيانات المالية والتشغيلية...
          </div>
        ) : error ? (
          <div className="p-5 bg-red-50 border border-red-200 rounded-xl text-sm text-red-800">
            {error}
          </div>
        ) : (
          <>
            {activeTab === 'overview' && dashboard && (
              <OverviewTab
                data={dashboard}
                onNavigateTab={(t) => setActiveTab(t as AdminTab)}
              />
            )}
            {activeTab === 'products' && (
              <ProductsTab
                products={products}
                categories={categories}
                onRefresh={loadAll}
              />
            )}
            {activeTab === 'orders' && (
              <OrdersTab orders={orders} onRefresh={loadAll} />
            )}
            {activeTab === 'finance' && (
              <FinanceTab onDashboardNeedsRefresh={loadAll} />
            )}
            {activeTab === 'suppliers' && (
              <SuppliersTab products={products} onRefreshProducts={loadAll} />
            )}
            {activeTab === 'settings' && (
              <SettingsTab onRefreshDashboard={loadAll} />
            )}
          </>
        )}
      </main>
    </div>
  );
}
