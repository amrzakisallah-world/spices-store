import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import { getDb } from './db.ts';

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: 'owner' | 'manager' | 'staff';
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export const SESSION_COOKIE_NAME = 'oy_admin_session';
const SESSION_TTL_DAYS = 14;

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derivedBuffer = crypto.scryptSync(password, salt, 64);
  const keyBuffer = Buffer.from(keyHex, 'hex');
  if (derivedBuffer.length !== keyBuffer.length) return false;
  return crypto.timingSafeEqual(derivedBuffer, keyBuffer);
}

function hashToken(token: string): string {
  const secret = process.env.SESSION_SECRET || 'oy-spices-dev-fallback-secret';
  return crypto.createHmac('sha256', secret).update(token).digest('hex');
}

export function createSession(userId: number): { rawToken: string; expiresAt: string } {
  const db = getDb();
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashToken(rawToken);
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000).toISOString();

  // Clean expired sessions opportunistically
  db.prepare("DELETE FROM sessions WHERE expires_at < datetime('now')").run();
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').run(
    tokenHash,
    userId,
    expiresAt
  );

  return { rawToken, expiresAt };
}

export function revokeSession(rawToken: string | undefined): void {
  if (!rawToken) return;
  const db = getDb();
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hashToken(rawToken));
}

export function getUserFromRequest(req: Request): AuthUser | null {
  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME];
  const authHeader = req.headers.authorization;
  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined;
  const rawToken = cookieToken || bearerToken;
  if (!rawToken) return null;

  const db = getDb();
  const row = db
    .prepare(
      `
      SELECT u.id, u.name, u.email, u.role, u.is_active, s.expires_at
      FROM sessions s
      JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ?
    `
    )
    .get(hashToken(rawToken)) as
    | {
        id: number;
        name: string;
        email: string;
        role: 'owner' | 'manager' | 'staff';
        is_active: number;
        expires_at: string;
      }
    | undefined;

  if (!row || !row.is_active) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hashToken(rawToken));
    return null;
  }

  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
  };
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const user = getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ error: 'غير مصرح بالدخول. يرجى تسجيل الدخول أولاً.' });
    return;
  }
  req.user = user;
  next();
}

export function requireAdminRole(req: Request, res: Response, next: NextFunction): void {
  if (!req.user || !['owner', 'manager', 'staff'].includes(req.user.role)) {
    res.status(403).json({ error: 'ليس لديك صلاحية تنفيذ هذا الإجراء.' });
    return;
  }
  next();
}

// Sliding-window rate limiter for abuse protection on public order and login routes
const rateBuckets = new Map<string, number[]>();

export function rateLimit(options: { windowMs: number; max: number; keyPrefix: string }) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const ip =
      (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
      req.socket.remoteAddress ||
      'unknown';
    const key = `${options.keyPrefix}:${ip}`;
    const now = Date.now();
    const cutoff = now - options.windowMs;
    const recent = (rateBuckets.get(key) || []).filter((ts) => ts > cutoff);

    if (recent.length >= options.max) {
      res.status(429).json({
        error: 'تم إرسال طلبات كثيرة خلال وقت قصير. يرجى الانتظار دقيقة والمحاولة مرة أخرى.',
      });
      return;
    }

    recent.push(now);
    rateBuckets.set(key, recent);
    next();
  };
}
