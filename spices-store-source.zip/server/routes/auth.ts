import { Router } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { getDb } from '../db.ts';
import {
  createSession,
  hashPassword,
  rateLimit,
  requireAuth,
  revokeSession,
  SESSION_COOKIE_NAME,
  verifyPassword,
} from '../security.ts';

export const authRouter = Router();

const loginRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  keyPrefix: 'admin_login',
});

const resetRateLimit = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  keyPrefix: 'admin_reset',
});

const loginSchema = z.object({
  email: z.string().trim().email('يرجى إدخال بريد إلكتروني صحيح'),
  password: z.string().min(4, 'يرجى إدخال كلمة المرور'),
});

authRouter.post('/login', loginRateLimit, (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'بيانات الدخول غير صالحة' });
    return;
  }

  const email = parsed.data.email.toLowerCase();
  const db = getDb();
  const user = db
    .prepare('SELECT id, name, email, password_hash, role, is_active FROM users WHERE LOWER(email) = ?')
    .get(email) as
    | {
        id: number;
        name: string;
        email: string;
        password_hash: string;
        role: 'owner' | 'manager' | 'staff';
        is_active: number;
      }
    | undefined;

  if (!user || !user.is_active || !verifyPassword(parsed.data.password, user.password_hash)) {
    res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    return;
  }

  const { rawToken, expiresAt } = createSession(user.id);
  const isProd = process.env.NODE_ENV === 'production';

  res.cookie(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProd,
    expires: new Date(expiresAt),
    path: '/',
  });

  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    },
  });
});

authRouter.post('/logout', (req, res) => {
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  revokeSession(token);
  res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
  res.json({ ok: true });
});

authRouter.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

const changePasswordSchema = z.object({
  current_password: z.string().min(1),
  new_password: z.string().min(8, 'كلمة المرور الجديدة يجب أن لا تقل عن 8 أحرف'),
});

authRouter.post('/change-password', requireAuth, (req, res) => {
  const parsed = changePasswordSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'بيانات غير صالحة' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id, password_hash FROM users WHERE id = ?').get(req.user!.id) as
    | { id: number; password_hash: string }
    | undefined;

  if (!user || !verifyPassword(parsed.data.current_password, user.password_hash)) {
    res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });
    return;
  }

  db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(
    hashPassword(parsed.data.new_password),
    user.id
  );

  res.json({ ok: true });
});

const resetWithKeySchema = z.object({
  email: z.string().trim().email('يرجى إدخال بريد الإدارة الصحيح'),
  recovery_key: z.string().trim().min(6, 'يرجى إدخال مفتاح الاسترداد'),
  new_password: z.string().min(8, 'كلمة المرور الجديدة يجب أن لا تقل عن 8 أحرف'),
});

authRouter.post('/reset-with-key', resetRateLimit, (req, res) => {
  const configuredKey = (process.env.ADMIN_RESET_KEY || '').trim();
  if (!configuredKey) {
    res.status(400).json({
      error:
        'ميزة الاسترداد من المتصفح تتطلب ضبط المتغير ADMIN_RESET_KEY في إعدادات البيئة (.env) أو استخدام الأمر npm run reset-admin على الخادم.',
    });
    return;
  }

  const parsed = resetWithKeySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'بيانات غير صالحة' });
    return;
  }

  const a = Buffer.from(parsed.data.recovery_key);
  const b = Buffer.from(configuredKey);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    res.status(403).json({ error: 'مفتاح الاسترداد غير صحيح' });
    return;
  }

  const db = getDb();
  const user = db
    .prepare('SELECT id FROM users WHERE LOWER(email) = ?')
    .get(parsed.data.email.toLowerCase()) as { id: number } | undefined;

  if (!user) {
    res.status(404).json({ error: 'لا يوجد حساب إدارة بهذا البريد الإلكتروني' });
    return;
  }

  db.transaction(() => {
    db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(
      hashPassword(parsed.data.new_password),
      user.id
    );
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
  })();

  res.json({ ok: true });
});
