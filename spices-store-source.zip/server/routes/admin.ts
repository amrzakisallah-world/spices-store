import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { z } from 'zod';
import { getDb } from '../db.ts';
import { requireAdminRole, requireAuth } from '../security.ts';
import type { DashboardSummary, PeriodMetrics } from '../../src/shared/types.ts';

export const adminRouter = Router();

adminRouter.use(requireAuth, requireAdminRole);

// Helper: compute metrics for a SQL date window
function computePeriodMetrics(
  db: ReturnType<typeof getDb>,
  orderWhereSql: string,
  expenseWhereSql: string,
  finWhereSql: string
): PeriodMetrics {
  const orderStats = db
    .prepare(
      `SELECT
        COUNT(*) as ordersCount,
        SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as completedOrdersCount,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelledOrdersCount,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_piasters - discount_piasters) ELSE 0 END), 0) as revenuePiasters,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_cost_piasters + delivery_actual_cost_piasters) ELSE 0 END), 0) as cogsPiasters
       FROM orders
       WHERE ${orderWhereSql}`
    )
    .get() as {
    ordersCount: number;
    completedOrdersCount: number;
    cancelledOrdersCount: number;
    revenuePiasters: number;
    cogsPiasters: number;
  };

  // Operating expenses exclude 'inventory_purchase' so inventory cost isn't double-counted with COGS
  const expStats = db
    .prepare(
      `SELECT COALESCE(SUM(amount_piasters), 0) as operatingExpensesPiasters
       FROM expenses
       WHERE category != 'inventory_purchase' AND ${expenseWhereSql}`
    )
    .get() as { operatingExpensesPiasters: number };

  const cashStats = db
    .prepare(
      `SELECT COALESCE(SUM(amount_piasters), 0) as cashCollectedPiasters
       FROM financial_records
       WHERE record_type = 'inflow' AND ${finWhereSql}`
    )
    .get() as { cashCollectedPiasters: number };

  const revenuePiasters = Number(orderStats.revenuePiasters || 0);
  const cogsPiasters = Number(orderStats.cogsPiasters || 0);
  const grossProfitPiasters = revenuePiasters - cogsPiasters;
  const operatingExpensesPiasters = Number(expStats.operatingExpensesPiasters || 0);
  const netProfitPiasters = grossProfitPiasters - operatingExpensesPiasters;

  return {
    ordersCount: Number(orderStats.ordersCount || 0),
    completedOrdersCount: Number(orderStats.completedOrdersCount || 0),
    cancelledOrdersCount: Number(orderStats.cancelledOrdersCount || 0),
    revenuePiasters,
    cogsPiasters,
    grossProfitPiasters,
    operatingExpensesPiasters,
    netProfitPiasters,
    cashCollectedPiasters: Number(cashStats.cashCollectedPiasters || 0),
  };
}

// 1. Dashboard Overview
adminRouter.get('/dashboard', (_req, res) => {
  const db = getDb();

  const today = computePeriodMetrics(
    db,
    "date(created_at) = date('now')",
    "date(expense_date) = date('now')",
    "date(record_date) = date('now')"
  );
  const week = computePeriodMetrics(
    db,
    "date(created_at) >= date('now', '-6 days')",
    "date(expense_date) >= date('now', '-6 days')",
    "date(record_date) >= date('now', '-6 days')"
  );
  const month = computePeriodMetrics(
    db,
    "strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')",
    "strftime('%Y-%m', expense_date) = strftime('%Y-%m', 'now')",
    "strftime('%Y-%m', record_date) = strftime('%Y-%m', 'now')"
  );
  const prevMonth = computePeriodMetrics(
    db,
    "strftime('%Y-%m', created_at) = strftime('%Y-%m', date('now', 'start of month', '-1 day'))",
    "strftime('%Y-%m', expense_date) = strftime('%Y-%m', date('now', 'start of month', '-1 day'))",
    "strftime('%Y-%m', record_date) = strftime('%Y-%m', date('now', 'start of month', '-1 day'))"
  );
  const year = computePeriodMetrics(
    db,
    "strftime('%Y', created_at) = strftime('%Y', 'now')",
    "strftime('%Y', expense_date) = strftime('%Y', 'now')",
    "strftime('%Y', record_date) = strftime('%Y', 'now')"
  );
  const all_time = computePeriodMetrics(db, '1=1', '1=1', '1=1');

  const pctChange = (cur: number, prev: number): number | null => {
    if (prev === 0) return cur > 0 ? 100 : null;
    return Math.round(((cur - prev) / Math.abs(prev)) * 1000) / 10;
  };

  const receivables = db
    .prepare(
      `SELECT COALESCE(SUM(MAX(0, total_piasters - paid_piasters)), 0) as amt
       FROM orders
       WHERE status != 'cancelled' AND payment_status != 'paid'`
    )
    .get() as { amt: number };

  const payables = db
    .prepare(
      `SELECT COALESCE(SUM(MAX(0, total_piasters - paid_piasters)), 0) as amt
       FROM supplier_purchases
       WHERE status != 'paid'`
    )
    .get() as { amt: number };

  const cashBalanceRow = db
    .prepare(
      `SELECT
        COALESCE(SUM(CASE WHEN record_type = 'inflow' THEN amount_piasters ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN record_type = 'outflow' THEN amount_piasters ELSE 0 END), 0) as bal
       FROM financial_records`
    )
    .get() as { bal: number };

  const invValuation = db
    .prepare(
      `SELECT
        COALESCE(SUM(MAX(0, stock_units) * cost_price_piasters), 0) as costVal,
        COALESCE(SUM(MAX(0, stock_units) * selling_price_piasters), 0) as retailVal
       FROM products WHERE is_active = 1`
    )
    .get() as { costVal: number; retailVal: number };

  const lowStockProducts = db
    .prepare(
      `SELECT p.*, c.name_ar as category_name_ar, c.name_en as category_name_en
       FROM products p
       JOIN categories c ON c.id = p.category_id
       WHERE p.is_active = 1 AND p.stock_units <= p.low_stock_threshold
       ORDER BY p.stock_units ASC
       LIMIT 10`
    )
    .all();

  const recentOrders = db
    .prepare('SELECT * FROM orders ORDER BY created_at DESC, id DESC LIMIT 6')
    .all();

  // Last 14 days daily series
  const dailySeries: DashboardSummary['dailySeries'] = [];
  for (let i = 13; i >= 0; i--) {
    const dayRow = db.prepare("SELECT date('now', ?) as d").get(`-${i} days`) as { d: string };
    const ordD = db
      .prepare(
        `SELECT COUNT(*) as cnt,
          COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_piasters - discount_piasters) ELSE 0 END), 0) as rev,
          COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_cost_piasters + delivery_actual_cost_piasters) ELSE 0 END), 0) as cost
         FROM orders WHERE date(created_at) = ?`
      )
      .get(dayRow.d) as { cnt: number; rev: number; cost: number };
    const expD = db
      .prepare(
        `SELECT COALESCE(SUM(amount_piasters), 0) as exp
         FROM expenses WHERE category != 'inventory_purchase' AND date(expense_date) = ?`
      )
      .get(dayRow.d) as { exp: number };
    dailySeries.push({
      date: dayRow.d,
      revenuePiasters: Number(ordD.rev || 0),
      costPiasters: Number(ordD.cost || 0),
      expensesPiasters: Number(expD.exp || 0),
      netProfitPiasters: Number(ordD.rev || 0) - Number(ordD.cost || 0) - Number(expD.exp || 0),
      ordersCount: Number(ordD.cnt || 0),
    });
  }

  // Actionable business alerts
  const alerts: DashboardSummary['alerts'] = [];
  const pendingCount = (
    db.prepare("SELECT COUNT(*) as c FROM orders WHERE status = 'pending'").get() as { c: number }
  ).c;
  if (pendingCount > 0) {
    alerts.push({
      level: 'warning',
      titleAr: `${pendingCount} طلبات جديدة بانتظار التأكيد`,
      detailAr: 'يرجى مراجعة الطلبات الجديدة وتأكيدها وتوجيهها للتجهيز.',
      actionTab: 'orders',
    });
  }
  if (lowStockProducts.length > 0) {
    alerts.push({
      level: 'danger',
      titleAr: `${lowStockProducts.length} أصناف وصلت للحد الأدنى للمخزون`,
      detailAr: 'تحتاج إلى إعادة طلب شراء من الموردين أو الحراز.',
      actionTab: 'products',
    });
  }
  if (Number(payables.amt || 0) > 0) {
    alerts.push({
      level: 'info',
      titleAr: 'مستحقات مفتوحة للموردين',
      detailAr: `يوجد رصيد آجل بقيمة ${(Number(payables.amt) / 100).toLocaleString('en-US')} ج.م على فواتير الموردين.`,
      actionTab: 'suppliers',
    });
  }

  const demoCheck = (db.prepare('SELECT COUNT(*) as c FROM orders WHERE is_demo = 1').get() as {
    c: number;
  }).c;
  if (demoCheck > 0) {
    alerts.push({
      level: 'info',
      titleAr: 'يوجد بيانات تجريبية افتتاحية في السجل',
      detailAr: 'يمكنك تصفير البيانات التجريبية بضغطة زر من تبويب الإعدادات عند بدء التشغيل الفعلي.',
      actionTab: 'settings',
    });
  }

  const summary: DashboardSummary = {
    periods: { today, week, month, year, all_time },
    prevMonthComparison: {
      revenueDeltaPct: pctChange(month.revenuePiasters, prevMonth.revenuePiasters),
      profitDeltaPct: pctChange(month.netProfitPiasters, prevMonth.netProfitPiasters),
      ordersDeltaPct: pctChange(month.ordersCount, prevMonth.ordersCount),
    },
    outstandingReceivablesPiasters: Number(receivables.amt || 0),
    supplierPayablesPiasters: Number(payables.amt || 0),
    cashBalancePiasters: Number(cashBalanceRow.bal || 0),
    inventoryValuationCostPiasters: Number(invValuation.costVal || 0),
    inventoryValuationRetailPiasters: Number(invValuation.retailVal || 0),
    lowStockProducts: lowStockProducts as DashboardSummary['lowStockProducts'],
    recentOrders: recentOrders as DashboardSummary['recentOrders'],
    dailySeries,
    alerts,
  };

  res.json(summary);
});

// 2. Admin Categories & Products
adminRouter.get('/categories', (_req, res) => {
  const db = getDb();
  const categories = db
    .prepare(
      `SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) as product_count
       FROM categories c ORDER BY c.sort_order ASC, c.id ASC`
    )
    .all();
  res.json({ categories });
});

const categorySchema = z.object({
  name_ar: z.string().trim().min(2).max(80),
  name_en: z.string().trim().min(2).max(80),
  description_ar: z.string().trim().max(250).optional().default(''),
  sort_order: z.number().int().min(0).optional().default(0),
});

adminRouter.post('/categories', (req, res) => {
  const parsed = categorySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات التصنيف غير صالحة' });
    return;
  }
  const db = getDb();
  const slug = `cat-${Date.now()}`;
  const r = db
    .prepare(
      'INSERT INTO categories (slug, name_ar, name_en, description_ar, sort_order) VALUES (?, ?, ?, ?, ?)'
    )
    .run(slug, parsed.data.name_ar, parsed.data.name_en, parsed.data.description_ar, parsed.data.sort_order);
  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

adminRouter.get('/products', (_req, res) => {
  const db = getDb();
  const products = db
    .prepare(
      `SELECT p.*, c.name_ar as category_name_ar, c.name_en as category_name_en,
        (SELECT image_url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.is_primary DESC, pi.sort_order ASC LIMIT 1) as primary_image
       FROM products p
       JOIN categories c ON c.id = p.category_id
       ORDER BY p.id ASC`
    )
    .all();
  res.json({ products });
});

const productSchema = z.object({
  sku: z.string().trim().min(2).max(40).optional(),
  name_ar: z.string().trim().min(2, 'اسم المنتج بالعربية مطلوب').max(140),
  name_en: z.string().trim().min(1).max(140).optional().default(''),
  category_id: z.number().int().positive(),
  description_ar: z.string().trim().max(600).optional().default(''),
  description_en: z.string().trim().max(600).optional().default(''),
  selling_price_piasters: z.number().int().min(0),
  cost_price_piasters: z.number().int().min(0),
  stock_units: z.number().int().min(0),
  low_stock_threshold: z.number().int().min(0).default(12),
  is_active: z.number().int().min(0).max(1).default(1),
  is_featured: z.number().int().min(0).max(1).default(0),
  is_new: z.number().int().min(0).max(1).default(0),
  image_url: z.string().trim().optional(),
  price_change_reason: z.string().trim().max(200).optional(),
});

adminRouter.post('/products', (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'بيانات المنتج غير صالحة' });
    return;
  }
  const d = parsed.data;
  const db = getDb();
  const sku = d.sku || `OY-${Date.now().toString().slice(-5)}`;
  const slug = `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  try {
    const productId = db.transaction(() => {
      const resInsert = db
        .prepare(
          `INSERT INTO products (
            sku, slug, name_ar, name_en, category_id, description_ar, description_en,
            unit_label_ar, base_weight_grams, selling_price_piasters, cost_price_piasters,
            stock_units, low_stock_threshold, is_active, is_featured, is_new
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'تمن كيلو (125 جم)', 125, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          sku,
          slug,
          d.name_ar,
          d.name_en || d.name_ar,
          d.category_id,
          d.description_ar,
          d.description_en,
          d.selling_price_piasters,
          d.cost_price_piasters,
          d.stock_units,
          d.low_stock_threshold,
          d.is_active,
          d.is_featured,
          d.is_new
        );
      const id = Number(resInsert.lastInsertRowid);

      const defaultImg = d.image_url || '/src/assets/images/category_ground_blends_1794949411130.jpg';
      db.prepare(
        'INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, 1, 0)'
      ).run(id, defaultImg, d.name_ar);

      if (d.stock_units > 0) {
        db.prepare(
          `INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, note, created_by)
           VALUES (?, 'adjustment', ?, ?, 'product_create', 'إضافة رصيد منتج جديد', ?)`
        ).run(id, d.stock_units, d.stock_units, req.user!.id);
      }

      return id;
    })();

    res.status(201).json({ id: productId });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر إضافة المنتج' });
  }
});

adminRouter.put('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const parsed = productSchema.safeParse(req.body);
  if (!Number.isInteger(id) || id <= 0 || !parsed.success) {
    res.status(400).json({ error: parsed.error?.issues[0]?.message || 'بيانات غير صالحة' });
    return;
  }

  const d = parsed.data;
  const db = getDb();
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as
    | {
        id: number;
        selling_price_piasters: number;
        cost_price_piasters: number;
        stock_units: number;
      }
    | undefined;

  if (!existing) {
    res.status(404).json({ error: 'المنتج غير موجود' });
    return;
  }

  db.transaction(() => {
    db.prepare(
      `UPDATE products SET
        name_ar = ?, name_en = ?, category_id = ?, description_ar = ?, description_en = ?,
        selling_price_piasters = ?, cost_price_piasters = ?, stock_units = ?,
        low_stock_threshold = ?, is_active = ?, is_featured = ?, is_new = ?,
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      d.name_ar,
      d.name_en || d.name_ar,
      d.category_id,
      d.description_ar,
      d.description_en,
      d.selling_price_piasters,
      d.cost_price_piasters,
      d.stock_units,
      d.low_stock_threshold,
      d.is_active,
      d.is_featured,
      d.is_new,
      id
    );

    if (
      existing.selling_price_piasters !== d.selling_price_piasters ||
      existing.cost_price_piasters !== d.cost_price_piasters
    ) {
      db.prepare(
        `INSERT INTO price_history (product_id, old_selling_piasters, new_selling_piasters, old_cost_piasters, new_cost_piasters, changed_by, reason)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      ).run(
        id,
        existing.selling_price_piasters,
        d.selling_price_piasters,
        existing.cost_price_piasters,
        d.cost_price_piasters,
        req.user!.id,
        d.price_change_reason || 'تحديث من لوحة التحكم'
      );
    }

    const deltaStock = d.stock_units - existing.stock_units;
    if (deltaStock !== 0) {
      db.prepare(
        `INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, note, created_by)
         VALUES (?, 'adjustment', ?, ?, 'manual_edit', 'تعديل يدوي للمخزون', ?)`
      ).run(id, deltaStock, d.stock_units, req.user!.id);
    }

    if (d.image_url) {
      db.prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ?').run(id);
      db.prepare(
        'INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, 1, 0)'
      ).run(id, d.image_url, d.name_ar);
    }
  })();

  res.json({ ok: true });
});

adminRouter.delete('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const db = getDb();
  const usedInOrders = (
    db.prepare('SELECT COUNT(*) as c FROM order_items WHERE product_id = ?').get(id) as { c: number }
  ).c;

  if (usedInOrders > 0) {
    // Preserve historical order integrity by deactivating instead of hard deleting
    db.prepare("UPDATE products SET is_active = 0, updated_at = datetime('now') WHERE id = ?").run(id);
    res.json({ ok: true, softDeleted: true, message: 'تم تعطيل المنتج لارتباطه بطلبات سابقة.' });
    return;
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  res.json({ ok: true, softDeleted: false });
});

// Product image upload (base64 Data URL from file picker / phone camera)
const uploadImageSchema = z.object({
  data_url: z.string().min(20),
  alt_text: z.string().max(120).optional().default(''),
});

adminRouter.post('/products/:id/upload-image', (req, res) => {
  const id = Number(req.params.id);
  const parsed = uploadImageSchema.safeParse(req.body);
  if (!Number.isInteger(id) || id <= 0 || !parsed.success) {
    res.status(400).json({ error: 'بيانات الصورة غير صالحة' });
    return;
  }

  const match = parsed.data.data_url.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    res.status(400).json({ error: 'صيغة الصورة غير مدعومة (يرجى رفع JPG أو PNG أو WEBP)' });
    return;
  }

  const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
  const buffer = Buffer.from(match[2], 'base64');
  if (buffer.length > 4 * 1024 * 1024) {
    res.status(400).json({ error: 'حجم الصورة يتجاوز الحد الأقصى (4 ميجابايت)' });
    return;
  }

  const uploadsDir = path.resolve(process.cwd(), 'public/uploads/products');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const filename = `prod_${id}_${crypto.randomBytes(6).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(uploadsDir, filename), buffer);
  const publicUrl = `/uploads/products/${filename}`;

  const db = getDb();
  db.transaction(() => {
    db.prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ?').run(id);
    db.prepare(
      'INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, 1, 0)'
    ).run(id, publicUrl, parsed.data.alt_text);
  })();

  res.status(201).json({ image_url: publicUrl });
});

// 3. Orders Management
adminRouter.get('/orders', (req, res) => {
  const db = getDb();
  const status = String(req.query.status || '').trim();
  const q = String(req.query.q || '').trim();

  let sql = 'SELECT * FROM orders WHERE 1=1';
  const params: Array<string> = [];

  if (status && status !== 'all') {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (q) {
    sql += ' AND (order_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR delivery_area LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }

  sql += ' ORDER BY created_at DESC, id DESC LIMIT 200';
  const orders = db.prepare(sql).all(...params) as Array<{ id: number }>;

  const getItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
  const enriched = orders.map((o) => ({
    ...o,
    items: getItems.all(o.id),
  }));

  res.json({ orders: enriched });
});

const updateOrderSchema = z.object({
  status: z.enum(['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled']),
  delivery_actual_cost_piasters: z.number().int().min(0).optional(),
  discount_piasters: z.number().int().min(0).optional(),
  delivery_notes: z.string().max(400).optional(),
});

adminRouter.put('/orders/:id', (req, res) => {
  const id = Number(req.params.id);
  const parsed = updateOrderSchema.safeParse(req.body);
  if (!Number.isInteger(id) || id <= 0 || !parsed.success) {
    res.status(400).json({ error: 'بيانات تحديث الطلب غير صالحة' });
    return;
  }

  const db = getDb();
  const existing = db.prepare('SELECT * FROM orders WHERE id = ?').get(id) as
    | {
        id: number;
        order_number: string;
        status: string;
        subtotal_piasters: number;
        delivery_fee_piasters: number;
        delivery_actual_cost_piasters: number;
        discount_piasters: number;
      }
    | undefined;

  if (!existing) {
    res.status(404).json({ error: 'الطلب غير موجود' });
    return;
  }

  const d = parsed.data;
  const newActualDelivery = d.delivery_actual_cost_piasters ?? existing.delivery_actual_cost_piasters;
  const newDiscount = d.discount_piasters ?? existing.discount_piasters;
  const newTotal = Math.max(0, existing.subtotal_piasters + existing.delivery_fee_piasters - newDiscount);

  db.transaction(() => {
    db.prepare(
      `UPDATE orders SET
        status = ?,
        delivery_actual_cost_piasters = ?,
        discount_piasters = ?,
        total_piasters = ?,
        delivery_notes = COALESCE(?, delivery_notes),
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(d.status, newActualDelivery, newDiscount, newTotal, d.delivery_notes ?? null, id);

    // Restore stock automatically if transitioning TO cancelled from non-cancelled
    if (existing.status !== 'cancelled' && d.status === 'cancelled') {
      const items = db
        .prepare('SELECT product_id, weight_grams, quantity FROM order_items WHERE order_id = ?')
        .all(id) as Array<{ product_id: number | null; weight_grams: number; quantity: number }>;

      for (const it of items) {
        if (!it.product_id) continue;
        const restoreUnits = Math.max(1, Math.round((it.weight_grams / 125) * it.quantity));
        const prod = db.prepare('SELECT stock_units FROM products WHERE id = ?').get(it.product_id) as
          | { stock_units: number }
          | undefined;
        if (!prod) continue;
        const balAfter = prod.stock_units + restoreUnits;
        db.prepare("UPDATE products SET stock_units = ?, updated_at = datetime('now') WHERE id = ?").run(
          balAfter,
          it.product_id
        );
        db.prepare(
          `INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, reference_id, note, created_by)
           VALUES (?, 'order_cancel_restore', ?, ?, 'order', ?, ?, ?)`
        ).run(
          it.product_id,
          restoreUnits,
          balAfter,
          id,
          `استرجاع مخزون لإلغاء طلب ${existing.order_number}`,
          req.user!.id
        );
      }
    }
  })();

  res.json({ ok: true });
});

const recordPaymentSchema = z.object({
  amount_piasters: z.number().int().positive(),
  method: z.enum(['cod', 'instapay', 'vodafone_cash', 'bank_transfer']).default('cod'),
  reference_number: z.string().max(100).optional().default(''),
  notes: z.string().max(250).optional().default(''),
});

adminRouter.post('/orders/:id/payments', (req, res) => {
  const id = Number(req.params.id);
  const parsed = recordPaymentSchema.safeParse(req.body);
  if (!Number.isInteger(id) || id <= 0 || !parsed.success) {
    res.status(400).json({ error: 'بيانات الدفعة غير صالحة' });
    return;
  }

  const db = getDb();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id) as
    | { id: number; order_number: string; total_piasters: number; paid_piasters: number; is_demo: number }
    | undefined;

  if (!order) {
    res.status(404).json({ error: 'الطلب غير موجود' });
    return;
  }

  const d = parsed.data;
  const newPaid = order.paid_piasters + d.amount_piasters;
  const newStatus = newPaid >= order.total_piasters ? 'paid' : 'partial';

  db.transaction(() => {
    db.prepare(
      "UPDATE orders SET paid_piasters = ?, payment_status = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(newPaid, newStatus, id);

    db.prepare(
      `INSERT INTO payments (order_id, direction, amount_piasters, method, reference_number, notes, is_demo, recorded_by)
       VALUES (?, 'inflow', ?, ?, ?, ?, ?, ?)`
    ).run(id, d.amount_piasters, d.method, d.reference_number, d.notes, order.is_demo, req.user!.id);

    db.prepare(
      `INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
       VALUES ('inflow', 'order_payment', ?, ?, ?, ?, date('now'), ?, ?, ?)`
    ).run(
      id,
      `تحصيل طلب ${order.order_number}`,
      d.amount_piasters,
      d.method,
      d.notes || d.reference_number,
      order.is_demo,
      req.user!.id
    );
  })();

  res.status(201).json({ ok: true, paid_piasters: newPaid, payment_status: newStatus });
});

// 4. Expenses, Income & Financial Reports
adminRouter.get('/finance', (req, res) => {
  const db = getDb();
  const from = String(req.query.from || new Date(Date.now() - 90 * 86400000).toISOString().slice(0, 10));
  const to = String(req.query.to || new Date().toISOString().slice(0, 10));

  const expenses = db
    .prepare(
      `SELECT e.*, s.name as supplier_name
       FROM expenses e
       LEFT JOIN suppliers s ON s.id = e.supplier_id
       WHERE date(e.expense_date) BETWEEN date(?) AND date(?)
       ORDER BY e.expense_date DESC, e.id DESC`
    )
    .all(from, to);

  const ledger = db
    .prepare(
      `SELECT * FROM financial_records
       WHERE date(record_date) BETWEEN date(?) AND date(?)
       ORDER BY record_date DESC, id DESC
       LIMIT 300`
    )
    .all(from, to);

  const pnlOrderStats = db
    .prepare(
      `SELECT
        COUNT(*) as ordersCount,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_piasters - discount_piasters) ELSE 0 END), 0) as revenuePiasters,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN (total_cost_piasters + delivery_actual_cost_piasters) ELSE 0 END), 0) as cogsPiasters
       FROM orders
       WHERE date(created_at) BETWEEN date(?) AND date(?)`
    )
    .get(from, to) as { ordersCount: number; revenuePiasters: number; cogsPiasters: number };

  const expenseByCategory = db
    .prepare(
      `SELECT category, COALESCE(SUM(amount_piasters), 0) as total_piasters
       FROM expenses
       WHERE date(expense_date) BETWEEN date(?) AND date(?)
       GROUP BY category`
    )
    .all(from, to) as Array<{ category: string; total_piasters: number }>;

  const operatingExpensesPiasters = expenseByCategory
    .filter((c) => c.category !== 'inventory_purchase')
    .reduce((acc, c) => acc + Number(c.total_piasters), 0);

  const cashFlowSummary = db
    .prepare(
      `SELECT
        COALESCE(SUM(CASE WHEN record_type = 'inflow' THEN amount_piasters ELSE 0 END), 0) as totalInflow,
        COALESCE(SUM(CASE WHEN record_type = 'outflow' THEN amount_piasters ELSE 0 END), 0) as totalOutflow
       FROM financial_records
       WHERE date(record_date) BETWEEN date(?) AND date(?)`
    )
    .get(from, to) as { totalInflow: number; totalOutflow: number };

  const revenuePiasters = Number(pnlOrderStats.revenuePiasters || 0);
  const cogsPiasters = Number(pnlOrderStats.cogsPiasters || 0);
  const grossProfitPiasters = revenuePiasters - cogsPiasters;
  const netProfitPiasters = grossProfitPiasters - operatingExpensesPiasters;

  res.json({
    range: { from, to },
    expenses,
    ledger,
    expenseByCategory,
    pnl: {
      ordersCount: Number(pnlOrderStats.ordersCount || 0),
      revenuePiasters,
      cogsPiasters,
      grossProfitPiasters,
      operatingExpensesPiasters,
      netProfitPiasters,
      totalInflowPiasters: Number(cashFlowSummary.totalInflow || 0),
      totalOutflowPiasters: Number(cashFlowSummary.totalOutflow || 0),
      netCashFlowPiasters:
        Number(cashFlowSummary.totalInflow || 0) - Number(cashFlowSummary.totalOutflow || 0),
    },
  });
});

const expenseSchema = z.object({
  category: z.enum([
    'inventory_purchase',
    'packaging',
    'delivery_shipping',
    'marketing',
    'rent_utilities',
    'salaries',
    'other',
  ]),
  title: z.string().trim().min(2).max(160),
  amount_piasters: z.number().int().positive(),
  payment_method: z.string().trim().max(40).default('cash'),
  supplier_id: z.number().int().positive().nullable().optional(),
  notes: z.string().trim().max(300).optional().default(''),
  expense_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

adminRouter.post('/expenses', (req, res) => {
  const parsed = expenseSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات المصروف غير صالحة' });
    return;
  }
  const d = parsed.data;
  const db = getDb();

  const expId = db.transaction(() => {
    const r = db
      .prepare(
        `INSERT INTO expenses (category, title, amount_piasters, payment_method, supplier_id, notes, expense_date, is_demo, recorded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`
      )
      .run(
        d.category,
        d.title,
        d.amount_piasters,
        d.payment_method,
        d.supplier_id ?? null,
        d.notes,
        d.expense_date,
        req.user!.id
      );
    const id = Number(r.lastInsertRowid);

    db.prepare(
      `INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
       VALUES ('outflow', 'expense', ?, ?, ?, ?, ?, ?, 0, ?)`
    ).run(id, d.title, d.amount_piasters, d.payment_method, d.expense_date, d.notes, req.user!.id);

    return id;
  })();

  res.status(201).json({ id: expId });
});

adminRouter.delete('/expenses/:id', (req, res) => {
  const id = Number(req.params.id);
  const db = getDb();
  db.transaction(() => {
    db.prepare("DELETE FROM financial_records WHERE source_type = 'expense' AND source_id = ?").run(id);
    db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
  })();
  res.json({ ok: true });
});

const incomeSchema = z.object({
  title: z.string().trim().min(2).max(160),
  amount_piasters: z.number().int().positive(),
  payment_method: z.string().trim().max(40).default('cash'),
  record_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  notes: z.string().trim().max(300).optional().default(''),
});

adminRouter.post('/income', (req, res) => {
  const parsed = incomeSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات الإيراد غير صالحة' });
    return;
  }
  const d = parsed.data;
  const db = getDb();
  const r = db
    .prepare(
      `INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
       VALUES ('inflow', 'manual_income', NULL, ?, ?, ?, ?, ?, 0, ?)`
    )
    .run(d.title, d.amount_piasters, d.payment_method, d.record_date, d.notes, req.user!.id);
  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

adminRouter.get('/finance/export', (req, res) => {
  const db = getDb();
  const from = String(req.query.from || '2020-01-01');
  const to = String(req.query.to || new Date().toISOString().slice(0, 10));

  const rows = db
    .prepare(
      `SELECT record_date, record_type, source_type, title, amount_piasters, payment_method, notes
       FROM financial_records
       WHERE date(record_date) BETWEEN date(?) AND date(?)
       ORDER BY record_date DESC, id DESC`
    )
    .all(from, to) as Array<{
    record_date: string;
    record_type: string;
    source_type: string;
    title: string;
    amount_piasters: number;
    payment_method: string;
    notes: string;
  }>;

  const esc = (s: string) => `"${String(s || '').replace(/"/g, '""')}"`;
  const lines = [
    ['التاريخ', 'النوع', 'المصدر', 'البيان', 'المبلغ (ج.م)', 'وسيلة الدفع', 'ملاحظات'].map(esc).join(','),
    ...rows.map((r) =>
      [
        r.record_date,
        r.record_type === 'inflow' ? 'دخل / تحصيل' : 'مصروف / سداد',
        r.source_type,
        r.title,
        (r.amount_piasters / 100).toFixed(2),
        r.payment_method,
        r.notes,
      ]
        .map(esc)
        .join(',')
    ),
  ];

  // UTF-8 BOM for proper Arabic rendering in Excel
  const csv = '\uFEFF' + lines.join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="spices-store-finance-${from}-to-${to}.csv"`);
  res.send(csv);
});

// 5. Suppliers & Harraz Price Tracking
adminRouter.get('/suppliers', (_req, res) => {
  const db = getDb();
  const suppliers = db
    .prepare(
      `SELECT s.*,
        (SELECT COUNT(*) FROM supplier_purchases sp WHERE sp.supplier_id = s.id) as purchases_count,
        (SELECT COALESCE(SUM(sp.total_piasters), 0) FROM supplier_purchases sp WHERE sp.supplier_id = s.id) as total_purchased_piasters,
        (SELECT COALESCE(SUM(MAX(0, sp.total_piasters - sp.paid_piasters)), 0) FROM supplier_purchases sp WHERE sp.supplier_id = s.id) as unpaid_piasters
       FROM suppliers s
       ORDER BY CASE WHEN s.code = 'HARRAZ' THEN 0 ELSE 1 END, s.id ASC`
    )
    .all();

  const purchases = db
    .prepare(
      `SELECT sp.*, s.name as supplier_name, s.code as supplier_code
       FROM supplier_purchases sp
       JOIN suppliers s ON s.id = sp.supplier_id
       ORDER BY sp.purchase_date DESC, sp.id DESC
       LIMIT 100`
    )
    .all() as Array<{ id: number }>;

  const getPurchaseItems = db.prepare('SELECT * FROM supplier_purchase_items WHERE purchase_id = ?');
  const enrichedPurchases = purchases.map((p) => ({ ...p, items: getPurchaseItems.all(p.id) }));

  const prices = db
    .prepare(
      `SELECT sp.*, s.name as supplier_name, s.code as supplier_code,
        p.name_ar as product_name_ar, p.selling_price_piasters, p.cost_price_piasters as current_cost_piasters
       FROM supplier_prices sp
       JOIN suppliers s ON s.id = sp.supplier_id
       JOIN products p ON p.id = sp.product_id
       ORDER BY sp.recorded_date DESC, sp.id DESC
       LIMIT 300`
    )
    .all();

  res.json({ suppliers, purchases: enrichedPurchases, prices });
});

const supplierSchema = z.object({
  name: z.string().trim().min(2).max(140),
  code: z.string().trim().min(2).max(40).optional(),
  phone: z.string().trim().max(30).optional().default(''),
  address: z.string().trim().max(250).optional().default(''),
  city: z.string().trim().max(80).optional().default('القاهرة'),
  notes: z.string().trim().max(400).optional().default(''),
});

adminRouter.post('/suppliers', (req, res) => {
  const parsed = supplierSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات المورد غير صالحة' });
    return;
  }
  const d = parsed.data;
  const code = d.code || `SUP-${Date.now().toString().slice(-5)}`;
  const db = getDb();
  const r = db
    .prepare('INSERT INTO suppliers (name, code, phone, address, city, notes) VALUES (?, ?, ?, ?, ?, ?)')
    .run(d.name, code, d.phone, d.address, d.city, d.notes);
  res.status(201).json({ id: Number(r.lastInsertRowid) });
});

const supplierPriceSchema = z.object({
  supplier_id: z.number().int().positive(),
  product_id: z.number().int().positive(),
  unit_weight_grams: z.number().int().positive().default(125),
  cost_piasters: z.number().int().positive(),
  recorded_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  source_note: z.string().trim().max(250).optional().default('تحديث يدوي'),
  update_product_cost: z.boolean().optional().default(true),
});

adminRouter.post('/supplier-prices', (req, res) => {
  const parsed = supplierPriceSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات سعر المورد غير صالحة' });
    return;
  }
  const d = parsed.data;
  const db = getDb();

  const priceId = db.transaction(() => {
    const r = db
      .prepare(
        `INSERT INTO supplier_prices (supplier_id, product_id, unit_weight_grams, cost_piasters, recorded_date, source_note, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        d.supplier_id,
        d.product_id,
        d.unit_weight_grams,
        d.cost_piasters,
        d.recorded_date,
        d.source_note,
        req.user!.id
      );

    if (d.update_product_cost) {
      // Normalize cost to 125g base unit
      const normalizedCost125 = Math.round((d.cost_piasters * 125) / d.unit_weight_grams);
      const prod = db
        .prepare('SELECT selling_price_piasters, cost_price_piasters FROM products WHERE id = ?')
        .get(d.product_id) as
        | { selling_price_piasters: number; cost_price_piasters: number }
        | undefined;

      if (prod && prod.cost_price_piasters !== normalizedCost125) {
        db.prepare("UPDATE products SET cost_price_piasters = ?, updated_at = datetime('now') WHERE id = ?").run(
          normalizedCost125,
          d.product_id
        );
        db.prepare(
          `INSERT INTO price_history (product_id, old_selling_piasters, new_selling_piasters, old_cost_piasters, new_cost_piasters, changed_by, reason)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(
          d.product_id,
          prod.selling_price_piasters,
          prod.selling_price_piasters,
          prod.cost_price_piasters,
          normalizedCost125,
          req.user!.id,
          `تحديث تكلفة من المورد (${d.source_note})`
        );
      }
    }

    return Number(r.lastInsertRowid);
  })();

  res.status(201).json({ id: priceId });
});

const purchaseSchema = z.object({
  supplier_id: z.number().int().positive(),
  invoice_number: z.string().trim().max(80).optional().default(''),
  purchase_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  shipping_cost_piasters: z.number().int().min(0).default(0),
  paid_piasters: z.number().int().min(0).default(0),
  notes: z.string().trim().max(300).optional().default(''),
  items: z
    .array(
      z.object({
        product_id: z.number().int().positive(),
        quantity_units: z.number().int().positive(), // number of 125g packs or weight units
        unit_weight_grams: z.number().int().positive().default(125),
        unit_cost_piasters: z.number().int().min(0),
      })
    )
    .min(1),
});

adminRouter.post('/supplier-purchases', (req, res) => {
  const parsed = purchaseSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات فاتورة الشراء غير صالحة' });
    return;
  }
  const d = parsed.data;
  const db = getDb();

  const supplier = db.prepare('SELECT id, name FROM suppliers WHERE id = ?').get(d.supplier_id) as
    | { id: number; name: string }
    | undefined;
  if (!supplier) {
    res.status(404).json({ error: 'المورد غير موجود' });
    return;
  }

  const purchaseId = db.transaction(() => {
    let subtotal = 0;
    const itemRows: Array<{
      product_id: number;
      product_name_ar: string;
      quantity_units: number;
      unit_weight_grams: number;
      unit_cost_piasters: number;
      line_total_piasters: number;
    }> = [];

    for (const it of d.items) {
      const prod = db.prepare('SELECT id, name_ar, stock_units, selling_price_piasters, cost_price_piasters FROM products WHERE id = ?').get(it.product_id) as
        | {
            id: number;
            name_ar: string;
            stock_units: number;
            selling_price_piasters: number;
            cost_price_piasters: number;
          }
        | undefined;
      if (!prod) throw new Error(`المنتج رقم ${it.product_id} غير موجود`);
      const lineTotal = it.quantity_units * it.unit_cost_piasters;
      subtotal += lineTotal;
      itemRows.push({
        product_id: prod.id,
        product_name_ar: prod.name_ar,
        quantity_units: it.quantity_units,
        unit_weight_grams: it.unit_weight_grams,
        unit_cost_piasters: it.unit_cost_piasters,
        line_total_piasters: lineTotal,
      });
    }

    const total = subtotal + d.shipping_cost_piasters;
    const paid = Math.min(total, d.paid_piasters);
    const status = paid >= total ? 'paid' : paid > 0 ? 'partial' : 'unpaid';

    const purchRes = db
      .prepare(
        `INSERT INTO supplier_purchases (
          supplier_id, invoice_number, purchase_date, subtotal_piasters,
          shipping_cost_piasters, total_piasters, paid_piasters, status, notes, is_demo, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
      )
      .run(
        d.supplier_id,
        d.invoice_number || `INV-${Date.now().toString().slice(-5)}`,
        d.purchase_date,
        subtotal,
        d.shipping_cost_piasters,
        total,
        paid,
        status,
        d.notes,
        req.user!.id
      );
    const pid = Number(purchRes.lastInsertRowid);

    for (const ir of itemRows) {
      db.prepare(
        `INSERT INTO supplier_purchase_items (purchase_id, product_id, product_name_ar, quantity_units, unit_weight_grams, unit_cost_piasters, line_total_piasters)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      ).run(
        pid,
        ir.product_id,
        ir.product_name_ar,
        ir.quantity_units,
        ir.unit_weight_grams,
        ir.unit_cost_piasters,
        ir.line_total_piasters
      );

      // Convert purchased units into base 125g units and update stock + cost
      const addBaseUnits = Math.max(1, Math.round((ir.unit_weight_grams / 125) * ir.quantity_units));
      const normCost125 = Math.round((ir.unit_cost_piasters * 125) / ir.unit_weight_grams);
      const cur = db
        .prepare('SELECT stock_units, cost_price_piasters, selling_price_piasters FROM products WHERE id = ?')
        .get(ir.product_id) as { stock_units: number; cost_price_piasters: number; selling_price_piasters: number };
      const balAfter = cur.stock_units + addBaseUnits;

      db.prepare(
        "UPDATE products SET stock_units = ?, cost_price_piasters = ?, updated_at = datetime('now') WHERE id = ?"
      ).run(balAfter, normCost125, ir.product_id);

      db.prepare(
        `INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, reference_id, note, created_by)
         VALUES (?, 'purchase', ?, ?, 'supplier_purchase', ?, ?, ?)`
      ).run(pid ? ir.product_id : ir.product_id, addBaseUnits, balAfter, pid, `فاتورة شراء من ${supplier.name}`, req.user!.id);

      db.prepare(
        `INSERT INTO supplier_prices (supplier_id, product_id, unit_weight_grams, cost_piasters, recorded_date, source_note, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      ).run(
        d.supplier_id,
        ir.product_id,
        ir.unit_weight_grams,
        ir.unit_cost_piasters,
        d.purchase_date,
        `فاتورة شراء ${d.invoice_number || pid}`,
        req.user!.id
      );
    }

    if (paid > 0) {
      db.prepare(
        `INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
         VALUES ('outflow', 'supplier_payment', ?, ?, ?, 'cash', ?, ?, 0, ?)`
      ).run(
        pid,
        `سداد فاتورة ${supplier.name} (${d.invoice_number || pid})`,
        paid,
        d.purchase_date,
        d.notes,
        req.user!.id
      );
    }

    return pid;
  })();

  res.status(201).json({ id: purchaseId });
});

adminRouter.post('/supplier-purchases/:id/pay', (req, res) => {
  const id = Number(req.params.id);
  const amount = Number(req.body?.amount_piasters);
  if (!Number.isInteger(id) || id <= 0 || !Number.isInteger(amount) || amount <= 0) {
    res.status(400).json({ error: 'المبلغ غير صالح' });
    return;
  }
  const db = getDb();
  const purch = db
    .prepare(
      `SELECT sp.*, s.name as supplier_name FROM supplier_purchases sp
       JOIN suppliers s ON s.id = sp.supplier_id WHERE sp.id = ?`
    )
    .get(id) as
    | { id: number; supplier_name: string; invoice_number: string; total_piasters: number; paid_piasters: number; is_demo: number }
    | undefined;

  if (!purch) {
    res.status(404).json({ error: 'الفاتورة غير موجودة' });
    return;
  }

  const newPaid = Math.min(purch.total_piasters, purch.paid_piasters + amount);
  const status = newPaid >= purch.total_piasters ? 'paid' : 'partial';

  db.transaction(() => {
    db.prepare('UPDATE supplier_purchases SET paid_piasters = ?, status = ? WHERE id = ?').run(
      newPaid,
      status,
      id
    );
    db.prepare(
      `INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
       VALUES ('outflow', 'supplier_payment', ?, ?, ?, 'cash', date('now'), 'سداد مستحقات مورد', ?, ?)`
    ).run(id, `سداد فاتورة ${purch.supplier_name} (${purch.invoice_number})`, amount, purch.is_demo, req.user!.id);
  })();

  res.json({ ok: true, paid_piasters: newPaid, status });
});

// 6. Store Settings & Clear Demo Data
adminRouter.get('/settings', (_req, res) => {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM store_settings').all() as Array<{
    key: string;
    value: string;
  }>;
  const demoCounts = db
    .prepare(
      `SELECT
        (SELECT COUNT(*) FROM orders WHERE is_demo = 1) as orders,
        (SELECT COUNT(*) FROM expenses WHERE is_demo = 1) as expenses,
        (SELECT COUNT(*) FROM supplier_purchases WHERE is_demo = 1) as purchases`
    )
    .get();
  res.json({ settings: Object.fromEntries(rows.map((r) => [r.key, r.value])), demoCounts });
});

const settingsSchema = z.object({
  store_name_ar: z.string().trim().min(2).max(100),
  store_name_en: z.string().trim().min(2).max(100),
  whatsapp_number: z.string().trim().max(30).optional().default(''),
  store_phone: z.string().trim().max(30).optional().default(''),
  store_address: z.string().trim().max(200).optional().default(''),
  default_delivery_fee_piasters: z.number().int().min(0),
  free_delivery_threshold_piasters: z.number().int().min(0),
});

adminRouter.put('/settings', (req, res) => {
  const parsed = settingsSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات الإعدادات غير صالحة' });
    return;
  }
  const db = getDb();
  const upsert = db.prepare(
    "INSERT INTO store_settings (key, value, updated_at) VALUES (?, ?, datetime('now')) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')"
  );
  const d = parsed.data;
  db.transaction(() => {
    upsert.run('store_name_ar', d.store_name_ar);
    upsert.run('store_name_en', d.store_name_en);
    upsert.run('whatsapp_number', d.whatsapp_number);
    upsert.run('store_phone', d.store_phone);
    upsert.run('store_address', d.store_address);
    upsert.run('default_delivery_fee_piasters', String(d.default_delivery_fee_piasters));
    upsert.run('free_delivery_threshold_piasters', String(d.free_delivery_threshold_piasters));
  })();
  res.json({ ok: true });
});

adminRouter.post('/clear-demo', (_req, res) => {
  const db = getDb();
  db.transaction(() => {
    db.prepare('DELETE FROM financial_records WHERE is_demo = 1').run();
    db.prepare('DELETE FROM payments WHERE is_demo = 1').run();
    db.prepare('DELETE FROM expenses WHERE is_demo = 1').run();
    db.prepare('DELETE FROM supplier_purchases WHERE is_demo = 1').run();
    db.prepare('DELETE FROM orders WHERE is_demo = 1').run();
  })();
  res.json({ ok: true });
});
