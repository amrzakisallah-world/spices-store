import { getDb } from './db.ts';
import { hashPassword } from './security.ts';
import { toPiasters } from '../src/shared/types.ts';

const IMG_WHOLE = '/src/assets/images/category_whole_spices_1794949411033.jpg';
const IMG_GROUND = '/src/assets/images/category_ground_blends_1794949411130.jpg';
const IMG_HERBS = '/src/assets/images/category_herbs_seeds_1794949411485.jpg';

interface SeedProduct {
  sku: string;
  slug: string;
  name_ar: string;
  name_en: string;
  categorySlug: string;
  priceEgp: number;
  costEgp: number;
  stockUnits: number;
  isFeatured?: number;
  isNew?: number;
  description_ar: string;
  description_en: string;
  image: string;
}

const INITIAL_PRODUCTS: SeedProduct[] = [
  {
    sku: 'OY-001',
    slug: 'whole-black-pepper',
    name_ar: 'فلفل أسود حصا',
    name_en: 'Whole Black Peppercorns',
    categorySlug: 'whole-spices',
    priceEgp: 60,
    costEgp: 43,
    stockUnits: 48,
    isFeatured: 1,
    description_ar: 'فلفل أسود حصا مختار بعناية، حبة كاملة غنية بالزيوت العطرية والطعم القوي الأصيل.',
    description_en: 'Selected whole black peppercorns with rich aroma and bold flavor.',
    image: IMG_WHOLE,
  },
  {
    sku: 'OY-002',
    slug: 'baladi-cumin-seeds',
    name_ar: 'كمون بلدي حصا',
    name_en: 'Baladi Cumin Seeds',
    categorySlug: 'whole-spices',
    priceEgp: 50,
    costEgp: 36,
    stockUnits: 56,
    isFeatured: 1,
    description_ar: 'كمون بلدي أصلي منقى ونظيف 100%، رائحة نفاذة مثالية للطهي المصري والتتبيلات.',
    description_en: '100% pure Egyptian Baladi cumin seeds, cleaned and aromatic.',
    image: IMG_WHOLE,
  },
  {
    sku: 'OY-003',
    slug: 'bay-leaves',
    name_ar: 'ورق لورا',
    name_en: 'Dried Bay Leaves',
    categorySlug: 'whole-spices',
    priceEgp: 35,
    costEgp: 22,
    stockUnits: 40,
    description_ar: 'ورق لورا مجفف طبيعي بأوراق كاملة عالية الجودة للشوربة والطواجن واللحوم.',
    description_en: 'Whole dried bay leaves for broths, stews, and roasts.',
    image: IMG_WHOLE,
  },
  {
    sku: 'OY-004',
    slug: 'baladi-coriander-seeds',
    name_ar: 'كزبرة بلدي حصا',
    name_en: 'Baladi Coriander Seeds',
    categorySlug: 'whole-spices',
    priceEgp: 20,
    costEgp: 13,
    stockUnits: 64,
    isFeatured: 1,
    description_ar: 'كزبرة بلدي حصا منقاة، مثالية للطشة المصرية والطحن المنزلي الطازج.',
    description_en: 'Cleaned Baladi coriander seeds ideal for traditional Egyptian cooking.',
    image: IMG_WHOLE,
  },
  {
    sku: 'OY-005',
    slug: 'curry-powder',
    name_ar: 'كاري',
    name_en: 'Aromatic Curry Blend',
    categorySlug: 'ground-spices',
    priceEgp: 40,
    costEgp: 27,
    stockUnits: 38,
    description_ar: 'خلطة كاري متوازنة بلون ذهبي زاهي ونكهة دافئة للدجاج والأرز والمأكولات الهندية.',
    description_en: 'Balanced aromatic golden curry blend for poultry, rice, and stews.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-006',
    slug: 'turmeric-powder',
    name_ar: 'كركم',
    name_en: 'Pure Ground Turmeric',
    categorySlug: 'ground-spices',
    priceEgp: 35,
    costEgp: 23,
    stockUnits: 44,
    isFeatured: 1,
    description_ar: 'كركم مطحون ناعم نقي بدون إضافات، لون طبيعي غني وفوائد صحية عالية.',
    description_en: 'Pure finely ground turmeric with vibrant natural color.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-007',
    slug: 'chili-powder',
    name_ar: 'شطة',
    name_en: 'Hot Chili Powder',
    categorySlug: 'ground-spices',
    priceEgp: 35,
    costEgp: 23,
    stockUnits: 42,
    description_ar: 'شطة حمراء مطحونة بدرجة حرارة قوية ونكهة واضحة لعشاق المذاق الحار.',
    description_en: 'Fiery red chili powder ground fresh for authentic heat.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-008',
    slug: 'spanish-paprika',
    name_ar: 'بابريكا اسباني',
    name_en: 'Spanish Sweet Paprika',
    categorySlug: 'ground-spices',
    priceEgp: 50,
    costEgp: 34,
    stockUnits: 32,
    description_ar: 'بابريكا إسبانية حلوة فاخرة تمنح الأطباق لوناً أحمر طبيعياً وطعماً غنياً.',
    description_en: 'Sweet Spanish paprika delivering deep natural red color and mild flavor.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-009',
    slug: 'smoked-paprika',
    name_ar: 'بابريكا مدخنة',
    name_en: 'Smoked Paprika',
    categorySlug: 'ground-spices',
    priceEgp: 55,
    costEgp: 38,
    stockUnits: 30,
    isFeatured: 1,
    description_ar: 'بابريكا مدخنة على الحطب بنكهة شواء عميقة مميزة للمشاوي والصوصات.',
    description_en: 'Wood-smoked paprika with rich smoky aroma for grills and sauces.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-010',
    slug: 'seven-spices',
    name_ar: 'سبع بهارات',
    name_en: 'Egyptian Seven Spices',
    categorySlug: 'blends',
    priceEgp: 55,
    costEgp: 38,
    stockUnits: 50,
    isFeatured: 1,
    description_ar: 'توليفة عمر و يونس الخاصة من السبع بهارات المطحونة طازجاً للّحوم والمحاشي والطواجن.',
    description_en: 'Omar & Younis signature freshly ground Seven Spices blend.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-011',
    slug: 'onion-powder',
    name_ar: 'بصل بودر',
    name_en: 'Onion Powder',
    categorySlug: 'ground-spices',
    priceEgp: 35,
    costEgp: 24,
    stockUnits: 45,
    description_ar: 'بصل مجفف مطحون ناعم سريع الذوبان في التتبيلات والبرجر والشوربات.',
    description_en: 'Finely ground dehydrated onion powder for marinades and rubs.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-012',
    slug: 'garlic-powder',
    name_ar: 'ثوم بودر',
    name_en: 'Garlic Powder',
    categorySlug: 'ground-spices',
    priceEgp: 35,
    costEgp: 24,
    stockUnits: 46,
    description_ar: 'ثوم بودر نقي برائحة مركزة يضيف عمقاً شهياً للتتبيلات والبطاطس والمخبوزات.',
    description_en: 'Pure concentrated garlic powder for seasonings and dips.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-013',
    slug: 'grilled-chicken-seasoning',
    name_ar: 'بهارات فراخ مشوية',
    name_en: 'Grilled Chicken Seasoning',
    categorySlug: 'blends',
    priceEgp: 40,
    costEgp: 26,
    stockUnits: 36,
    isNew: 1,
    isFeatured: 1,
    description_ar: 'خلطة جديدة مميزة لتتبيل الفراخ المشوية على الفحم أو في الفرن بطعم المطاعم.',
    description_en: 'New signature blend crafted for charcoal and oven-roasted chicken.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-014',
    slug: 'potato-seasoning',
    name_ar: 'بهارات بطاطس',
    name_en: 'Crispy Potato Seasoning',
    categorySlug: 'blends',
    priceEgp: 40,
    costEgp: 25,
    stockUnits: 34,
    isNew: 1,
    description_ar: 'تتبيلة جديدة رائعة للبطاطس المقلية والودجز بطعم متوازن يحبه الكبار والأطفال.',
    description_en: 'New savory seasoning blend for fries and roasted potato wedges.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-015',
    slug: 'ground-cinnamon',
    name_ar: 'قرفة ناعمة',
    name_en: 'Ground Cinnamon',
    categorySlug: 'ground-spices',
    priceEgp: 40,
    costEgp: 27,
    stockUnits: 38,
    description_ar: 'قرفة ناعمة عطرية دافئة للحلويات والمشروبات والأرز بالخلطة واللحوم.',
    description_en: 'Warm aromatic ground cinnamon for desserts, drinks, and savory dishes.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-016',
    slug: 'cinnamon-sticks',
    name_ar: 'قرفة عيدان',
    name_en: 'Cinnamon Sticks',
    categorySlug: 'whole-spices',
    priceEgp: 60,
    costEgp: 42,
    stockUnits: 26,
    description_ar: 'عيدان قرفة كاملة عالية الجودة للمشروبات الدافئة والكبسة والشوربة.',
    description_en: 'Whole rolled cinnamon sticks ideal for warm beverages and Kabsa.',
    image: IMG_WHOLE,
  },
  {
    sku: 'OY-017',
    slug: 'sumac',
    name_ar: 'سماق',
    name_en: 'Tangy Sumac',
    categorySlug: 'ground-spices',
    priceEgp: 60,
    costEgp: 42,
    stockUnits: 24,
    description_ar: 'سماق أحمر أصلي بمذاق حامض منعش للفتوش والمشاوي والمسخن.',
    description_en: 'Authentic tangy crimson sumac for salads, grills, and Levantine dishes.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-018',
    slug: 'rosemary',
    name_ar: 'روز ماري',
    name_en: 'Dried Rosemary',
    categorySlug: 'herbs-seeds',
    priceEgp: 30,
    costEgp: 19,
    stockUnits: 35,
    description_ar: 'أوراق روزماري مجففة طبيعياً مثالية للحوم والبطاطس المشوية والدجاج.',
    description_en: 'Fragrant dried rosemary needles for steaks, poultry, and roasted potatoes.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-019',
    slug: 'rose-buds',
    name_ar: 'زر ورد',
    name_en: 'Dried Rose Buds',
    categorySlug: 'herbs-seeds',
    priceEgp: 30,
    costEgp: 19,
    stockUnits: 28,
    description_ar: 'زر ورد مجفف عطري يستخدم في خلطات البهارات الفاخرة والمشروبات والحلويات.',
    description_en: 'Aromatic dried rose buds for gourmet spice blends and infusions.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-020',
    slug: 'nigella-seeds',
    name_ar: 'حبة البركة',
    name_en: 'Black Nigella Seeds',
    categorySlug: 'herbs-seeds',
    priceEgp: 35,
    costEgp: 23,
    stockUnits: 42,
    description_ar: 'حبة البركة (الحبة السوداء) نقية ومنقاة للمخبوزات والعسل والاستخدام اليومي.',
    description_en: 'Pure cleaned black nigella seeds for baking and daily wellness.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-021',
    slug: 'white-sesame',
    name_ar: 'سمسم أبيض',
    name_en: 'Raw White Sesame Seeds',
    categorySlug: 'herbs-seeds',
    priceEgp: 25,
    costEgp: 17,
    stockUnits: 40,
    description_ar: 'سمسم أبيض نقي منقى للمخبوزات والحلويات المنزلية وتحضير الطحينة.',
    description_en: 'Clean white sesame seeds for baking, sweets, and homemade tahini.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-022',
    slug: 'roasted-sesame',
    name_ar: 'سمسم محمص',
    name_en: 'Roasted Sesame Seeds',
    categorySlug: 'herbs-seeds',
    priceEgp: 30,
    costEgp: 20,
    stockUnits: 38,
    description_ar: 'سمسم محمص بعناية بلون ذهبي ومذاق مقرمش للدقة والمخبوزات والسلطات.',
    description_en: 'Golden roasted sesame seeds with crisp nutty crunch for dukkah and toppings.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-023',
    slug: 'ginger-powder',
    name_ar: 'جنزبيل',
    name_en: 'Ground Ginger',
    categorySlug: 'ground-spices',
    priceEgp: 50,
    costEgp: 35,
    stockUnits: 30,
    description_ar: 'جنزبيل مطحون نقي بنكهة دافئة لاذعة للمشروبات الصحية والتتبيلات الآسيوية.',
    description_en: 'Pure zesty ground ginger for herbal drinks, baking, and marinades.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-024',
    slug: 'thyme',
    name_ar: 'زعتر',
    name_en: 'Dried Thyme',
    categorySlug: 'herbs-seeds',
    priceEgp: 35,
    costEgp: 22,
    stockUnits: 36,
    description_ar: 'زعتر طبيعي مجفف عالي النقاء للمخبوزات والبيتزا وتتبيلات الدجاج.',
    description_en: 'Pure dried thyme leaves for flatbreads, pizza, and marinades.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-025',
    slug: 'citric-acid',
    name_ar: 'ملح ليمون',
    name_en: 'Citric Acid',
    categorySlug: 'ground-spices',
    priceEgp: 15,
    costEgp: 9,
    stockUnits: 50,
    description_ar: 'ملح ليمون غذائي نقي لضبط الحموضة في المخللات والمربات والعصائر.',
    description_en: 'Food-grade citric acid for pickling, preserves, and cooking.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-026',
    slug: 'anise-seeds',
    name_ar: 'ينسون',
    name_en: 'Anise Seeds',
    categorySlug: 'herbs-seeds',
    priceEgp: 35,
    costEgp: 23,
    stockUnits: 38,
    description_ar: 'ينسون بلدي منقى برائحة عطرة ومهدئة للمشروبات الساخنة والمخبوزات.',
    description_en: 'Cleaned aromatic anise seeds for soothing herbal tea and baking.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-027',
    slug: 'fennel-seeds',
    name_ar: 'شمر',
    name_en: 'Fennel Seeds',
    categorySlug: 'herbs-seeds',
    priceEgp: 25,
    costEgp: 16,
    stockUnits: 34,
    description_ar: 'شمر طبيعي نقي بمذاق حلو منعش للمشروبات الدافئة والمخبوزات الشرقية.',
    description_en: 'Natural sweet fennel seeds for infusions and traditional pastries.',
    image: IMG_HERBS,
  },
  {
    sku: 'OY-028',
    slug: 'biryani-spices',
    name_ar: 'بهارات برياني',
    name_en: 'Biryani Spice Blend',
    categorySlug: 'blends',
    priceEgp: 50,
    costEgp: 34,
    stockUnits: 28,
    description_ar: 'خلطة برياني أصيلة تجمع الهيل والقرفة والقرنفل والكركم لأشهى طبق أرز برياني.',
    description_en: 'Authentic Biryani masala with cardamom, cloves, cinnamon, and turmeric.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-029',
    slug: 'fish-seasoning',
    name_ar: 'بهارات السمك',
    name_en: 'Seafood & Fish Seasoning',
    categorySlug: 'blends',
    priceEgp: 45,
    costEgp: 30,
    stockUnits: 32,
    description_ar: 'تتبيلة متكاملة للأسماك المقلية والمشوية والجمبري بالكمون والكزبرة والليمون المجفف.',
    description_en: 'Balanced seafood seasoning crafted for fried and grilled fish.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-030',
    slug: 'sausage-spices',
    name_ar: 'بهارات سجق',
    name_en: 'Egyptian Sausage Seasoning',
    categorySlug: 'blends',
    priceEgp: 60,
    costEgp: 41,
    stockUnits: 22,
    description_ar: 'خلطة بهارات السجق البلدي الأصلي بتوازن دقيق يبرز طعم اللحوم.',
    description_en: 'Traditional Egyptian sujuk seasoning blend with warm savory spices.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-031',
    slug: 'far-east-spices',
    name_ar: 'بهارات الشرق الأقصى',
    name_en: 'Far East Five Spice Blend',
    categorySlug: 'blends',
    priceEgp: 55,
    costEgp: 37,
    stockUnits: 20,
    description_ar: 'توليفة بهارات الشرق الأقصى بالينسون النجمي والقرفة والجنزبيل للأطباق الآسيوية.',
    description_en: 'Aromatic Far East spice blend for stir-fries, noodles, and glazes.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-032',
    slug: 'kabsa-spices',
    name_ar: 'بهارات كبسة',
    name_en: 'Kabsa Spice Mix',
    categorySlug: 'blends',
    priceEgp: 50,
    costEgp: 34,
    stockUnits: 34,
    description_ar: 'خلطة الكبسة الخليجية الفاخرة بطعم غني مع اللومي والقرفة والهيل.',
    description_en: 'Rich Arabian Kabsa blend with dried lime, cardamom, and warm spices.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-033',
    slug: 'kofta-spices',
    name_ar: 'بهارات كفتة',
    name_en: 'Kofta Grill Seasoning',
    categorySlug: 'blends',
    priceEgp: 65,
    costEgp: 44,
    stockUnits: 28,
    description_ar: 'خلطة كفتة الحاتي بمزيج احترافي يمنح الكفتة رائحة المشويات الأصيلة.',
    description_en: 'Artisanal Hatti Kofta seasoning for juicy, fragrant grilled skewers.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-034',
    slug: 'hawawshi-spices',
    name_ar: 'بهارات حواوشي',
    name_en: 'Hawawshi Spice Blend',
    categorySlug: 'blends',
    priceEgp: 65,
    costEgp: 44,
    stockUnits: 30,
    isFeatured: 1,
    description_ar: 'خلطة الحواوشي المصري الشهيرة بكبابة صيني وقرفة وجوزة الطيب وفلفل أسود.',
    description_en: 'Classic Egyptian Hawawshi spice blend for rich savory meat pies.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-035',
    slug: 'liver-kebda-spices',
    name_ar: 'بهارات كبدة',
    name_en: 'Alexandrian Kebda Spices',
    categorySlug: 'blends',
    priceEgp: 65,
    costEgp: 44,
    stockUnits: 26,
    description_ar: 'بهارات الكبدة الإسكندراني بالكمون والكزبرة والشطة لتتبيلة لا تقاوم.',
    description_en: 'Alexandrian liver seasoning crafted with roasted cumin and coriander.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-036',
    slug: 'chicken-shawarma-spices',
    name_ar: 'بهارات شاورما فراخ',
    name_en: 'Chicken Shawarma Blend',
    categorySlug: 'blends',
    priceEgp: 60,
    costEgp: 41,
    stockUnits: 30,
    description_ar: 'خلطة شاورما الفراخ الأصلية بالهيل والكركم والبابريكا والكزبرة لطعم الشاورما السوري.',
    description_en: 'Authentic chicken shawarma seasoning with cardamom, turmeric, and paprika.',
    image: IMG_GROUND,
  },
  {
    sku: 'OY-037',
    slug: 'meat-shawarma-spices',
    name_ar: 'بهارات شاورما لحم',
    name_en: 'Beef Shawarma Blend',
    categorySlug: 'blends',
    priceEgp: 60,
    costEgp: 41,
    stockUnits: 28,
    description_ar: 'بهارات شاورما اللحم بالسماق والقرفة والقرنفل والفلفل الأسود لتتبيلة احترافية.',
    description_en: 'Rich beef shawarma spice blend with sumac, cinnamon, and cloves.',
    image: IMG_GROUND,
  },
];

export function ensureDatabaseSeeded(): void {
  const db = getDb();

  // 1. Store settings
  const defaultSettings: Record<string, string> = {
    store_name_ar: 'عمر و يونس',
    store_name_en: 'Omar & Younis Spices',
    whatsapp_number: process.env.WHATSAPP_NUMBER || '',
    store_phone: process.env.STORE_PHONE || '',
    store_address: process.env.STORE_ADDRESS || 'القاهرة، مصر',
    default_delivery_fee_piasters: String(toPiasters(Number(process.env.DEFAULT_DELIVERY_FEE_EGP || 45))),
    free_delivery_threshold_piasters: String(
      toPiasters(Number(process.env.FREE_DELIVERY_THRESHOLD_EGP || 600))
    ),
  };

  const insertSetting = db.prepare(
    'INSERT OR IGNORE INTO store_settings (key, value) VALUES (?, ?)'
  );
  for (const [k, v] of Object.entries(defaultSettings)) {
    insertSetting.run(k, v);
  }

  // 2. Owner account (only created if no users exist)
  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  let adminUserId = 1;
  if (userCount === 0) {
    const email = (process.env.ADMIN_EMAIL || 'admin@omaryounis.com').trim().toLowerCase();
    const initialPass = process.env.ADMIN_INITIAL_PASSWORD || 'ChangeMe123!';
    const adminName = process.env.ADMIN_NAME || 'مدير المتجر';

    if (!process.env.ADMIN_INITIAL_PASSWORD) {
      console.warn(
        '[SECURITY NOTICE] No ADMIN_INITIAL_PASSWORD env var set. Seeded initial owner account with temporary dev password; change it immediately inside Admin Settings.'
      );
    }

    const res = db
      .prepare(
        'INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?)'
      )
      .run(adminName, email, '', hashPassword(initialPass), 'owner');
    adminUserId = Number(res.lastInsertRowid);
  } else {
    const firstUser = db
      .prepare('SELECT id, email FROM users ORDER BY id ASC LIMIT 1')
      .get() as { id: number; email: string };
    adminUserId = firstUser.id;

    const envEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
    if (envEmail) {
      const matched = db
        .prepare('SELECT id FROM users WHERE LOWER(email) = ?')
        .get(envEmail) as { id: number } | undefined;
      if (!matched) {
        const envName = process.env.ADMIN_NAME?.trim() || 'مدير المتجر';
        const envPass = process.env.ADMIN_INITIAL_PASSWORD;
        if (envPass) {
          db.prepare(
            "UPDATE users SET email = ?, name = ?, password_hash = ?, updated_at = datetime('now') WHERE id = ?"
          ).run(envEmail, envName, hashPassword(envPass), adminUserId);
        } else {
          db.prepare(
            "UPDATE users SET email = ?, name = ?, updated_at = datetime('now') WHERE id = ?"
          ).run(envEmail, envName, adminUserId);
        }
      }
    }
  }

  // 3. Categories
  const categoryCount = (db.prepare('SELECT COUNT(*) as c FROM categories').get() as { c: number }).c;
  if (categoryCount === 0) {
    const insertCat = db.prepare(
      'INSERT INTO categories (slug, name_ar, name_en, description_ar, sort_order) VALUES (?, ?, ?, ?, ?)'
    );
    insertCat.run('whole-spices', 'توابل حصا و صحيحة', 'Whole Spices', 'حبوب وتوابل صحيحة منقاة ومضمونة 100%', 1);
    insertCat.run('ground-spices', 'توابل مطحونة وأساسيات', 'Ground Spices', 'توابل مطحونة طازجاً بدون أي إضافات', 2);
    insertCat.run('blends', 'خلطات وبهارات جاهزة', 'Spice Blends', 'توليفات بهارات احترافية للمطابخ والمشويات', 3);
    insertCat.run('herbs-seeds', 'أعشاب وبذور طبيعية', 'Herbs & Seeds', 'أعشاب عطرية وبذور طبيعية طازجة', 4);
  }

  // 4. Products (37 authentic products from price list)
  const productCount = (db.prepare('SELECT COUNT(*) as c FROM products').get() as { c: number }).c;
  if (productCount === 0) {
    const catRows = db.prepare('SELECT id, slug FROM categories').all() as Array<{
      id: number;
      slug: string;
    }>;
    const catMap = new Map(catRows.map((c) => [c.slug, c.id]));

    const insertProd = db.prepare(`
      INSERT INTO products (
        sku, slug, name_ar, name_en, category_id, description_ar, description_en,
        unit_label_ar, base_weight_grams, selling_price_piasters, cost_price_piasters,
        stock_units, low_stock_threshold, is_active, is_featured, is_new
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);
    const insertImg = db.prepare(
      'INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, 1, 0)'
    );
    const insertMov = db.prepare(`
      INSERT INTO inventory_movements (product_id, movement_type, delta_units, balance_after, reference_type, note, created_by)
      VALUES (?, 'adjustment', ?, ?, 'initial_seed', 'رصيد افتتاحي للمخزون', ?)
    `);

    db.transaction(() => {
      for (const p of INITIAL_PRODUCTS) {
        const catId = catMap.get(p.categorySlug) || catRows[0].id;
        const sellingP = toPiasters(p.priceEgp);
        const costP = toPiasters(p.costEgp);
        const res = insertProd.run(
          p.sku,
          p.slug,
          p.name_ar,
          p.name_en,
          catId,
          p.description_ar,
          p.description_en,
          'تمن كيلو (125 جم)',
          125,
          sellingP,
          costP,
          p.stockUnits,
          12,
          p.isFeatured || 0,
          p.isNew || 0
        );
        const productId = Number(res.lastInsertRowid);
        insertImg.run(productId, p.image, p.name_ar);
        insertMov.run(productId, p.stockUnits, p.stockUnits, adminUserId);
      }
    })();
  }

  // 5. Suppliers (Harraz + Secondary Wholesale Supplier)
  const supplierCount = (db.prepare('SELECT COUNT(*) as c FROM suppliers').get() as { c: number }).c;
  if (supplierCount === 0) {
    const insertSup = db.prepare(
      'INSERT INTO suppliers (name, code, phone, address, city, notes) VALUES (?, ?, ?, ?, ?, ?)'
    );
    const harrazRes = insertSup.run(
      'عطار الحراز (سوق العطارة)',
      'HARRAZ',
      '',
      'سوق العطارة - ميدان باب الخلق / الأزهر',
      'القاهرة',
      'المورد الرئيسي المرجعي — الأسعار تُحدث يدوياً حسب فواتير الشراء الفعلية.'
    );
    insertSup.run(
      'مؤسسة النيل لتجارة التوابل جملة',
      'NILE-WHOLESALE',
      '',
      'منطقة العبور / سوق الجملة',
      'القاهرة',
      'مورد بديل للعبوات والتوابل الحصا.'
    );

    const harrazId = Number(harrazRes.lastInsertRowid);
    const topProducts = db
      .prepare('SELECT id, cost_price_piasters FROM products ORDER BY id ASC LIMIT 10')
      .all() as Array<{ id: number; cost_price_piasters: number }>;

    const insertSupPrice = db.prepare(`
      INSERT INTO supplier_prices (supplier_id, product_id, unit_weight_grams, cost_piasters, recorded_date, source_note, created_by)
      VALUES (?, ?, 125, ?, ?, ?, ?)
    `);

    const prevMonthDate = new Date(Date.now() - 28 * 86400000).toISOString().slice(0, 10);
    const recentDate = new Date(Date.now() - 4 * 86400000).toISOString().slice(0, 10);

    db.transaction(() => {
      for (const prod of topProducts) {
        const olderCost = Math.max(500, prod.cost_price_piasters - 200);
        insertSupPrice.run(
          harrazId,
          prod.id,
          olderCost,
          prevMonthDate,
          'مرجع يدوي افتتاحي (الشهر السابق)',
          adminUserId
        );
        insertSupPrice.run(
          harrazId,
          prod.id,
          prod.cost_price_piasters,
          recentDate,
          'مرجع يدوي افتتاحي (آخر تحديث)',
          adminUserId
        );
      }
    })();
  }

  // 6. Demo operational records (clearly tagged is_demo = 1, wipeable in Admin Settings)
  const orderCount = (db.prepare('SELECT COUNT(*) as c FROM orders').get() as { c: number }).c;
  if (orderCount === 0) {
    seedDemoTransactions(db, adminUserId);
  }
}

function seedDemoTransactions(db: ReturnType<typeof getDb>, adminUserId: number): void {
  const prods = db
    .prepare('SELECT id, name_ar, selling_price_piasters, cost_price_piasters FROM products LIMIT 12')
    .all() as Array<{
    id: number;
    name_ar: string;
    selling_price_piasters: number;
    cost_price_piasters: number;
  }>;
  if (prods.length < 6) return;

  const harraz = db.prepare("SELECT id FROM suppliers WHERE code = 'HARRAZ'").get() as
    | { id: number }
    | undefined;

  const daysAgoIso = (days: number) => {
    const d = new Date(Date.now() - days * 86400000);
    return d.toISOString().replace('T', ' ').slice(0, 19);
  };
  const daysAgoDate = (days: number) => new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);

  db.transaction(() => {
    const demoOrders = [
      {
        orderNumber: 'OY-1001',
        trackingCode: 'TRK-1001',
        name: 'أحمد محمود (بيانات تجريبية)',
        phone: '01012345678',
        area: 'مدينة نصر',
        address: 'شارع عباس العقاد - عمارة 14',
        status: 'delivered',
        paymentMethod: 'cod',
        paymentStatus: 'paid',
        daysAgo: 12,
        deliveryFee: 4500,
        deliveryActual: 3500,
        items: [
          { prod: prods[0], qty: 2, mult: 2, label: '250 جم (ربع كيلو)', grams: 250 },
          { prod: prods[1], qty: 1, mult: 4, label: '500 جم (نص كيلو)', grams: 500 },
        ],
      },
      {
        orderNumber: 'OY-1002',
        trackingCode: 'TRK-1002',
        name: 'سارة علي (بيانات تجريبية)',
        phone: '01123456789',
        area: 'المعادي',
        address: 'شارع 9 المعادي - بجوار المترو',
        status: 'delivered',
        paymentMethod: 'instapay',
        paymentStatus: 'paid',
        daysAgo: 5,
        deliveryFee: 4500,
        deliveryActual: 3500,
        items: [
          { prod: prods[9], qty: 2, mult: 2, label: '250 جم (ربع كيلو)', grams: 250 },
          { prod: prods[8], qty: 1, mult: 2, label: '250 جم (ربع كيلو)', grams: 250 },
          { prod: prods[5], qty: 2, mult: 1, label: '125 جم (تمن كيلو)', grams: 125 },
        ],
      },
      {
        orderNumber: 'OY-1003',
        trackingCode: 'TRK-1003',
        name: 'كريم حسن (بيانات تجريبية)',
        phone: '01234567890',
        area: 'الدقي',
        address: 'شارع التحرير - الدور الرابع',
        status: 'out_for_delivery',
        paymentMethod: 'cod',
        paymentStatus: 'unpaid',
        daysAgo: 1,
        deliveryFee: 4500,
        deliveryActual: 3500,
        items: [
          { prod: prods[3], qty: 2, mult: 2, label: '250 جم (ربع كيلو)', grams: 250 },
          { prod: prods[10], qty: 2, mult: 1, label: '125 جم (تمن كيلو)', grams: 125 },
        ],
      },
      {
        orderNumber: 'OY-1004',
        trackingCode: 'TRK-1004',
        name: 'منى إبراهيم (بيانات تجريبية)',
        phone: '01555667788',
        area: 'مصر الجديدة',
        address: 'ميدان روكسي - شارع الخليفة المأمون',
        status: 'pending',
        paymentMethod: 'vodafone_cash',
        paymentStatus: 'unpaid',
        daysAgo: 0,
        deliveryFee: 0,
        deliveryActual: 4000,
        items: [
          { prod: prods[0], qty: 1, mult: 8, label: '1 كجم (كيلو كامل)', grams: 1000 },
          { prod: prods[9], qty: 2, mult: 2, label: '250 جم (ربع كيلو)', grams: 250 },
        ],
      },
    ];

    const insertCust = db.prepare(
      'INSERT OR IGNORE INTO customers (name, phone, area, street_address) VALUES (?, ?, ?, ?)'
    );
    const getCust = db.prepare('SELECT id FROM customers WHERE phone = ?');
    const insertOrder = db.prepare(`
      INSERT INTO orders (
        order_number, tracking_code, customer_id, customer_name, customer_phone,
        delivery_address, delivery_area, delivery_notes, status, payment_method, payment_status,
        subtotal_piasters, delivery_fee_piasters, delivery_actual_cost_piasters, discount_piasters,
        total_piasters, total_cost_piasters, paid_piasters, is_demo, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, 1, ?, ?)
    `);
    const insertItem = db.prepare(`
      INSERT INTO order_items (
        order_id, product_id, product_name_ar, variant_label_ar, weight_grams,
        quantity, unit_price_piasters, unit_cost_piasters, line_total_piasters, line_cost_piasters
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertPayment = db.prepare(`
      INSERT INTO payments (order_id, direction, amount_piasters, method, notes, is_demo, recorded_by, paid_at)
      VALUES (?, 'inflow', ?, ?, 'تحصيل طلب [تجريبي]', 1, ?, ?)
    `);
    const insertFin = db.prepare(`
      INSERT INTO financial_records (record_type, source_type, source_id, title, amount_piasters, payment_method, record_date, notes, is_demo, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);

    for (const o of demoOrders) {
      insertCust.run(o.name, o.phone, o.area, o.address);
      const cust = getCust.get(o.phone) as { id: number };
      let subtotal = 0;
      let totalCost = 0;

      for (const it of o.items) {
        subtotal += it.prod.selling_price_piasters * it.mult * it.qty;
        totalCost += it.prod.cost_price_piasters * it.mult * it.qty;
      }
      const total = subtotal + o.deliveryFee;
      const paid = o.paymentStatus === 'paid' ? total : 0;
      const ts = daysAgoIso(o.daysAgo);
      const dt = daysAgoDate(o.daysAgo);

      const ordRes = insertOrder.run(
        o.orderNumber,
        o.trackingCode,
        cust.id,
        o.name,
        o.phone,
        o.address,
        o.area,
        'طلب تجريبي افتتاحي — يمكن حذفه من إعدادات الإدارة',
        o.status,
        o.paymentMethod,
        o.paymentStatus,
        subtotal,
        o.deliveryFee,
        o.deliveryActual,
        total,
        totalCost,
        paid,
        ts,
        ts
      );
      const orderId = Number(ordRes.lastInsertRowid);

      for (const it of o.items) {
        const unitP = it.prod.selling_price_piasters * it.mult;
        const unitC = it.prod.cost_price_piasters * it.mult;
        insertItem.run(
          orderId,
          it.prod.id,
          it.prod.name_ar,
          it.label,
          it.grams,
          it.qty,
          unitP,
          unitC,
          unitP * it.qty,
          unitC * it.qty
        );
      }

      if (paid > 0) {
        insertPayment.run(orderId, paid, o.paymentMethod, adminUserId, ts);
        insertFin.run(
          'inflow',
          'order_payment',
          orderId,
          `تحصيل طلب ${o.orderNumber} [تجريبي]`,
          paid,
          o.paymentMethod,
          dt,
          'بيانات تجريبية افتتاحية',
          adminUserId
        );
      }
    }

    // Demo operating expenses
    const expInsert = db.prepare(`
      INSERT INTO expenses (category, title, amount_piasters, payment_method, supplier_id, notes, expense_date, is_demo, recorded_by)
      VALUES (?, ?, ?, 'cash', ?, 'بيانات تجريبية افتتاحية', ?, 1, ?)
    `);
    const exp1 = expInsert.run('packaging', 'أكياس تغليف حراري وملصقات [تجريبي]', 28000, null, daysAgoDate(7), adminUserId);
    insertFin.run(
      'outflow',
      'expense',
      Number(exp1.lastInsertRowid),
      'أكياس تغليف حراري وملصقات [تجريبي]',
      28000,
      'cash',
      daysAgoDate(7),
      'بيانات تجريبية',
      adminUserId
    );

    const exp2 = expInsert.run('marketing', 'حملة إعلانية تجريبية [تجريبي]', 15000, null, daysAgoDate(3), adminUserId);
    insertFin.run(
      'outflow',
      'expense',
      Number(exp2.lastInsertRowid),
      'حملة إعلانية تجريبية [تجريبي]',
      15000,
      'cash',
      daysAgoDate(3),
      'بيانات تجريبية',
      adminUserId
    );

    // Demo supplier invoice from Harraz
    if (harraz) {
      const purchRes = db
        .prepare(
          `INSERT INTO supplier_purchases (supplier_id, invoice_number, purchase_date, subtotal_piasters, shipping_cost_piasters, total_piasters, paid_piasters, status, notes, is_demo, created_by)
           VALUES (?, 'HRZ-DEMO-101', ?, 95000, 5000, 100000, 100000, 'paid', 'فاتورة شراء افتتاحية [تجريبي]', 1, ?)`
        )
        .run(harraz.id, daysAgoDate(10), adminUserId);
      const purchId = Number(purchRes.lastInsertRowid);
      db.prepare(
        `INSERT INTO supplier_purchase_items (purchase_id, product_id, product_name_ar, quantity_units, unit_weight_grams, unit_cost_piasters, line_total_piasters)
         VALUES (?, ?, ?, 10, 125, ?, ?)`
      ).run(purchId, prods[0].id, prods[0].name_ar, prods[0].cost_price_piasters, prods[0].cost_price_piasters * 10);
      insertFin.run(
        'outflow',
        'supplier_payment',
        purchId,
        'سداد فاتورة حراز HRZ-DEMO-101 [تجريبي]',
        100000,
        'cash',
        daysAgoDate(10),
        'بيانات تجريبية',
        adminUserId
      );
    }
  })();
}
