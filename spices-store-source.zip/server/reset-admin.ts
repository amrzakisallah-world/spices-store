import 'dotenv/config';
import { getDb } from './db.ts';
import { hashPassword } from './security.ts';

const email = (process.argv[2] || process.env.ADMIN_EMAIL || 'admin@omaryounis.com')
  .trim()
  .toLowerCase();
const newPassword = process.argv[3] || process.env.ADMIN_INITIAL_PASSWORD;

if (!newPassword || newPassword.length < 8) {
  console.error('Usage: npm run reset-admin -- <email> <new_password_min_8_chars>');
  process.exit(1);
}

const db = getDb();
const user = db.prepare('SELECT id, email FROM users WHERE LOWER(email) = ?').get(email) as
  | { id: number; email: string }
  | undefined;

if (!user) {
  console.error(`Admin user not found for email: ${email}`);
  process.exit(1);
}

db.transaction(() => {
  db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(
    hashPassword(newPassword),
    user.id
  );
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
})();

console.log(`Password updated successfully for ${user.email} and existing sessions cleared.`);
