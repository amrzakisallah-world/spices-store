-- Spices Store (Omar & Younis) Relational Database Schema
-- Monetary values are stored as integer piasters (1 EGP = 100 piasters) to guarantee exact financial math.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL UNIQUE,
  applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT DEFAULT '',
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner', 'manager', 'staff')) DEFAULT 'owner',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS store_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_ar TEXT DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sku TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  description_ar TEXT NOT NULL DEFAULT '',
  description_en TEXT NOT NULL DEFAULT '',
  unit_label_ar TEXT NOT NULL DEFAULT 'تمن كيلو (125 جم)',
  base_weight_grams INTEGER NOT NULL DEFAULT 125,
  selling_price_piasters INTEGER NOT NULL CHECK (selling_price_piasters >= 0),
  cost_price_piasters INTEGER NOT NULL DEFAULT 0 CHECK (cost_price_piasters >= 0),
  stock_units INTEGER NOT NULL DEFAULT 0,
  low_stock_threshold INTEGER NOT NULL DEFAULT 12,
  is_active INTEGER NOT NULL DEFAULT 1,
  is_featured INTEGER NOT NULL DEFAULT 0,
  is_new INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  alt_text TEXT NOT NULL DEFAULT '',
  is_primary INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  old_selling_piasters INTEGER NOT NULL,
  new_selling_piasters INTEGER NOT NULL,
  old_cost_piasters INTEGER NOT NULL,
  new_cost_piasters INTEGER NOT NULL,
  changed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  alternate_phone TEXT DEFAULT '',
  governorate TEXT DEFAULT '',
  area TEXT DEFAULT '',
  street_address TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_number TEXT NOT NULL UNIQUE,
  tracking_code TEXT NOT NULL UNIQUE,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  delivery_area TEXT NOT NULL DEFAULT '',
  delivery_notes TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled')) DEFAULT 'pending',
  payment_method TEXT NOT NULL CHECK (payment_method IN ('cod', 'instapay', 'vodafone_cash', 'bank_transfer')) DEFAULT 'cod',
  payment_status TEXT NOT NULL CHECK (payment_status IN ('unpaid', 'partial', 'paid')) DEFAULT 'unpaid',
  subtotal_piasters INTEGER NOT NULL CHECK (subtotal_piasters >= 0),
  delivery_fee_piasters INTEGER NOT NULL DEFAULT 0 CHECK (delivery_fee_piasters >= 0),
  delivery_actual_cost_piasters INTEGER NOT NULL DEFAULT 0 CHECK (delivery_actual_cost_piasters >= 0),
  discount_piasters INTEGER NOT NULL DEFAULT 0 CHECK (discount_piasters >= 0),
  total_piasters INTEGER NOT NULL CHECK (total_piasters >= 0),
  total_cost_piasters INTEGER NOT NULL DEFAULT 0 CHECK (total_cost_piasters >= 0),
  paid_piasters INTEGER NOT NULL DEFAULT 0 CHECK (paid_piasters >= 0),
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name_ar TEXT NOT NULL,
  variant_label_ar TEXT NOT NULL,
  weight_grams INTEGER NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price_piasters INTEGER NOT NULL CHECK (unit_price_piasters >= 0),
  unit_cost_piasters INTEGER NOT NULL DEFAULT 0 CHECK (unit_cost_piasters >= 0),
  line_total_piasters INTEGER NOT NULL CHECK (line_total_piasters >= 0),
  line_cost_piasters INTEGER NOT NULL DEFAULT 0 CHECK (line_cost_piasters >= 0)
);

CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  phone TEXT DEFAULT '',
  address TEXT DEFAULT '',
  city TEXT DEFAULT 'القاهرة',
  notes TEXT DEFAULT '',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS supplier_prices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  unit_weight_grams INTEGER NOT NULL DEFAULT 125,
  cost_piasters INTEGER NOT NULL CHECK (cost_piasters >= 0),
  recorded_date TEXT NOT NULL DEFAULT (date('now')),
  source_note TEXT NOT NULL DEFAULT '',
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS supplier_purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  invoice_number TEXT NOT NULL DEFAULT '',
  purchase_date TEXT NOT NULL DEFAULT (date('now')),
  subtotal_piasters INTEGER NOT NULL CHECK (subtotal_piasters >= 0),
  shipping_cost_piasters INTEGER NOT NULL DEFAULT 0 CHECK (shipping_cost_piasters >= 0),
  total_piasters INTEGER NOT NULL CHECK (total_piasters >= 0),
  paid_piasters INTEGER NOT NULL DEFAULT 0 CHECK (paid_piasters >= 0),
  status TEXT NOT NULL CHECK (status IN ('unpaid', 'partial', 'paid')) DEFAULT 'unpaid',
  notes TEXT DEFAULT '',
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS supplier_purchase_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id INTEGER NOT NULL REFERENCES supplier_purchases(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name_ar TEXT NOT NULL,
  quantity_units INTEGER NOT NULL CHECK (quantity_units > 0),
  unit_weight_grams INTEGER NOT NULL DEFAULT 125,
  unit_cost_piasters INTEGER NOT NULL CHECK (unit_cost_piasters >= 0),
  line_total_piasters INTEGER NOT NULL CHECK (line_total_piasters >= 0)
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER REFERENCES orders(id) ON DELETE SET NULL,
  direction TEXT NOT NULL CHECK (direction IN ('inflow', 'outflow')) DEFAULT 'inflow',
  amount_piasters INTEGER NOT NULL CHECK (amount_piasters > 0),
  method TEXT NOT NULL DEFAULT 'cod',
  reference_number TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  is_demo INTEGER NOT NULL DEFAULT 0,
  recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  paid_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL CHECK (category IN ('inventory_purchase', 'packaging', 'delivery_shipping', 'marketing', 'rent_utilities', 'salaries', 'other')),
  title TEXT NOT NULL,
  amount_piasters INTEGER NOT NULL CHECK (amount_piasters > 0),
  payment_method TEXT NOT NULL DEFAULT 'cash',
  supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
  notes TEXT DEFAULT '',
  expense_date TEXT NOT NULL DEFAULT (date('now')),
  is_demo INTEGER NOT NULL DEFAULT 0,
  recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  movement_type TEXT NOT NULL CHECK (movement_type IN ('purchase', 'sale', 'order_cancel_restore', 'adjustment', 'spoilage')),
  delta_units INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  reference_type TEXT DEFAULT '',
  reference_id INTEGER,
  note TEXT DEFAULT '',
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS financial_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  record_type TEXT NOT NULL CHECK (record_type IN ('inflow', 'outflow')),
  source_type TEXT NOT NULL CHECK (source_type IN ('order_payment', 'expense', 'supplier_payment', 'manual_income')),
  source_id INTEGER,
  title TEXT NOT NULL,
  amount_piasters INTEGER NOT NULL CHECK (amount_piasters > 0),
  payment_method TEXT NOT NULL DEFAULT 'cash',
  record_date TEXT NOT NULL DEFAULT (date('now')),
  notes TEXT DEFAULT '',
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_supplier_prices_product ON supplier_prices(product_id, recorded_date);
CREATE INDEX IF NOT EXISTS idx_financial_records_date ON financial_records(record_date);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
