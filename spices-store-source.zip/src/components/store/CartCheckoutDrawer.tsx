import { useState } from 'react';
import { X, Plus, Minus, Trash2, CheckCircle2, MessageCircle, ShoppingBag } from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  PAYMENT_METHOD_LABELS,
  type CartItem,
  type Language,
  type PaymentMethod,
  type StorePublicConfig,
} from '../../shared/types';
import { ResilientImage } from '../ResilientImage';

interface CartCheckoutDrawerProps {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQty: (productId: number, weightGrams: number, delta: number) => void;
  onRemoveItem: (productId: number, weightGrams: number) => void;
  onClearCart: () => void;
  config: StorePublicConfig;
  lang: Language;
  onOrderCreated: (orderNumber: string) => void;
}

export function CartCheckoutDrawer({
  open,
  onClose,
  items,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  config,
  lang,
  onOrderCreated,
}: CartCheckoutDrawerProps) {
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryArea, setDeliveryArea] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [websiteUrl, setWebsiteUrl] = useState(''); // honeypot
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<{
    order_number: string;
    tracking_code: string;
    total_piasters: number;
    delivery_fee_piasters: number;
    subtotal_piasters: number;
    itemsSnapshot: CartItem[];
  } | null>(null);

  if (!open) return null;

  const subtotalPiasters = items.reduce(
    (sum, it) => sum + it.unitPricePiasters * it.quantity,
    0
  );
  const deliveryFee =
    items.length === 0
      ? 0
      : subtotalPiasters >= config.free_delivery_threshold_piasters
      ? 0
      : config.default_delivery_fee_piasters;
  const totalPiasters = subtotalPiasters + deliveryFee;
  const remainingForFree = Math.max(0, config.free_delivery_threshold_piasters - subtotalPiasters);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      const res = await api.createOrder({
        customer_name: customerName,
        customer_phone: customerPhone,
        delivery_area: deliveryArea,
        delivery_address: deliveryAddress,
        delivery_notes: deliveryNotes,
        payment_method: paymentMethod,
        website_url: websiteUrl,
        items: items.map((it) => ({
          product_id: it.productId,
          weight_grams: it.weightGrams,
          quantity: it.quantity,
        })),
      });

      setConfirmedOrder({
        order_number: res.order.order_number,
        tracking_code: res.order.tracking_code,
        total_piasters: res.order.total_piasters,
        delivery_fee_piasters: res.order.delivery_fee_piasters,
        subtotal_piasters: res.order.subtotal_piasters,
        itemsSnapshot: [...items],
      });
      setStep('success');
      onClearCart();
      onOrderCreated(res.order.order_number);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إرسال الطلب');
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    if (step === 'success') {
      setStep('cart');
      setConfirmedOrder(null);
    }
    onClose();
  };

  const whatsappText = confirmedOrder
    ? encodeURIComponent(
        `مرحباً متجر عمر و يونس، تم تأكيد طلبي رقم ${confirmedOrder.order_number} (كود التتبع: ${confirmedOrder.tracking_code})\n` +
          confirmedOrder.itemsSnapshot
            .map((i) => `- ${i.nameAr} (${i.variantLabelAr}) × ${i.quantity}`)
            .join('\n') +
          `\nالإجمالي: ${formatEGP(confirmedOrder.total_piasters, 'ar')}`
      )
    : '';

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/45 backdrop-blur-[2px]">
      <div
        className="w-full max-w-md bg-[#FAF7F2] h-full flex flex-col border-s border-[#E3D7C3] shadow-2xl"
        role="dialog"
        aria-modal="true"
        aria-label={lang === 'ar' ? 'سلة التسوق' : 'Shopping Cart'}
      >
        <div className="flex items-center justify-between px-5 py-4 bg-white border-b border-[#EAE0D0]">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#4E3119]" />
            <h2 className="text-lg font-bold text-[#2A1B0E]">
              {step === 'cart' && (lang === 'ar' ? 'سلة المشتريات' : 'Your Cart')}
              {step === 'checkout' && (lang === 'ar' ? 'إتمام طلب التوصيل' : 'Delivery Checkout')}
              {step === 'success' && (lang === 'ar' ? 'تم استلام طلبك بنجاح' : 'Order Confirmed')}
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-[#4E3119] hover:bg-[#F3ECE0] transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {step === 'cart' && (
            <>
              {items.length === 0 ? (
                <div className="text-center py-16 px-4">
                  <ShoppingBag className="w-12 h-12 mx-auto text-[#B59E7E] mb-3" strokeWidth={1.5} />
                  <p className="text-base font-semibold text-[#2A1B0E] mb-1">
                    {lang === 'ar' ? 'السلة فارغة حالياً' : 'Your cart is empty'}
                  </p>
                  <p className="text-sm text-[#6E5A44]">
                    {lang === 'ar'
                      ? 'أضف توابلك المفضلة واختر الوزن المناسب من المتجر.'
                      : 'Browse our fresh spices and select your preferred weight.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {remainingForFree > 0 ? (
                    <div className="p-3 bg-white border border-[#EAE0D0] rounded-lg text-xs text-[#4E3119]">
                      {lang === 'ar'
                        ? `أضف منتجات بقيمة ${formatEGP(remainingForFree, 'ar')} للحصول على توصيل مجاني.`
                        : `Add ${formatEGP(remainingForFree, 'en')} more for free delivery.`}
                    </div>
                  ) : (
                    <div className="p-3 bg-[#68782C]/10 border border-[#68782C]/25 rounded-lg text-xs font-medium text-[#47541A]">
                      {lang === 'ar'
                        ? 'طلبك مؤهل للتوصيل المجاني بالكامل.'
                        : 'Your order qualifies for free delivery.'}
                    </div>
                  )}

                  <ul className="divide-y divide-[#EAE0D0] bg-white border border-[#EAE0D0] rounded-xl overflow-hidden">
                    {items.map((item) => (
                      <li key={`${item.productId}-${item.weightGrams}`} className="p-3.5 flex gap-3">
                        <ResilientImage
                          src={item.imageUrl}
                          alt={item.nameAr}
                          className="w-16 h-16 rounded-lg object-cover shrink-0 border border-[#EAE0D0]"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="text-sm font-bold text-[#2A1B0E] truncate">
                              {lang === 'ar' ? item.nameAr : item.nameEn}
                            </h3>
                            <button
                              type="button"
                              onClick={() => onRemoveItem(item.productId, item.weightGrams)}
                              className="text-[#8A745C] hover:text-red-700 p-1"
                              aria-label="حذف الصنف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="text-xs text-[#6E5A44] mt-0.5">
                            {lang === 'ar' ? item.variantLabelAr : item.variantLabelEn} ·{' '}
                            <span className="font-mono-num">
                              {formatEGP(item.unitPricePiasters, lang)}
                            </span>
                          </p>
                          <div className="flex items-center justify-between mt-2.5">
                            <div className="inline-flex items-center border border-[#DFD2BE] rounded-lg bg-[#FAF7F2]">
                              <button
                                type="button"
                                onClick={() => onUpdateQty(item.productId, item.weightGrams, -1)}
                                className="w-9 h-9 flex items-center justify-center text-[#4E3119] hover:bg-[#EFE7D8]"
                                aria-label="إنقاص الكمية"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-8 text-center text-sm font-semibold font-mono-num text-[#2A1B0E]">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => onUpdateQty(item.productId, item.weightGrams, 1)}
                                className="w-9 h-9 flex items-center justify-center text-[#4E3119] hover:bg-[#EFE7D8]"
                                aria-label="زيادة الكمية"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <span className="text-sm font-bold text-[#4E3119] font-mono-num">
                              {formatEGP(item.unitPricePiasters * item.quantity, lang)}
                            </span>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {step === 'checkout' && (
            <form id="checkout-form" onSubmit={handleSubmitOrder} className="space-y-4">
              {error && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
                  {error}
                </div>
              )}

              {/* Honeypot */}
              <input
                type="text"
                tabIndex={-1}
                autoComplete="off"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                className="hidden"
                aria-hidden="true"
              />

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                  {lang === 'ar' ? 'الاسم بالكامل *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: محمد أحمد علي' : 'e.g. Mohamed Ahmed'}
                  className="w-full min-h-[44px] px-3.5 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm focus:outline-none focus:border-[#C78A1E]"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                  {lang === 'ar' ? 'رقم الموبايل (واتساب / اتصال) *' : 'Mobile Number *'}
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="01012345678"
                  className="w-full min-h-[44px] px-3.5 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm text-start font-mono-num focus:outline-none focus:border-[#C78A1E]"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                  {lang === 'ar' ? 'المنطقة / المحافظة *' : 'Area / Governorate *'}
                </label>
                <input
                  type="text"
                  required
                  value={deliveryArea}
                  onChange={(e) => setDeliveryArea(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: مدينة نصر، القاهرة' : 'e.g. Nasr City, Cairo'}
                  className="w-full min-h-[44px] px-3.5 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm focus:outline-none focus:border-[#C78A1E]"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                  {lang === 'ar' ? 'عنوان التوصيل بالتفصيل *' : 'Detailed Delivery Address *'}
                </label>
                <textarea
                  required
                  rows={2}
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder={
                    lang === 'ar'
                      ? 'اسم الشارع، رقم العمارة، الدور، الشقة، وأقرب علامة مميزة'
                      : 'Street, building, floor, apartment, and nearest landmark'
                  }
                  className="w-full px-3.5 py-2.5 bg-white border border-[#DFD2BE] rounded-lg text-sm focus:outline-none focus:border-[#C78A1E]"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                  {lang === 'ar' ? 'ملاحظات التوصيل أو التغليف (اختياري)' : 'Delivery Notes (Optional)'}
                </label>
                <input
                  type="text"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  placeholder={
                    lang === 'ar'
                      ? 'مثال: الاتصال قبل الوصول بنصف ساعة / تعبئة كل صنف منفصل'
                      : 'e.g. Call 30 mins before arrival'
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm focus:outline-none focus:border-[#C78A1E]"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2A1B0E] mb-1.5">
                  {lang === 'ar' ? 'طريقة الدفع' : 'Payment Method'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['cod', 'instapay', 'vodafone_cash', 'bank_transfer'] as PaymentMethod[]).map(
                    (method) => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => setPaymentMethod(method)}
                        className={`min-h-[44px] px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                          paymentMethod === method
                            ? 'bg-[#4E3119] text-white border-[#4E3119]'
                            : 'bg-white text-[#2A1B0E] border-[#DFD2BE] hover:border-[#C78A1E]'
                        }`}
                      >
                        {PAYMENT_METHOD_LABELS[method][lang]}
                      </button>
                    )
                  )}
                </div>
              </div>
            </form>
          )}

          {step === 'success' && confirmedOrder && (
            <div className="bg-white border border-[#EAE0D0] rounded-xl p-5 space-y-4">
              <div className="flex items-center gap-3 text-[#47541A]">
                <CheckCircle2 className="w-8 h-8 shrink-0 text-[#68782C]" />
                <div>
                  <h3 className="text-base font-bold text-[#2A1B0E]">
                    {lang === 'ar' ? 'تم تسجيل طلبك في عمر و يونس' : 'Your Order is Confirmed'}
                  </h3>
                  <p className="text-xs text-[#6E5A44]">
                    {lang === 'ar'
                      ? 'احتفظ برقم الطلب لمتابعة حالة التوصيل في أي وقت.'
                      : 'Keep your order number to track delivery status anytime.'}
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-[#FAF7F2] border border-[#EAE0D0] rounded-lg grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-[#6E5A44]">رقم الطلب</div>
                  <div className="font-bold font-mono-num text-[#4E3119]">
                    {confirmedOrder.order_number}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#6E5A44]">كود التتبع</div>
                  <div className="font-bold font-mono-num text-[#4E3119]">
                    {confirmedOrder.tracking_code}
                  </div>
                </div>
              </div>

              <div className="border-t border-[#EAE0D0] pt-3 space-y-1.5 text-sm">
                {confirmedOrder.itemsSnapshot.map((it) => (
                  <div
                    key={`${it.productId}-${it.weightGrams}`}
                    className="flex justify-between text-[#2A1B0E]"
                  >
                    <span>
                      {it.nameAr} ({it.variantLabelAr}) × {it.quantity}
                    </span>
                    <span className="font-mono-num">
                      {formatEGP(it.unitPricePiasters * it.quantity, lang)}
                    </span>
                  </div>
                ))}
                <div className="flex justify-between text-[#6E5A44] pt-2 border-t border-[#EAE0D0]">
                  <span>{lang === 'ar' ? 'التوصيل' : 'Delivery'}</span>
                  <span className="font-mono-num">
                    {confirmedOrder.delivery_fee_piasters === 0
                      ? lang === 'ar'
                        ? 'مجاني'
                        : 'Free'
                      : formatEGP(confirmedOrder.delivery_fee_piasters, lang)}
                  </span>
                </div>
                <div className="flex justify-between font-bold text-base text-[#4E3119] pt-1">
                  <span>{lang === 'ar' ? 'الإجمالي المطلوب' : 'Total Due'}</span>
                  <span className="font-mono-num">
                    {formatEGP(confirmedOrder.total_piasters, lang)}
                  </span>
                </div>
              </div>

              {config.whatsapp_number && (
                <a
                  href={`https://wa.me/${config.whatsapp_number.replace(/[^0-9]/g, '')}?text=${whatsappText}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full min-h-[44px] flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#25D366] text-white font-semibold text-sm hover:opacity-95 transition-opacity"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>
                    {lang === 'ar' ? 'إرسال تفاصيل الطلب عبر واتساب' : 'Send Order via WhatsApp'}
                  </span>
                </a>
              )}
            </div>
          )}
        </div>

        {items.length > 0 && step !== 'success' && (
          <div className="p-5 bg-white border-t border-[#EAE0D0] space-y-3">
            <div className="space-y-1 text-sm">
              <div className="flex justify-between text-[#6E5A44]">
                <span>{lang === 'ar' ? 'المجموع الفرعي' : 'Subtotal'}</span>
                <span className="font-mono-num">{formatEGP(subtotalPiasters, lang)}</span>
              </div>
              <div className="flex justify-between text-[#6E5A44]">
                <span>{lang === 'ar' ? 'رسوم التوصيل' : 'Delivery Fee'}</span>
                <span className="font-mono-num">
                  {deliveryFee === 0
                    ? lang === 'ar'
                      ? 'مجاني'
                      : 'Free'
                    : formatEGP(deliveryFee, lang)}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#2A1B0E] pt-1.5 border-t border-[#EAE0D0]">
                <span>{lang === 'ar' ? 'الإجمالي' : 'Total'}</span>
                <span className="font-mono-num text-[#4E3119]">
                  {formatEGP(totalPiasters, lang)}
                </span>
              </div>
            </div>

            {step === 'cart' ? (
              <button
                type="button"
                onClick={() => setStep('checkout')}
                className="w-full min-h-[46px] px-5 py-3 rounded-lg bg-[#C78A1E] hover:bg-[#B07714] text-white font-bold text-sm transition-colors"
              >
                {lang === 'ar' ? 'المتابعة لإتمام الطلب' : 'Proceed to Checkout'}
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="min-h-[46px] px-4 py-3 rounded-lg border border-[#DFD2BE] text-sm font-semibold text-[#4E3119] hover:bg-[#FAF7F2]"
                >
                  {lang === 'ar' ? 'رجوع' : 'Back'}
                </button>
                <button
                  type="submit"
                  form="checkout-form"
                  disabled={submitting}
                  className="flex-1 min-h-[46px] px-5 py-3 rounded-lg bg-[#4E3119] hover:bg-[#3A2310] disabled:opacity-60 text-white font-bold text-sm transition-colors"
                >
                  {submitting
                    ? lang === 'ar'
                      ? 'جاري تأكيد الطلب...'
                      : 'Submitting...'
                    : lang === 'ar'
                    ? 'تأكيد الطلب الآن'
                    : 'Confirm Order'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
