import { useState } from 'react';
import { X, Plus, Check } from 'lucide-react';
import { formatEGP, WEIGHT_OPTIONS, type Language, type Product } from '../../shared/types';
import { ResilientImage } from '../ResilientImage';

interface QuickOrderModalProps {
  open: boolean;
  onClose: () => void;
  products: Product[];
  onAddToCart: (product: Product, weightGrams: number, qty: number) => void;
  onOpenCart: () => void;
  cartCount: number;
  lang: Language;
}

export function QuickOrderModal({
  open,
  onClose,
  products,
  onAddToCart,
  onOpenCart,
  cartCount,
  lang,
}: QuickOrderModalProps) {
  const [selectedGrams, setSelectedGrams] = useState<number>(125);
  const [recentlyAddedId, setRecentlyAddedId] = useState<number | null>(null);

  if (!open) return null;

  const weightOpt = WEIGHT_OPTIONS.find((w) => w.grams === selectedGrams) || WEIGHT_OPTIONS[0];

  const handleQuickAdd = (product: Product) => {
    onAddToCart(product, selectedGrams, 1);
    setRecentlyAddedId(product.id);
    setTimeout(() => {
      setRecentlyAddedId((prev) => (prev === product.id ? null : prev));
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-[2px]">
      <div
        className="w-full max-w-2xl max-h-[90vh] bg-[#FAF7F2] rounded-2xl border border-[#DFD2BE] shadow-2xl flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        <div className="px-5 py-4 bg-white border-b border-[#EAE0D0] flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-[#2A1B0E]">
              {lang === 'ar' ? 'قائمة الطلب السريع' : 'Quick Order List'}
            </h2>
            <p className="text-xs text-[#6E5A44]">
              {lang === 'ar'
                ? 'أضف توابلك الأساسية بلمسة واحدة من القائمة المجمعة'
                : 'Tap + to quickly add your essential spices'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-[#4E3119] hover:bg-[#F3ECE0]"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-3 bg-[#F4EDE0] border-b border-[#EAE0D0] flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-semibold text-[#4E3119]">
            {lang === 'ar' ? 'الوزن المحدد للقائمة:' : 'Selected Pack Weight:'}
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            {WEIGHT_OPTIONS.map((w) => (
              <button
                key={w.grams}
                type="button"
                onClick={() => setSelectedGrams(w.grams)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  selectedGrams === w.grams
                    ? 'bg-[#4E3119] text-white'
                    : 'bg-white text-[#4E3119] border border-[#DFD2BE] hover:border-[#C78A1E]'
                }`}
              >
                {w.grams >= 1000 ? '1 كجم' : `${w.grams} جم`}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {products.map((product) => {
            const unitPrice = product.selling_price_piasters * weightOpt.multiplier;
            const outOfStock = product.stock_units < weightOpt.multiplier;
            const justAdded = recentlyAddedId === product.id;

            return (
              <div
                key={product.id}
                className="flex items-center gap-3 p-3 bg-white border border-[#EAE0D0] rounded-xl"
              >
                <ResilientImage
                  src={product.primary_image}
                  alt={product.name_ar}
                  className="w-12 h-12 rounded-lg object-cover shrink-0 border border-[#EAE0D0]"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold text-[#2A1B0E] truncate">
                    {lang === 'ar' ? product.name_ar : product.name_en}
                  </div>
                  <div className="text-xs text-[#6E5A44] flex items-center gap-1.5">
                    <span className="font-mono-num font-semibold text-[#4E3119]">
                      {formatEGP(unitPrice, lang)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{weightOpt.grams >= 1000 ? '1 كجم' : `${weightOpt.grams} جم`}</span>
                    {outOfStock && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-red-700 font-medium">غير متوفر بهذا الوزن</span>
                      </>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  disabled={outOfStock}
                  onClick={() => handleQuickAdd(product)}
                  className={`min-w-[44px] min-h-[44px] rounded-full flex items-center justify-center transition-colors shrink-0 ${
                    outOfStock
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : justAdded
                      ? 'bg-[#68782C] text-white'
                      : 'bg-[#C78A1E] hover:bg-[#B07714] text-white'
                  }`}
                  aria-label={`إضافة ${product.name_ar}`}
                >
                  {justAdded ? <Check className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                </button>
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-white border-t border-[#EAE0D0] flex items-center justify-between gap-3">
          <div className="text-sm text-[#4E3119] font-semibold">
            {lang === 'ar'
              ? `إجمالي الأصناف بالسلة: ${cartCount}`
              : `Items in Cart: ${cartCount}`}
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenCart();
            }}
            className="min-h-[44px] px-5 py-2.5 rounded-lg bg-[#C78A1E] hover:bg-[#B07714] text-white font-bold text-sm transition-colors whitespace-nowrap"
          >
            {lang === 'ar' ? 'عرض السلة والذهاب للدفع' : 'View Cart & Checkout'}
          </button>
        </div>
      </div>
    </div>
  );
}
