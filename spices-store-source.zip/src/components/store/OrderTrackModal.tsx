import { useState } from 'react';
import { X, Search, PackageCheck } from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  ORDER_STATUS_LABELS,
  type Language,
  type OrderRecord,
  type OrderStatus,
} from '../../shared/types';

interface OrderTrackModalProps {
  open: boolean;
  onClose: () => void;
  initialCode?: string;
  lang: Language;
}

const FLOW_STEPS: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'out_for_delivery',
  'delivered',
];

export function OrderTrackModal({ open, onClose, initialCode = '', lang }: OrderTrackModalProps) {
  const [code, setCode] = useState(initialCode);
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [order, setOrder] = useState<OrderRecord | null>(null);

  if (!open) return null;

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setOrder(null);
    setLoading(true);
    try {
      const res = await api.trackOrder(code.trim(), phone.trim());
      setOrder(res.order);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر البحث عن الطلب');
    } finally {
      setLoading(false);
    }
  };

  const currentStepIdx = order ? FLOW_STEPS.indexOf(order.status) : -1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-[2px]">
      <div
        className="w-full max-w-lg bg-[#FAF7F2] rounded-2xl border border-[#DFD2BE] shadow-2xl overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        <div className="px-5 py-4 bg-white border-b border-[#EAE0D0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-[#4E3119]" />
            <h2 className="text-lg font-bold text-[#2A1B0E]">
              {lang === 'ar' ? 'تتبع حالة الطلب' : 'Track Your Order'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-[#4E3119] hover:bg-[#F3ECE0]"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          <form onSubmit={handleTrack} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#4E3119] mb-1">
                  {lang === 'ar' ? 'رقم الطلب أو كود التتبع' : 'Order # or Tracking Code'}
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="OY-1001"
                  className="w-full min-h-[44px] px-3 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm font-mono-num focus:outline-none focus:border-[#C78A1E]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#4E3119] mb-1">
                  {lang === 'ar' ? 'رقم الهاتف المسجل بالطلب' : 'Phone Number'}
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01012345678"
                  className="w-full min-h-[44px] px-3 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm font-mono-num focus:outline-none focus:border-[#C78A1E]"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[44px] flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#4E3119] hover:bg-[#3A2310] text-white text-sm font-bold transition-colors"
            >
              <Search className="w-4 h-4" />
              <span>{loading ? 'جاري البحث...' : lang === 'ar' ? 'عرض حالة الطلب' : 'Check Status'}</span>
            </button>
          </form>

          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
              {error}
            </div>
          )}

          {order && (
            <div className="bg-white border border-[#EAE0D0] rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-[#EAE0D0] pb-3">
                <div>
                  <div className="text-xs text-[#6E5A44]">
                    {order.order_number} · {order.delivery_area}
                  </div>
                  <div className="text-base font-bold text-[#2A1B0E]">{order.customer_name}</div>
                </div>
                <div className="text-end">
                  <div className="text-sm font-bold text-[#4E3119]">
                    {ORDER_STATUS_LABELS[order.status][lang]}
                  </div>
                  <div className="text-xs text-[#6E5A44] font-mono-num">
                    {formatEGP(order.total_piasters, lang)}
                  </div>
                </div>
              </div>

              {order.status === 'cancelled' ? (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
                  {lang === 'ar' ? 'تم إلغاء هذا الطلب.' : 'This order has been cancelled.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {FLOW_STEPS.map((st, idx) => {
                    const done = idx <= currentStepIdx;
                    return (
                      <div key={st} className="flex items-center gap-3">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                            done
                              ? 'bg-[#68782C] text-white'
                              : 'bg-[#F3ECE0] text-[#8A745C] border border-[#DFD2BE]'
                          }`}
                        >
                          {idx + 1}
                        </span>
                        <span
                          className={`text-sm ${
                            done ? 'font-bold text-[#2A1B0E]' : 'text-[#8A745C]'
                          }`}
                        >
                          {ORDER_STATUS_LABELS[st][lang]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}

              {order.items && order.items.length > 0 && (
                <div className="border-t border-[#EAE0D0] pt-3 space-y-1.5 text-xs">
                  <div className="font-bold text-[#4E3119] mb-1">
                    {lang === 'ar' ? 'الأصناف المطلوبة' : 'Order Items'}
                  </div>
                  {order.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between text-[#2A1B0E]">
                      <span>
                        {it.product_name_ar} ({it.variant_label_ar}) × {it.quantity}
                      </span>
                      <span className="font-mono-num">{formatEGP(it.line_total_piasters, lang)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
