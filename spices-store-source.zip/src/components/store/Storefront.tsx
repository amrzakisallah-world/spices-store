import { useEffect, useMemo, useState } from 'react';
import {
  Search,
  ShoppingBasket,
  Zap,
  Truck,
  Leaf,
  Scale,
  ShieldCheck,
  Headphones,
  Package,
  MessageCircle,
  X,
  Plus,
  Minus,
  Menu,
  Globe,
} from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  WEIGHT_OPTIONS,
  type CartItem,
  type Category,
  type Language,
  type Product,
  type StorePublicConfig,
} from '../../shared/types';
import { ResilientImage } from '../ResilientImage';
import { CartCheckoutDrawer } from './CartCheckoutDrawer';
import { QuickOrderModal } from './QuickOrderModal';
import { OrderTrackModal } from './OrderTrackModal';

interface StorefrontProps {
  lang: Language;
  onToggleLang: () => void;
}

const CART_STORAGE_KEY = 'oy_spices_cart_v1';

export function Storefront({ lang, onToggleLang }: StorefrontProps) {
  const [config, setConfig] = useState<StorePublicConfig>({
    store_name_ar: 'عمر و يونس',
    store_name_en: 'Omar & Younis Spices',
    whatsapp_number: '',
    store_phone: '',
    store_address: 'القاهرة، مصر',
    default_delivery_fee_piasters: 4500,
    free_delivery_threshold_piasters: 60000,
  });
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cardWeights, setCardWeights] = useState<Record<number, number>>({});

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const [cartOpen, setCartOpen] = useState(false);
  const [quickOrderOpen, setQuickOrderOpen] = useState(false);
  const [trackOpen, setTrackOpen] = useState(false);
  const [lastOrderCode, setLastOrderCode] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);

  // Product detail modal
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);
  const [detailWeight, setDetailWeight] = useState<number>(125);
  const [detailQty, setDetailQty] = useState<number>(1);

  // Brief feedback toast when item added
  const [addedFeedback, setAddedFeedback] = useState<string>('');

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota issues
    }
  }, [cart]);

  useEffect(() => {
    let active = true;
    async function load() {
      setLoading(true);
      setLoadError('');
      try {
        const [cfg, cats, prods] = await Promise.all([
          api.getPublicConfig(),
          api.getCategories(),
          api.getProducts(),
        ]);
        if (!active) return;
        setConfig(cfg);
        setCategories(cats.categories);
        setProducts(prods.products);
      } catch (err) {
        if (!active) return;
        setLoadError(err instanceof Error ? err.message : 'تعذر تحميل المنتجات');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => {
      active = false;
    };
  }, []);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return products.filter((p) => {
      if (selectedCategory !== 'all') {
        const cat = categories.find((c) => c.slug === selectedCategory);
        if (cat && p.category_id !== cat.id) return false;
      }
      if (!q) return true;
      return (
        p.name_ar.toLowerCase().includes(q) ||
        p.name_en.toLowerCase().includes(q) ||
        p.description_ar.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
      );
    });
  }, [products, categories, selectedCategory, searchQuery]);

  const addToCart = (product: Product, weightGrams: number, qty: number) => {
    const weightOpt = WEIGHT_OPTIONS.find((w) => w.grams === weightGrams) || WEIGHT_OPTIONS[0];
    const unitPricePiasters = product.selling_price_piasters * weightOpt.multiplier;

    setCart((prev) => {
      const idx = prev.findIndex(
        (it) => it.productId === product.id && it.weightGrams === weightGrams
      );
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + qty };
        return copy;
      }
      return [
        ...prev,
        {
          productId: product.id,
          sku: product.sku,
          nameAr: product.name_ar,
          nameEn: product.name_en,
          imageUrl: product.primary_image || null,
          weightGrams,
          variantLabelAr: weightOpt.labelAr,
          variantLabelEn: weightOpt.labelEn,
          unitPricePiasters,
          quantity: qty,
          baseMultiplier: weightOpt.multiplier,
        },
      ];
    });

    setAddedFeedback(
      lang === 'ar'
        ? `تمت إضافة ${product.name_ar} إلى السلة`
        : `Added ${product.name_en} to cart`
    );
    setTimeout(() => setAddedFeedback(''), 2200);
  };

  const updateCartQty = (productId: number, weightGrams: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((it) =>
          it.productId === productId && it.weightGrams === weightGrams
            ? { ...it, quantity: it.quantity + delta }
            : it
        )
        .filter((it) => it.quantity > 0)
    );
  };

  const removeCartItem = (productId: number, weightGrams: number) => {
    setCart((prev) =>
      prev.filter((it) => !(it.productId === productId && it.weightGrams === weightGrams))
    );
  };

  const totalCartItems = cart.reduce((s, it) => s + it.quantity, 0);
  const totalCartPiasters = cart.reduce((s, it) => s + it.unitPricePiasters * it.quantity, 0);

  const openProductDetail = (p: Product) => {
    const w = cardWeights[p.id] || 125;
    setDetailProduct(p);
    setDetailWeight(w);
    setDetailQty(1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#2A1B0E]">
      {/* Slim Dismissible Delivery Strip (<= 38px) */}
      {!bannerDismissed && (
        <div className="bg-[#4E3119] text-[#FAF7F2] text-xs px-4 py-2 flex items-center justify-between gap-4">
          <div className="flex-1 text-center truncate">
            {lang === 'ar'
              ? `توصيل مجاني للطلبات فوق ${formatEGP(config.free_delivery_threshold_piasters, 'ar')} · الأسعار محدثة من المتجر مباشرة`
              : `Free delivery over ${formatEGP(config.free_delivery_threshold_piasters, 'en')} · Freshly packed daily`}
          </div>
          <button
            type="button"
            onClick={() => setBannerDismissed(true)}
            className="text-[#FAF7F2]/80 hover:text-white shrink-0"
            aria-label="إخفاء الشريط"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#FAF7F2]/95 backdrop-blur-sm border-b border-[#EAE0D0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand mark */}
          <a
            href="#top"
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C78A1E] rounded-lg"
          >
            <img
              src="/assets/aistudio/1794927406322_2be839d2.jpg"
              alt="شعار عمر و يونس"
              className="w-9 h-9 rounded-lg object-cover border border-[#DFD2BE]"
            />
            <span className="text-lg font-extrabold text-[#4E3119] font-display">
              {lang === 'ar' ? config.store_name_ar : config.store_name_en}
            </span>
          </a>

          {/* Zone 2: Clean single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-[#4E3119]">
            <a
              href="#catalog"
              className="hover:text-[#C78A1E] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {lang === 'ar' ? 'التوابل والأسعار' : 'Spices Catalog'}
            </a>
            <button
              type="button"
              onClick={() => setQuickOrderOpen(true)}
              className="hover:text-[#C78A1E] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {lang === 'ar' ? 'الطلب السريع' : 'Quick Order'}
            </button>
            <button
              type="button"
              onClick={() => setTrackOpen(true)}
              className="hover:text-[#C78A1E] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {lang === 'ar' ? 'تتبع الطلب' : 'Track Order'}
            </button>
            <a
              href="#guarantees"
              className="hover:text-[#C78A1E] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {lang === 'ar' ? 'ضمان الجودة' : 'Quality'}
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action (+ Mobile Menu button) */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setCartOpen(true)}
              className="min-h-[42px] px-4 py-2 rounded-lg bg-[#4E3119] hover:bg-[#3A2310] text-white text-sm font-bold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <ShoppingBasket className="w-4 h-4" />
              <span>{lang === 'ar' ? 'السلة' : 'Cart'}</span>
              <span className="font-mono-num text-xs bg-[#C78A1E] text-white px-1.5 py-0.5 rounded">
                {totalCartItems}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg border border-[#DFD2BE] text-[#4E3119]"
              aria-label="القائمة"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-[#EAE0D0] px-4 py-3 space-y-2">
            <a
              href="#catalog"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2.5 text-sm font-semibold text-[#2A1B0E] border-b border-[#F3ECE0]"
            >
              {lang === 'ar' ? 'التوابل والأسعار' : 'Spices Catalog'}
            </a>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setQuickOrderOpen(true);
              }}
              className="block w-full text-start py-2.5 text-sm font-semibold text-[#2A1B0E] border-b border-[#F3ECE0]"
            >
              {lang === 'ar' ? 'قائمة الطلب السريع' : 'Quick Order List'}
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setTrackOpen(true);
              }}
              className="block w-full text-start py-2.5 text-sm font-semibold text-[#2A1B0E] border-b border-[#F3ECE0]"
            >
              {lang === 'ar' ? 'تتبع حالة الطلب' : 'Track Order'}
            </button>
            <button
              type="button"
              onClick={() => {
                onToggleLang();
                setMobileMenuOpen(false);
              }}
              className="block w-full text-start py-2.5 text-sm font-semibold text-[#6E5A44]"
            >
              {lang === 'ar' ? 'Switch to English' : 'التبديل للعربية'}
            </button>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main id="top" className="flex-1">
        {/* Section 1: Hero Split */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 lg:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-between bg-white border border-[#EAE0D0] rounded-2xl p-6 sm:p-10">
              <div>
                <div className="flex items-center justify-between gap-4 mb-5">
                  <span className="text-xs font-semibold text-[#68782C]">
                    {lang === 'ar'
                      ? 'توابل وبهارات أصلي ومضمونة 100% · القاهرة'
                      : '100% Authentic Natural Spices · Egypt'}
                  </span>
                  <button
                    type="button"
                    onClick={onToggleLang}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4E3119] hover:text-[#C78A1E] whitespace-nowrap"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
                  </button>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold text-[#2A1B0E] leading-tight [text-wrap:balance] mb-4">
                  {lang === 'ar'
                    ? 'نكهة طبيعية أصيلة.. لمنزل أجمل ومطبخ متكامل'
                    : 'Pure Egyptian Spices, Packed Fresh Daily'}
                </h1>

                <p className="text-base text-[#5C4936] leading-relaxed max-w-xl mb-7">
                  {lang === 'ar'
                    ? 'من أجود حبوب التوابل الحصا إلى خلطات عمر و يونس الخاصة. اختر الوزن المناسب من 125 جم حتى 1 كجم بأسعار واضحة ومحدثة وتوصيل سريع لباب البيت.'
                    : 'From whole hand-selected seeds to Omar & Younis signature blends. Pick exact pack weights from 125g to 1kg with transparent prices and doorstep delivery.'}
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <a
                    href="#catalog"
                    className="min-h-[46px] px-6 py-3 rounded-lg bg-[#C78A1E] hover:bg-[#B07714] text-white font-bold text-sm inline-flex items-center justify-center transition-colors whitespace-nowrap"
                  >
                    {lang === 'ar' ? 'تصفح الأسعار والمنتجات' : 'Browse Spices & Prices'}
                  </a>
                  <button
                    type="button"
                    onClick={() => setQuickOrderOpen(true)}
                    className="min-h-[46px] px-5 py-3 rounded-lg border border-[#DFD2BE] bg-[#FAF7F2] hover:border-[#4E3119] text-[#4E3119] font-bold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap"
                  >
                    <Zap className="w-4 h-4 text-[#C78A1E]" />
                    <span>{lang === 'ar' ? 'قائمة الطلب السريع' : 'Quick Order List'}</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-7 mt-8 border-t border-[#EAE0D0] text-center sm:text-start">
                <div>
                  <div className="text-xl font-extrabold font-mono-num text-[#4E3119]">
                    {products.length || 37}+
                  </div>
                  <div className="text-xs text-[#6E5A44]">
                    {lang === 'ar' ? 'صنف توابل وبهارات' : 'Fresh Spices'}
                  </div>
                </div>
                <div>
                  <div className="text-xl font-extrabold font-mono-num text-[#4E3119]">125g–1kg</div>
                  <div className="text-xs text-[#6E5A44]">
                    {lang === 'ar' ? 'أوزان مرنة وميزان دقيق' : 'Exact Weights'}
                  </div>
                </div>
                <div>
                  <div className="text-xl font-extrabold text-[#4E3119]">
                    {lang === 'ar' ? 'عند الاستلام' : 'COD & Digital'}
                  </div>
                  <div className="text-xs text-[#6E5A44]">
                    {lang === 'ar' ? 'أو إنستا باي وفودافون كاش' : 'Flexible Payment'}
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-[#EAE0D0] bg-[#EFE7D8]">
              <ResilientImage
                src="/src/assets/images/hero_egyptian_spices_1794949411199.jpg"
                alt={
                  lang === 'ar'
                    ? 'توابل وبهارات عمر و يونس الطبيعية'
                    : 'Omar & Younis authentic natural spices'
                }
                className="w-full h-72 sm:h-96 lg:h-full object-cover"
              />
            </div>
          </div>
        </section>

        {/* Section 2: Catalog & Live Prices */}
        <section id="catalog" className="max-w-7xl mx-auto px-4 sm:px-6 py-8 lg:py-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#2A1B0E]">
                {lang === 'ar' ? 'قائمة التوابل والأسعار الحالية' : 'Spices & Current Prices'}
              </h2>
              <p className="text-sm text-[#6E5A44] mt-1">
                {lang === 'ar'
                  ? 'الأسعار المعروضة مرتبطة مباشرة بقاعدة البيانات — اختر الوزن لكل صنف وأضف للسلة.'
                  : 'Prices load directly from the live catalog — choose pack weight and add to cart.'}
              </p>
            </div>

            {/* Search Box */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-[#8A745C] absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  lang === 'ar' ? 'ابحث: كمون، فلفل أسود، بهارات...' : 'Search cumin, pepper, blends...'
                }
                className="w-full min-h-[44px] ps-10 pe-4 py-2 bg-white border border-[#DFD2BE] rounded-lg text-sm focus:outline-none focus:border-[#C78A1E]"
              />
            </div>
          </div>

          {/* Interactive Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-[#4E3119] text-white'
                  : 'bg-white text-[#4E3119] border border-[#EAE0D0] hover:border-[#C78A1E]'
              }`}
            >
              {lang === 'ar' ? `جميع الأصناف (${products.length})` : `All (${products.length})`}
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.slug)}
                className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory === cat.slug
                    ? 'bg-[#4E3119] text-white'
                    : 'bg-white text-[#4E3119] border border-[#EAE0D0] hover:border-[#C78A1E]'
                }`}
              >
                {lang === 'ar' ? cat.name_ar : cat.name_en}
              </button>
            ))}
          </div>

          {/* States: Loading / Error / Empty / Grid */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-[#EAE0D0] rounded-xl overflow-hidden animate-pulse"
                >
                  <div className="aspect-[4/3] bg-[#EFE7D8]" />
                  <div className="p-4 space-y-3">
                    <div className="h-3 w-24 bg-[#EFE7D8] rounded" />
                    <div className="h-5 w-44 bg-[#EFE7D8] rounded" />
                    <div className="h-10 w-full bg-[#EFE7D8] rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : loadError ? (
            <div className="p-6 bg-red-50 border border-red-200 rounded-xl text-center text-sm text-red-800">
              {loadError}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="p-12 bg-white border border-[#EAE0D0] rounded-xl text-center">
              <p className="text-base font-bold text-[#2A1B0E] mb-1">
                {lang === 'ar' ? 'لا توجد أصناف مطابقة لبحثك' : 'No matching spices found'}
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="mt-3 px-4 py-2 rounded-lg bg-[#4E3119] text-white text-xs font-bold"
              >
                {lang === 'ar' ? 'عرض جميع الأصناف' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => {
                const selectedGrams = cardWeights[product.id] || 125;
                const weightOpt =
                  WEIGHT_OPTIONS.find((w) => w.grams === selectedGrams) || WEIGHT_OPTIONS[0];
                const displayPrice = product.selling_price_piasters * weightOpt.multiplier;
                const outOfStock = product.stock_units < weightOpt.multiplier;
                const lowStock =
                  !outOfStock && product.stock_units <= product.low_stock_threshold;

                return (
                  <article
                    key={product.id}
                    className="bg-white border border-[#EAE0D0] rounded-xl overflow-hidden flex flex-col transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-md"
                  >
                    <button
                      type="button"
                      onClick={() => openProductDetail(product)}
                      className="aspect-[4/3] w-full overflow-hidden bg-[#F3ECE0] text-start focus-visible:outline-none"
                    >
                      <ResilientImage
                        src={product.primary_image}
                        alt={product.name_ar}
                        className="w-full h-full object-cover"
                      />
                    </button>

                    <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                      <div>
                        {/* Unboxed Metadata (Zero-Pill Rule) */}
                        <div className="text-xs text-[#6E5A44] flex items-center gap-1.5 mb-1">
                          <span>
                            {lang === 'ar' ? product.category_name_ar : product.category_name_en}
                          </span>
                          {product.is_new === 1 && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-bold text-[#C78A1E]">
                                {lang === 'ar' ? 'جديد' : 'New'}
                              </span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span
                            className={
                              outOfStock
                                ? 'text-red-700 font-semibold'
                                : lowStock
                                ? 'text-amber-700 font-semibold'
                                : 'text-[#68782C]'
                            }
                          >
                            {outOfStock
                              ? lang === 'ar'
                                ? 'غير متوفر بهذا الوزن'
                                : 'Out of Stock'
                              : lowStock
                              ? lang === 'ar'
                                ? 'كمية محدودة'
                                : 'Low Stock'
                              : lang === 'ar'
                              ? 'متوفر'
                              : 'In Stock'}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => openProductDetail(product)}
                          className="text-start w-full"
                        >
                          <h3 className="text-base font-bold text-[#2A1B0E] hover:text-[#C78A1E] transition-colors">
                            {lang === 'ar' ? product.name_ar : product.name_en}
                          </h3>
                        </button>

                        {/* Weight selector buttons */}
                        <div className="grid grid-cols-4 gap-1.5 mt-3">
                          {WEIGHT_OPTIONS.map((opt) => {
                            const active = selectedGrams === opt.grams;
                            return (
                              <button
                                key={opt.grams}
                                type="button"
                                onClick={() =>
                                  setCardWeights((prev) => ({ ...prev, [product.id]: opt.grams }))
                                }
                                className={`min-h-[34px] px-1.5 py-1 rounded text-[11px] font-semibold transition-colors whitespace-nowrap ${
                                  active
                                    ? 'bg-[#4E3119] text-white'
                                    : 'bg-[#FAF7F2] text-[#4E3119] border border-[#EAE0D0] hover:border-[#C78A1E]'
                                }`}
                              >
                                {opt.grams >= 1000 ? '1 كجم' : `${opt.grams} جم`}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-[#F2EAE0] flex items-center justify-between gap-3">
                        <div>
                          <div className="text-lg font-extrabold text-[#4E3119] font-mono-num">
                            {formatEGP(displayPrice, lang)}
                          </div>
                          <div className="text-[11px] text-[#6E5A44]">
                            {weightOpt.grams >= 1000
                              ? lang === 'ar'
                                ? '1 كجم'
                                : '1 kg'
                              : lang === 'ar'
                              ? `${weightOpt.grams} جرام`
                              : `${weightOpt.grams}g`}
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={outOfStock}
                          onClick={() => addToCart(product, selectedGrams, 1)}
                          className={`min-h-[44px] px-4 py-2 rounded-lg text-sm font-bold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                            outOfStock
                              ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                              : 'bg-[#C78A1E] hover:bg-[#B07714] text-white'
                          }`}
                        >
                          <Plus className="w-4 h-4" />
                          <span>{lang === 'ar' ? 'أضف للسلة' : 'Add'}</span>
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        {/* Section 3: Quality Guarantees & Delivery Info */}
        <section
          id="guarantees"
          className="bg-white border-y border-[#EAE0D0] py-12"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="max-w-2xl mb-8">
              <h2 className="text-2xl font-extrabold text-[#2A1B0E]">
                {lang === 'ar'
                  ? 'لماذا يثق عملاؤنا في عمر و يونس؟'
                  : 'Why Customers Trust Omar & Younis'}
              </h2>
              <p className="text-sm text-[#6E5A44] mt-1">
                {lang === 'ar'
                  ? 'جودة .. ثقة .. طعم أصيل — التزام كامل في الاختيار والطحن والوزن والتوصيل.'
                  : 'Quality, trust, and authentic flavor from selection to doorstep delivery.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: Leaf,
                  titleAr: 'طازجة وطبيعية 100%',
                  titleEn: 'Freshness & Natural Source',
                  descAr: 'توابل مختارة بدون ألوان صناعية أو مواد حافظة أو خلطات مغشوشة.',
                },
                {
                  icon: Scale,
                  titleAr: 'وزن دقيق ومضمون',
                  titleEn: 'Accurate Weight',
                  descAr: 'تعبئة بالميزان الإلكتروني الدقيق من 125 جرام وحتى 1 كيلوجرام.',
                },
                {
                  icon: Package,
                  titleAr: 'تغليف يدوي محكم',
                  titleEn: 'Hand-packed Care',
                  descAr: 'عبوات تحافظ على الزيوت العطرية والنكهة الطازجة حتى وصولها لمطبخك.',
                },
                {
                  icon: Truck,
                  titleAr: 'شحن آمن وتوصيل سريع',
                  titleEn: 'Secure Delivery',
                  descAr: `رسوم توصيل ${formatEGP(config.default_delivery_fee_piasters, 'ar')} ومجاني فوق ${formatEGP(config.free_delivery_threshold_piasters, 'ar')}.`,
                },
                {
                  icon: ShieldCheck,
                  titleAr: 'دفع آمن ومرن',
                  titleEn: 'Secure Payment',
                  descAr: 'ادفع نقداً عند الاستلام أو عبر إنستا باي أو فودافون كاش.',
                },
                {
                  icon: Headphones,
                  titleAr: 'متابعة ودعم مستمر',
                  titleEn: 'Friendly Support',
                  descAr: 'متابعة حالة طلبك خطوة بخطوة مباشرة عبر رقم الطلب.',
                },
              ].map((pillar) => {
                const Icon = pillar.icon;
                return (
                  <div
                    key={pillar.titleAr}
                    className="p-5 bg-[#FAF7F2] border border-[#EAE0D0] rounded-xl flex items-start gap-4"
                  >
                    <div className="w-10 h-10 rounded-lg bg-white border border-[#EAE0D0] flex items-center justify-center shrink-0 text-[#4E3119]">
                      <Icon className="w-5 h-5" strokeWidth={1.75} />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-[#2A1B0E]">
                        {lang === 'ar' ? pillar.titleAr : pillar.titleEn}
                      </h3>
                      <p className="text-xs text-[#6E5A44] mt-1 leading-relaxed">
                        {pillar.descAr}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      {/* Clean Footer */}
      <footer className="bg-[#2A1B0E] text-[#F5EDE0] py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/1794927406322_2be839d2.jpg"
              alt="عمر و يونس"
              className="w-11 h-11 rounded-lg object-cover border border-white/15"
            />
            <div>
              <div className="font-bold text-base">
                {config.store_name_ar} · {config.store_name_en}
              </div>
              <div className="text-xs text-[#D8C9B4]">
                {config.store_address}
                {config.store_phone ? ` · ${config.store_phone}` : ''}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button
              type="button"
              onClick={() => setTrackOpen(true)}
              className="hover:text-[#C78A1E] underline underline-offset-4"
            >
              {lang === 'ar' ? 'تتبع طلبك' : 'Track Order'}
            </button>
            <button
              type="button"
              onClick={() => setQuickOrderOpen(true)}
              className="hover:text-[#C78A1E] underline underline-offset-4"
            >
              {lang === 'ar' ? 'قائمة الطلب السريع' : 'Quick Order'}
            </button>
            {config.whatsapp_number && (
              <a
                href={`https://wa.me/${config.whatsapp_number.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#25D366] text-white font-bold"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>واتساب المتجر</span>
              </a>
            )}
          </div>
        </div>
      </footer>

      {/* Sticky Mobile Cart Bar (<= 15% viewport height, only shown when cart has items) */}
      {totalCartItems > 0 && !cartOpen && (
        <div className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-[#4E3119] text-white px-4 py-2.5 border-t border-white/10 shadow-lg flex items-center justify-between gap-3">
          <div className="text-xs">
            <span className="font-bold font-mono-num">{totalCartItems}</span>{' '}
            {lang === 'ar' ? 'صنف بالسلة' : 'items'} ·{' '}
            <span className="font-bold font-mono-num">
              {formatEGP(totalCartPiasters, lang)}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            className="min-h-[40px] px-4 py-1.5 rounded-lg bg-[#C78A1E] text-white text-xs font-bold whitespace-nowrap"
          >
            {lang === 'ar' ? 'عرض السلة والدفع' : 'Checkout'}
          </button>
        </div>
      )}

      {/* Brief Add-to-Cart Feedback */}
      {addedFeedback && (
        <div className="fixed bottom-16 md:bottom-6 start-1/2 -translate-x-1/2 z-40 px-4 py-2.5 rounded-lg bg-[#2A1B0E] text-white text-xs font-bold shadow-lg">
          {addedFeedback}
        </div>
      )}

      {/* Product Detail Modal */}
      {detailProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-[2px]">
          <div
            className="w-full max-w-2xl bg-[#FAF7F2] rounded-2xl border border-[#DFD2BE] overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2"
            role="dialog"
            aria-modal="true"
          >
            <div className="aspect-square md:aspect-auto bg-[#EFE7D8]">
              <ResilientImage
                src={detailProduct.primary_image}
                alt={detailProduct.name_ar}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6 flex flex-col justify-between gap-4 bg-white">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs text-[#6E5A44]">
                      {lang === 'ar'
                        ? detailProduct.category_name_ar
                        : detailProduct.category_name_en}{' '}
                      · {detailProduct.sku}
                    </div>
                    <h3 className="text-xl font-extrabold text-[#2A1B0E] mt-1">
                      {lang === 'ar' ? detailProduct.name_ar : detailProduct.name_en}
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setDetailProduct(null)}
                    className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg text-[#4E3119] hover:bg-[#F3ECE0]"
                    aria-label="إغلاق"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-sm text-[#5C4936] mt-3 leading-relaxed">
                  {lang === 'ar' ? detailProduct.description_ar : detailProduct.description_en}
                </p>

                <div className="mt-4">
                  <div className="text-xs font-bold text-[#4E3119] mb-2">
                    {lang === 'ar' ? 'اختر الوزن:' : 'Select Weight:'}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {WEIGHT_OPTIONS.map((w) => (
                      <button
                        key={w.grams}
                        type="button"
                        onClick={() => setDetailWeight(w.grams)}
                        className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                          detailWeight === w.grams
                            ? 'bg-[#4E3119] text-white border-[#4E3119]'
                            : 'bg-[#FAF7F2] text-[#2A1B0E] border-[#DFD2BE]'
                        }`}
                      >
                        {lang === 'ar' ? w.labelAr : w.labelEn}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#EAE0D0] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="inline-flex items-center border border-[#DFD2BE] rounded-lg">
                    <button
                      type="button"
                      onClick={() => setDetailQty((q) => Math.max(1, q - 1))}
                      className="w-10 h-10 flex items-center justify-center text-[#4E3119]"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center font-bold font-mono-num">{detailQty}</span>
                    <button
                      type="button"
                      onClick={() => setDetailQty((q) => q + 1)}
                      className="w-10 h-10 flex items-center justify-center text-[#4E3119]"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-xl font-extrabold font-mono-num text-[#4E3119]">
                    {formatEGP(
                      detailProduct.selling_price_piasters *
                        (WEIGHT_OPTIONS.find((w) => w.grams === detailWeight)?.multiplier || 1) *
                        detailQty,
                      lang
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    addToCart(detailProduct, detailWeight, detailQty);
                    setDetailProduct(null);
                  }}
                  className="w-full min-h-[46px] rounded-lg bg-[#C78A1E] hover:bg-[#B07714] text-white font-bold text-sm transition-colors"
                >
                  {lang === 'ar' ? 'أضف إلى السلة' : 'Add to Cart'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Drawers & Modals */}
      <CartCheckoutDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart}
        onUpdateQty={updateCartQty}
        onRemoveItem={removeCartItem}
        onClearCart={() => setCart([])}
        config={config}
        lang={lang}
        onOrderCreated={(num) => setLastOrderCode(num)}
      />

      <QuickOrderModal
        open={quickOrderOpen}
        onClose={() => setQuickOrderOpen(false)}
        products={products}
        onAddToCart={addToCart}
        onOpenCart={() => setCartOpen(true)}
        cartCount={totalCartItems}
        lang={lang}
      />

      <OrderTrackModal
        open={trackOpen}
        onClose={() => setTrackOpen(false)}
        initialCode={lastOrderCode}
        lang={lang}
      />
    </div>
  );
}
