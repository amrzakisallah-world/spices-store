import { useEffect, useState } from 'react';
import { Plus, Info, TrendingUp, TrendingDown } from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  toPiasters,
  type Product,
  type Supplier,
  type SupplierPriceRecord,
} from '../../shared/types';

interface SuppliersTabProps {
  products: Product[];
  onRefreshProducts: () => void;
}

export function SuppliersTab({ products, onRefreshProducts }: SuppliersTabProps) {
  const todayStr = new Date().toISOString().slice(0, 10);

  const [suppliers, setSuppliers] = useState<
    Array<
      Supplier & {
        purchases_count: number;
        total_purchased_piasters: number;
        unpaid_piasters: number;
      }
    >
  >([]);
  const [purchases, setPurchases] = useState<
    Array<{
      id: number;
      supplier_id: number;
      supplier_name: string;
      invoice_number: string;
      purchase_date: string;
      total_piasters: number;
      paid_piasters: number;
      status: string;
      items: Array<{
        id: number;
        product_name_ar: string;
        quantity_units: number;
        unit_weight_grams: number;
        unit_cost_piasters: number;
        line_total_piasters: number;
      }>;
    }>
  >([]);
  const [prices, setPrices] = useState<SupplierPriceRecord[]>([]);
  const [selectedSupplierId, setSelectedSupplierId] = useState<number>(1);
  const [feedback, setFeedback] = useState('');

  // Log Supplier Price form
  const [priceProdId, setPriceProdId] = useState<number>(products[0]?.id || 1);
  const [priceWeightGrams, setPriceWeightGrams] = useState<number>(125);
  const [priceEgp, setPriceEgp] = useState('');
  const [priceDate, setPriceDate] = useState(todayStr);
  const [priceNote, setPriceNote] = useState('تسعيرة الحراز - تحديث يدوي');
  const [updateProdCost, setUpdateProdCost] = useState(true);

  // Add Supplier form
  const [newSupName, setNewSupName] = useState('');
  const [newSupPhone, setNewSupPhone] = useState('');
  const [newSupAddr, setNewSupAddr] = useState('');

  // Purchase Invoice form
  const [invNumber, setInvNumber] = useState('');
  const [invDate, setInvDate] = useState(todayStr);
  const [invProdId, setInvProdId] = useState<number>(products[0]?.id || 1);
  const [invQty, setInvQty] = useState('10');
  const [invUnitCostEgp, setInvUnitCostEgp] = useState('40');
  const [invShippingEgp, setInvShippingEgp] = useState('0');
  const [invPaidEgp, setInvPaidEgp] = useState('');

  const loadData = async () => {
    const res = await api.getSuppliersData();
    setSuppliers(res.suppliers);
    setPurchases(res.purchases);
    setPrices(res.prices);
    if (res.suppliers.length > 0 && !res.suppliers.some((s) => s.id === selectedSupplierId)) {
      setSelectedSupplierId(res.suppliers[0].id);
    }
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogPrice = async (e: React.FormEvent) => {
    e.preventDefault();
    const costP = toPiasters(Number(priceEgp));
    if (costP <= 0) return;
    await api.logSupplierPrice({
      supplier_id: selectedSupplierId,
      product_id: Number(priceProdId),
      unit_weight_grams: Number(priceWeightGrams),
      cost_piasters: costP,
      recorded_date: priceDate,
      source_note: priceNote,
      update_product_cost: updateProdCost,
    });
    setPriceEgp('');
    setFeedback('تم تسجيل سعر المورد وتحديث السجل التاريخي بنجاح.');
    await loadData();
    if (updateProdCost) onRefreshProducts();
  };

  const handleCreateSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.createSupplier({
      name: newSupName,
      phone: newSupPhone,
      address: newSupAddr,
    });
    setNewSupName('');
    setNewSupPhone('');
    setNewSupAddr('');
    setFeedback('تمت إضافة المورد الجديد.');
    await loadData();
  };

  const handleCreatePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    const qty = Math.max(1, Math.round(Number(invQty)));
    const unitCost = toPiasters(Number(invUnitCostEgp));
    const shipCost = toPiasters(Number(invShippingEgp || 0));
    const total = qty * unitCost + shipCost;
    const paid = invPaidEgp === '' ? total : toPiasters(Number(invPaidEgp));

    await api.createSupplierPurchase({
      supplier_id: selectedSupplierId,
      invoice_number: invNumber,
      purchase_date: invDate,
      shipping_cost_piasters: shipCost,
      paid_piasters: paid,
      items: [
        {
          product_id: Number(invProdId),
          quantity_units: qty,
          unit_weight_grams: 125,
          unit_cost_piasters: unitCost,
        },
      ],
    });
    setInvNumber('');
    setInvPaidEgp('');
    setFeedback('تم تسجيل فاتورة الشراء وتحديث المخزون وسعر المورد تلقائياً.');
    await loadData();
    onRefreshProducts();
  };

  const handlePayInvoice = async (purchaseId: number, remainingPiasters: number) => {
    await api.paySupplierPurchase(purchaseId, remainingPiasters);
    setFeedback('تم تسجيل سداد الفاتورة بالكامل.');
    await loadData();
  };

  // Compute historical comparison per product for the selected supplier
  const supplierPricesFiltered = prices.filter((p) => p.supplier_id === selectedSupplierId);
  const priceComparisonRows = (() => {
    const grouped = new Map<number, SupplierPriceRecord[]>();
    for (const row of supplierPricesFiltered) {
      const list = grouped.get(row.product_id) || [];
      list.push(row);
      grouped.set(row.product_id, list);
    }
    return Array.from(grouped.entries()).map(([productId, list]) => {
      const latest = list[0];
      const previous = list[1] || null;
      const normLatest125 = Math.round((latest.cost_piasters * 125) / latest.unit_weight_grams);
      const normPrev125 = previous
        ? Math.round((previous.cost_piasters * 125) / previous.unit_weight_grams)
        : null;
      const selling125 = latest.selling_price_piasters || 0;
      const margin125 = selling125 - normLatest125;
      const delta125 = normPrev125 !== null ? normLatest125 - normPrev125 : null;
      return {
        productId,
        productNameAr: latest.product_name_ar || '',
        latestDate: latest.recorded_date,
        sourceNote: latest.source_note,
        normLatest125,
        normPrev125,
        delta125,
        selling125,
        margin125,
      };
    });
  })();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-extrabold text-slate-900">
          إدارة الموردين وتتبع أسعار الحراز
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          سجل أسعار الشراء من عطار الحراز والموردين يدوياً وقارن تغير الأسعار تاريخياً مع سعر البيع وهوامش الربح.
        </p>
      </div>

      {/* Explicit Transparency Notice */}
      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <div>
          <strong>ملاحظة مهنية:</strong> أسعار الحراز والموردين المعروضة هنا تُسجل يدوياً من واقع فواتير الشراء أو عروض الأسعار الفعلية ولا تدّعي الربط اللحظي التلقائي مع أي مصدر خارجي غير موثق. كل تحديث يُحفظ في السجل التاريخي للمقارنة.
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-slate-900 text-white text-xs font-semibold">
          {feedback}
        </div>
      )}

      {/* Supplier Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {suppliers.map((sup) => (
          <button
            key={sup.id}
            type="button"
            onClick={() => setSelectedSupplierId(sup.id)}
            className={`text-start p-4 rounded-xl border transition-colors ${
              selectedSupplierId === sup.id
                ? 'bg-[#4E3119] text-white border-[#4E3119]'
                : 'bg-white text-slate-900 border-slate-200 hover:border-[#C78A1E]'
            }`}
          >
            <div className="text-xs opacity-80">{sup.code} · {sup.city}</div>
            <div className="text-base font-extrabold mt-0.5">{sup.name}</div>
            <div className="mt-3 pt-2 border-t border-current/15 flex justify-between text-xs font-mono-num">
              <span>مشتريات: {formatEGP(sup.total_purchased_piasters, 'ar')}</span>
              <span>متبقي: {formatEGP(sup.unpaid_piasters, 'ar')}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Log Supplier Price + New Purchase Invoice */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={handleLogPrice}
          className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold text-slate-900">
            تسجيل تحديث سعر شراء (للمورد المحدد)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">الصنف</label>
              <select
                value={priceProdId}
                onChange={(e) => setPriceProdId(Number(e.target.value))}
                className="w-full min-h-[38px] px-2 border border-slate-200 rounded-lg bg-white"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_ar}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">الوزن المرجعي</label>
              <select
                value={priceWeightGrams}
                onChange={(e) => setPriceWeightGrams(Number(e.target.value))}
                className="w-full min-h-[38px] px-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value={125}>125 جم (تمن كيلو)</option>
                <option value={1000}>1 كجم (كيلو جملة)</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">سعر الشراء (ج.م) *</label>
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={priceEgp}
                onChange={(e) => setPriceEgp(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">تاريخ السعر</label>
              <input
                type="date"
                required
                value={priceDate}
                onChange={(e) => setPriceDate(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
          </div>
          <input
            type="text"
            value={priceNote}
            onChange={(e) => setPriceNote(e.target.value)}
            placeholder="ملاحظة المصدر (مثال: تسعيرة الحراز بتاريخ اليوم)"
            className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
          />
          <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={updateProdCost}
              onChange={(e) => setUpdateProdCost(e.target.checked)}
            />
            <span>تحديث تكلفة الشراء المعتمدة للمنتج تلقائياً (محولة لوحدة 125 جم)</span>
          </label>
          <button
            type="submit"
            className="min-h-[40px] px-4 py-2 rounded-lg bg-[#4E3119] text-white font-bold inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>حفظ السعر في السجل التاريخي</span>
          </button>
        </form>

        <form
          onSubmit={handleCreatePurchase}
          className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold text-slate-900">
            تسجيل فاتورة شراء بضاعة (تزيد المخزون تلقائياً)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">الصنف المشترى</label>
              <select
                value={invProdId}
                onChange={(e) => setInvProdId(Number(e.target.value))}
                className="w-full min-h-[38px] px-2 border border-slate-200 rounded-lg bg-white"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_ar}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">رقم الفاتورة</label>
              <input
                type="text"
                value={invNumber}
                onChange={(e) => setInvNumber(e.target.value)}
                placeholder="مثال: HRZ-204"
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">الكمية (وحدة 125 جم)</label>
              <input
                type="number"
                min="1"
                required
                value={invQty}
                onChange={(e) => setInvQty(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">تكلفة الوحدة 125 جم (ج.م)</label>
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={invUnitCostEgp}
                onChange={(e) => setInvUnitCostEgp(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">مصاريف نقل الفاتورة (ج.م)</label>
              <input
                type="number"
                min="0"
                value={invShippingEgp}
                onChange={(e) => setInvShippingEgp(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">المدفوع حالياً (فارغ = مسدد بالكامل)</label>
              <input
                type="number"
                min="0"
                value={invPaidEgp}
                onChange={(e) => setInvPaidEgp(e.target.value)}
                placeholder="اختياري"
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
            <div>
              <label className="block font-bold text-slate-700 mb-1">تاريخ الفاتورة</label>
              <input
                type="date"
                required
                value={invDate}
                onChange={(e) => setInvDate(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <button
              type="submit"
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold inline-flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل فاتورة الشراء</span>
            </button>
          </div>
        </form>
      </div>

      {/* Price Comparison Table (Supplier Cost vs Previous Cost vs Selling Price) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <div className="px-4 py-3 border-b border-slate-200 font-bold text-sm text-slate-900">
          مقارنة أسعار المورد المحدد مع السعر التاريخي وسعر البيع (لوحدة 125 جم)
        </div>
        {priceComparisonRows.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500">
            لا توجد أسعار مسجلة لهذا المورد بعد. استخدم النموذج أعلاه لتسجيل أول سعر.
          </div>
        ) : (
          <table className="w-full text-xs min-w-[700px]">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th className="text-start px-4 py-2.5">الصنف</th>
                <th className="text-end px-3 py-2.5">آخر سعر شراء</th>
                <th className="text-end px-3 py-2.5">السعر السابق</th>
                <th className="text-end px-3 py-2.5">التغير</th>
                <th className="text-end px-3 py-2.5">سعر البيع بالمتجر</th>
                <th className="text-end px-3 py-2.5">هامش الربح</th>
                <th className="text-start px-4 py-2.5">آخر تحديث</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {priceComparisonRows.map((row) => (
                <tr key={row.productId}>
                  <td className="px-4 py-2.5 font-bold text-slate-900">{row.productNameAr}</td>
                  <td className="px-3 py-2.5 text-end font-mono-num font-bold text-slate-900">
                    {formatEGP(row.normLatest125, 'ar')}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num text-slate-500">
                    {row.normPrev125 !== null ? formatEGP(row.normPrev125, 'ar') : '—'}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num">
                    {row.delta125 === null ? (
                      '—'
                    ) : row.delta125 > 0 ? (
                      <span className="inline-flex items-center gap-1 text-red-700 font-bold">
                        <TrendingUp className="w-3 h-3" />+{formatEGP(row.delta125, 'ar')}
                      </span>
                    ) : row.delta125 < 0 ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                        <TrendingDown className="w-3 h-3" />
                        {formatEGP(row.delta125, 'ar')}
                      </span>
                    ) : (
                      <span className="text-slate-500">ثابت</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num text-slate-900">
                    {formatEGP(row.selling125, 'ar')}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num font-bold text-emerald-700">
                    {formatEGP(row.margin125, 'ar')}
                  </td>
                  <td className="px-4 py-2.5 text-slate-500">
                    <span className="font-mono-num">{row.latestDate}</span> · {row.sourceNote}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Purchase Invoices + Add Supplier */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 font-bold text-sm text-slate-900">
            سجل فواتير الشراء ({purchases.length})
          </div>
          {purchases.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">لا توجد فواتير شراء مسجلة.</div>
          ) : (
            <div className="divide-y divide-slate-100">
              {purchases.map((p) => {
                const rem = Math.max(0, p.total_piasters - p.paid_piasters);
                return (
                  <div key={p.id} className="p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900">
                        {p.supplier_name} ·{' '}
                        <span className="font-mono-num">{p.invoice_number}</span>
                      </div>
                      <div className="text-slate-500 font-mono-num mt-0.5">
                        {p.purchase_date} · الإجمالي: {formatEGP(p.total_piasters, 'ar')} · المسدد:{' '}
                        {formatEGP(p.paid_piasters, 'ar')}
                      </div>
                    </div>
                    {rem > 0 ? (
                      <button
                        type="button"
                        onClick={() => handlePayInvoice(p.id, rem)}
                        className="px-3 py-1.5 rounded-lg bg-[#4E3119] text-white font-bold"
                      >
                        سداد المتبقي ({formatEGP(rem, 'ar')})
                      </button>
                    ) : (
                      <span className="text-emerald-700 font-bold">مسددة بالكامل</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <form
          onSubmit={handleCreateSupplier}
          className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold text-slate-900">إضافة مورد جديد</h3>
          <input
            type="text"
            required
            value={newSupName}
            onChange={(e) => setNewSupName(e.target.value)}
            placeholder="اسم المورد أو التاجر *"
            className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
          />
          <input
            type="text"
            dir="ltr"
            value={newSupPhone}
            onChange={(e) => setNewSupPhone(e.target.value)}
            placeholder="رقم الهاتف"
            className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg text-start"
          />
          <input
            type="text"
            value={newSupAddr}
            onChange={(e) => setNewSupAddr(e.target.value)}
            placeholder="العنوان / السوق"
            className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
          />
          <button
            type="submit"
            className="w-full min-h-[40px] rounded-lg bg-slate-900 text-white font-bold"
          >
            إضافة المورد
          </button>
        </form>
      </div>
    </div>
  );
}
