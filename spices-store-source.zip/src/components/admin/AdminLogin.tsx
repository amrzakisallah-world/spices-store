import { useState } from 'react';
import { Lock, ArrowRight, Eye, EyeOff, KeyRound } from 'lucide-react';
import { api } from '../../lib/api';

interface AdminLoginProps {
  onSuccess: (user: { id: number; name: string; email: string; role: string }) => void;
  onBackToStore: () => void;
}

export function AdminLogin({ onSuccess, onBackToStore }: AdminLoginProps) {
  const [mode, setMode] = useState<'login' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Recovery form
  const [recoveryKey, setRecoveryKey] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);
    try {
      const res = await api.login(email.trim(), password);
      onSuccess(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);
    try {
      await api.resetPasswordWithKey({
        email: email.trim(),
        recovery_key: recoveryKey.trim(),
        new_password: newPassword,
      });
      setSuccessMsg('تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.');
      setPassword('');
      setRecoveryKey('');
      setNewPassword('');
      setMode('login');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إعادة تعيين كلمة المرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-[#EAE0D0] rounded-2xl p-7 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/1794927406322_2be839d2.jpg"
              alt="عمر و يونس"
              className="w-10 h-10 rounded-lg object-cover border border-[#DFD2BE]"
            />
            <div>
              <h1 className="text-lg font-extrabold text-[#2A1B0E]">إدارة متجر عمر و يونس</h1>
              <p className="text-xs text-[#6E5A44]">
                {mode === 'login' ? 'بوابة المالك الخاصة — دخول محمي' : 'إعادة تعيين كلمة المرور'}
              </p>
            </div>
          </div>
          {mode === 'login' ? (
            <Lock className="w-5 h-5 text-[#4E3119]" />
          ) : (
            <KeyRound className="w-5 h-5 text-[#4E3119]" />
          )}
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
            {successMsg}
          </div>
        )}

        {mode === 'login' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                البريد الإلكتروني للإدارة
              </label>
              <input
                type="email"
                required
                dir="ltr"
                autoCapitalize="none"
                autoCorrect="off"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@omaryounis.com"
                className="w-full min-h-[44px] px-3.5 py-2 bg-[#FAF7F2] border border-[#DFD2BE] rounded-lg text-sm text-start focus:outline-none focus:border-[#C78A1E]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  dir="ltr"
                  autoCapitalize="none"
                  autoCorrect="off"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full min-h-[44px] ps-3.5 pe-11 py-2 bg-[#FAF7F2] border border-[#DFD2BE] rounded-lg text-sm text-start focus:outline-none focus:border-[#C78A1E]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute top-1/2 -translate-y-1/2 end-2 w-9 h-9 flex items-center justify-center text-[#6E5A44] hover:text-[#2A1B0E]"
                  aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] rounded-lg bg-[#4E3119] hover:bg-[#3A2310] disabled:opacity-60 text-white font-bold text-sm transition-colors"
            >
              {loading ? 'جاري التحقق...' : 'دخول لوحة الإدارة'}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setSuccessMsg('');
                  setMode('reset');
                }}
                className="text-xs font-semibold text-[#6E5A44] hover:text-[#4E3119] underline underline-offset-4"
              >
                نسيت كلمة المرور؟ إعادة التعيين بمفتاح الاسترداد
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleReset} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                البريد الإلكتروني للإدارة
              </label>
              <input
                type="email"
                required
                dir="ltr"
                autoCapitalize="none"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@omaryounis.com"
                className="w-full min-h-[44px] px-3.5 py-2 bg-[#FAF7F2] border border-[#DFD2BE] rounded-lg text-sm text-start focus:outline-none focus:border-[#C78A1E]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                مفتاح الاسترداد (ADMIN_RESET_KEY)
              </label>
              <input
                type="password"
                required
                dir="ltr"
                value={recoveryKey}
                onChange={(e) => setRecoveryKey(e.target.value)}
                placeholder="المفتاح المضبوط في إعدادات الخادم"
                className="w-full min-h-[44px] px-3.5 py-2 bg-[#FAF7F2] border border-[#DFD2BE] rounded-lg text-sm text-start focus:outline-none focus:border-[#C78A1E]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#2A1B0E] mb-1">
                كلمة المرور الجديدة (8 أحرف فأكثر)
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  dir="ltr"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full min-h-[44px] ps-3.5 pe-11 py-2 bg-[#FAF7F2] border border-[#DFD2BE] rounded-lg text-sm text-start focus:outline-none focus:border-[#C78A1E]"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword((v) => !v)}
                  className="absolute top-1/2 -translate-y-1/2 end-2 w-9 h-9 flex items-center justify-center text-[#6E5A44] hover:text-[#2A1B0E]"
                  aria-label="إظهار أو إخفاء كلمة المرور"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] rounded-lg bg-[#4E3119] hover:bg-[#3A2310] disabled:opacity-60 text-white font-bold text-sm transition-colors"
            >
              {loading ? 'جاري التحديث...' : 'حفظ كلمة المرور الجديدة'}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('login');
                }}
                className="text-xs font-semibold text-[#4E3119] underline underline-offset-4"
              >
                العودة لتسجيل الدخول
              </button>
            </div>
          </form>
        )}

        <div className="mt-5 pt-4 border-t border-[#EAE0D0] flex items-center justify-between text-xs text-[#6E5A44]">
          <button
            type="button"
            onClick={onBackToStore}
            className="inline-flex items-center gap-1.5 font-semibold text-[#4E3119] hover:text-[#C78A1E]"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>العودة لواجهة المتجر</span>
          </button>
          <span>لا يوجد تسجيل عام للحسابات</span>
        </div>
      </div>
    </div>
  );
}
