import { useState } from 'react';
import { Search, Banknote, Truck, X } from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  fromPiasters,
  ORDER_STATUS_LABELS,
  PAYMENT_METHOD_LABELS,
  toPiasters,
  type OrderRecord,
  type OrderStatus,
  type PaymentMethod,
} from '../../shared/types';

interface OrdersTabProps {
  orders: OrderRecord[];
  onRefresh: () => void;
}

export function OrdersTab({ orders, onRefresh }: OrdersTabProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<OrderRecord | null>(null);
  const [payAmountEgp, setPayAmountEgp] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('cod');
  const [deliveryCostEgp, setDeliveryCostEgp] = useState('');
  const [feedback, setFeedback] = useState('');

  const filtered = orders.filter((o) => {
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      o.order_number.toLowerCase().includes(q) ||
      o.customer_name.toLowerCase().includes(q) ||
      o.customer_phone.includes(q) ||
      o.delivery_area.toLowerCase().includes(q)
    );
  });

  const handleStatusChange = async (order: OrderRecord, newStatus: OrderStatus) => {
    setFeedback('');
    try {
      await api.updateOrder(order.id, { status: newStatus });
      setFeedback(
        newStatus === 'cancelled'
          ? `تم إلغاء الطلب ${order.order_number} واسترجاع الكميات للمخزون.`
          : `تم تحديث حالة الطلب ${order.order_number} إلى "${ORDER_STATUS_LABELS[newStatus].ar}".`
      );
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر تحديث الطلب');
    }
  };

  const openManageOrder = (o: OrderRecord) => {
    setSelectedOrder(o);
    const remaining = Math.max(0, o.total_piasters - o.paid_piasters);
    setPayAmountEgp(String(fromPiasters(remaining)));
    setPayMethod(o.payment_method);
    setDeliveryCostEgp(String(fromPiasters(o.delivery_actual_cost_piasters)));
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;
    const amt = toPiasters(Number(payAmountEgp));
    if (amt <= 0) return;
    try {
      await api.recordOrderPayment(selectedOrder.id, {
        amount_piasters: amt,
        method: payMethod,
      });
      setFeedback(`تم تسجيل تحصيل ${formatEGP(amt, 'ar')} للطلب ${selectedOrder.order_number}`);
      setSelectedOrder(null);
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر تسجيل الدفعة');
    }
  };

  const handleSaveDeliveryCost = async () => {
    if (!selectedOrder) return;
    try {
      await api.updateOrder(selectedOrder.id, {
        status: selectedOrder.status,
        delivery_actual_cost_piasters: toPiasters(Number(deliveryCostEgp)),
      });
      setFeedback(`تم تحديث تكلفة الشحن الفعلية للطلب ${selectedOrder.order_number}`);
      setSelectedOrder(null);
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر تحديث تكلفة التوصيل');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">إدارة الطلبات والتحصيلات ({orders.length})</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            متابعة حالات التوصيل، تسجيل الدفعات المحصلة، وتكلفة المندوب الفعلية لحساب صافي الربح بدقة.
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-slate-900 text-white text-xs font-semibold flex items-center justify-between">
          <span>{feedback}</span>
          <button type="button" onClick={() => setFeedback('')}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث برقم الطلب، اسم العميل، الهاتف، المنطقة..."
            className="w-full min-h-[42px] ps-9 pe-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="min-h-[42px] px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
        >
          <option value="all">كل الحالات</option>
          {(Object.keys(ORDER_STATUS_LABELS) as OrderStatus[]).map((st) => (
            <option key={st} value={st}>
              {ORDER_STATUS_LABELS[st].ar}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-10 bg-white border border-slate-200 rounded-xl text-center text-xs text-slate-500">
            لا توجد طلبات مطابقة للبحث.
          </div>
        ) : (
          filtered.map((o) => {
            const remaining = Math.max(0, o.total_piasters - o.paid_piasters);
            const profitEst =
              o.status === 'cancelled'
                ? 0
                : o.total_piasters -
                  o.discount_piasters -
                  o.total_cost_piasters -
                  o.delivery_actual_cost_piasters;

            return (
              <div
                key={o.id}
                className="bg-white border border-slate-200 rounded-xl p-4 space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-1.5">
                      <span className="font-mono-num font-bold text-slate-900">
                        {o.order_number}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">{o.created_at.slice(0, 16)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{PAYMENT_METHOD_LABELS[o.payment_method].ar}</span>
                      {o.is_demo === 1 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-700 font-semibold">بيانات تجريبية</span>
                        </>
                      )}
                    </div>
                    <div className="text-sm font-bold text-slate-900 mt-1">
                      {o.customer_name} —{' '}
                      <span dir="ltr" className="font-mono-num text-slate-700">
                        {o.customer_phone}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {o.delivery_area} — {o.delivery_address}
                      {o.delivery_notes ? ` (${o.delivery_notes})` : ''}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <select
                      value={o.status}
                      onChange={(e) => handleStatusChange(o, e.target.value as OrderStatus)}
                      className="min-h-[38px] px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800"
                    >
                      {(Object.keys(ORDER_STATUS_LABELS) as OrderStatus[]).map((st) => (
                        <option key={st} value={st}>
                          {ORDER_STATUS_LABELS[st].ar}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => openManageOrder(o)}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg bg-[#4E3119] text-white text-xs font-bold inline-flex items-center gap-1.5"
                    >
                      <Banknote className="w-3.5 h-3.5" />
                      <span>التحصيل والشحن</span>
                    </button>
                  </div>
                </div>

                {/* Order Items */}
                {o.items && o.items.length > 0 && (
                  <div className="bg-slate-50 border border-slate-100 rounded-lg p-2.5 text-xs space-y-1">
                    {o.items.map((it) => (
                      <div key={it.id} className="flex justify-between text-slate-700">
                        <span>
                          {it.product_name_ar} ({it.variant_label_ar}) × {it.quantity}
                        </span>
                        <span className="font-mono-num">
                          {formatEGP(it.line_total_piasters, 'ar')}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
                  <div className="flex flex-wrap items-center gap-4 font-mono-num">
                    <span>
                      الإجمالي: <strong className="text-slate-900">{formatEGP(o.total_piasters, 'ar')}</strong>
                    </span>
                    <span>
                      المحصل:{' '}
                      <strong className="text-emerald-700">{formatEGP(o.paid_piasters, 'ar')}</strong>
                    </span>
                    {remaining > 0 && o.status !== 'cancelled' && (
                      <span>
                        المتبقي:{' '}
                        <strong className="text-amber-700">{formatEGP(remaining, 'ar')}</strong>
                      </span>
                    )}
                    <span>
                      تكلفة المندوب: <strong>{formatEGP(o.delivery_actual_cost_piasters, 'ar')}</strong>
                    </span>
                  </div>
                  <div className="font-mono-num">
                    صافي ربح الطلب:{' '}
                    <strong className={profitEst >= 0 ? 'text-emerald-700' : 'text-red-700'}>
                      {formatEGP(profitEst, 'ar')}
                    </strong>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Payment & Delivery Cost Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45">
          <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                تحصيل وتكلفة شحن — {selectedOrder.order_number}
              </h3>
              <button type="button" onClick={() => setSelectedOrder(null)}>
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <div className="p-5 space-y-5 text-sm">
              <form onSubmit={handleRecordPayment} className="space-y-3">
                <div className="text-xs font-bold text-slate-800">تسجيل دفعة محصلة من العميل</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">المبلغ (ج.م)</label>
                    <input
                      type="number"
                      step="0.5"
                      min="1"
                      required
                      value={payAmountEgp}
                      onChange={(e) => setPayAmountEgp(e.target.value)}
                      className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">الوسيلة</label>
                    <select
                      value={payMethod}
                      onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                      className="w-full min-h-[40px] px-2 border border-slate-200 rounded-lg bg-white text-xs"
                    >
                      {(Object.keys(PAYMENT_METHOD_LABELS) as PaymentMethod[]).map((m) => (
                        <option key={m} value={m}>
                          {PAYMENT_METHOD_LABELS[m].ar}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full min-h-[40px] rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold"
                >
                  تأكيد استلام الدفعة
                </button>
              </form>

              <div className="pt-4 border-t border-slate-200 space-y-2.5">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Truck className="w-4 h-4" />
                  <span>تكلفة الشحن / المندوب الفعلية المدفوعة (ج.م)</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="1"
                    min="0"
                    value={deliveryCostEgp}
                    onChange={(e) => setDeliveryCostEgp(e.target.value)}
                    className="flex-1 min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                  />
                  <button
                    type="button"
                    onClick={handleSaveDeliveryCost}
                    className="px-4 py-2 rounded-lg bg-[#4E3119] text-white text-xs font-bold"
                  >
                    حفظ
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
