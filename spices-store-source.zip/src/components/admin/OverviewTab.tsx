import { useState } from 'react';
import { AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import {
  formatEGP,
  ORDER_STATUS_LABELS,
  type DashboardSummary,
} from '../../shared/types';

interface OverviewTabProps {
  data: DashboardSummary;
  onNavigateTab: (tab: string) => void;
}

type PeriodKey = 'today' | 'week' | 'month' | 'year' | 'all_time';

const PERIOD_LABELS: Record<PeriodKey, string> = {
  today: 'اليوم',
  week: 'آخر 7 أيام',
  month: 'هذا الشهر',
  year: 'هذا العام',
  all_time: 'الإجمالي الكلي',
};

export function OverviewTab({ data, onNavigateTab }: OverviewTabProps) {
  const [period, setPeriod] = useState<PeriodKey>('month');
  const metrics = data.periods[period];

  const maxDailyRev = Math.max(
    10000,
    ...data.dailySeries.map((d) => Math.max(d.revenuePiasters, Math.abs(d.netProfitPiasters)))
  );

  const renderDelta = (pct: number | null) => {
    if (pct === null) return <span className="text-xs text-slate-500">لا توجد بيانات شهر سابق</span>;
    const positive = pct >= 0;
    return (
      <span
        className={`inline-flex items-center gap-1 text-xs font-semibold font-mono-num ${
          positive ? 'text-emerald-700' : 'text-red-700'
        }`}
      >
        {positive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
        {positive ? `+${pct}%` : `${pct}%`} عن الشهر السابق
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Period Selector */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">ملخص الأداء المالي والتشغيلي</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            الأرقام تفرّق بدقة بين إجمالي المبيعات (الإيرادات) والربح الفعلي بعد تكلفة البضاعة والمصروفات.
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg overflow-x-auto">
          {(Object.keys(PERIOD_LABELS) as PeriodKey[]).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setPeriod(key)}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors whitespace-nowrap ${
                period === key
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {PERIOD_LABELS[key]}
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">إجمالي المبيعات (الإيرادات)</div>
          <div className="text-xl font-extrabold font-mono-num text-slate-900 mt-1">
            {formatEGP(metrics.revenuePiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-mono-num">
            {metrics.ordersCount} طلب · {metrics.completedOrdersCount} مكتمل
          </div>
          {period === 'month' && <div className="mt-1.5">{renderDelta(data.prevMonthComparison.revenueDeltaPct)}</div>}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">تكلفة البضاعة والتوصيل (COGS)</div>
          <div className="text-xl font-extrabold font-mono-num text-slate-900 mt-1">
            {formatEGP(metrics.cogsPiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            محسوبة بالتكلفة المسجلة وقت كل طلب
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">مجمل الربح (قبل المصروفات)</div>
          <div className="text-xl font-extrabold font-mono-num text-emerald-700 mt-1">
            {formatEGP(metrics.grossProfitPiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-mono-num">
            هامش:{' '}
            {metrics.revenuePiasters > 0
              ? `${Math.round((metrics.grossProfitPiasters / metrics.revenuePiasters) * 100)}%`
              : '0%'}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">المصروفات التشغيلية</div>
          <div className="text-xl font-extrabold font-mono-num text-amber-700 mt-1">
            {formatEGP(metrics.operatingExpensesPiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-500 mt-1">تغليف، تسويق، شحن، مرافق</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">صافي الربح الفعلي</div>
          <div
            className={`text-xl font-extrabold font-mono-num mt-1 ${
              metrics.netProfitPiasters >= 0 ? 'text-emerald-700' : 'text-red-700'
            }`}
          >
            {formatEGP(metrics.netProfitPiasters, 'ar')}
          </div>
          {period === 'month' && <div className="mt-1.5">{renderDelta(data.prevMonthComparison.profitDeltaPct)}</div>}
        </div>
      </div>

      {/* Cash Position & Balance Sheet Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 text-white rounded-xl p-4">
          <div className="text-xs text-slate-300">صافي رصيد السيولة المسجل</div>
          <div className="text-xl font-extrabold font-mono-num mt-1">
            {formatEGP(data.cashBalancePiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono-num">
            تحصيلات الفترة: {formatEGP(metrics.cashCollectedPiasters, 'ar')}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">مبالغ غير محصلة من العملاء</div>
          <div className="text-xl font-extrabold font-mono-num text-amber-700 mt-1">
            {formatEGP(data.outstandingReceivablesPiasters, 'ar')}
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('orders')}
            className="text-xs text-[#4E3119] font-bold hover:underline mt-1"
          >
            مراجعة التحصيلات في الطلبات ←
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">مستحقات آجلة للموردين</div>
          <div className="text-xl font-extrabold font-mono-num text-red-700 mt-1">
            {formatEGP(data.supplierPayablesPiasters, 'ar')}
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('suppliers')}
            className="text-xs text-[#4E3119] font-bold hover:underline mt-1"
          >
            إدارة فواتير الحراز والموردين ←
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">تقييم المخزون الحالي (بالتكلفة)</div>
          <div className="text-xl font-extrabold font-mono-num text-slate-900 mt-1">
            {formatEGP(data.inventoryValuationCostPiasters, 'ar')}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-mono-num">
            قيمة البيع المتوقعة: {formatEGP(data.inventoryValuationRetailPiasters, 'ar')}
          </div>
        </div>
      </div>

      {/* 14-Day Chart + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">حركة المبيعات وصافي الربح (آخر 14 يوم)</h3>
              <p className="text-xs text-slate-500">العمود البني: المبيعات · العمود الأخضر: صافي الربح</p>
            </div>
          </div>
          <div className="h-52 flex items-end gap-1.5 border-b border-slate-200 pb-2">
            {data.dailySeries.map((day) => {
              const revH = Math.max(4, Math.round((day.revenuePiasters / maxDailyRev) * 100));
              const profH = Math.max(
                4,
                Math.round((Math.max(0, day.netProfitPiasters) / maxDailyRev) * 100)
              );
              return (
                <div key={day.date} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                  <div className="w-full flex items-end justify-center gap-0.5 h-40">
                    <div
                      title={`${day.date} مبيعات: ${formatEGP(day.revenuePiasters, 'ar')}`}
                      style={{ height: `${revH}%` }}
                      className="w-1/2 max-w-[14px] bg-[#4E3119] rounded-t"
                    />
                    <div
                      title={`${day.date} صافي ربح: ${formatEGP(day.netProfitPiasters, 'ar')}`}
                      style={{ height: `${profH}%` }}
                      className="w-1/2 max-w-[14px] bg-[#68782C] rounded-t"
                    />
                  </div>
                  <span className="text-[10px] font-mono-num text-slate-500">
                    {day.date.slice(5)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Business Alerts */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">تنبيهات العمل الهامة</h3>
          {data.alerts.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              لا توجد تنبيهات عاجلة حالياً — جميع المؤشرات مستقرة.
            </p>
          ) : (
            <div className="space-y-2.5">
              {data.alerts.map((al, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-lg border text-xs ${
                    al.level === 'danger'
                      ? 'bg-red-50 border-red-200 text-red-900'
                      : al.level === 'warning'
                      ? 'bg-amber-50 border-amber-200 text-amber-900'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{al.titleAr}</span>
                  </div>
                  <p className="mt-1 opacity-90">{al.detailAr}</p>
                  {al.actionTab && (
                    <button
                      type="button"
                      onClick={() => onNavigateTab(al.actionTab!)}
                      className="mt-1.5 font-bold underline"
                    >
                      عرض التفاصيل
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Low Stock + Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">تنبيهات انخفاض المخزون</h3>
            <button
              type="button"
              onClick={() => onNavigateTab('products')}
              className="text-xs font-bold text-[#4E3119] hover:underline"
            >
              إدارة المخزون
            </button>
          </div>
          {data.lowStockProducts.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              جميع الأصناف فوق الحد الأدنى للمخزون.
            </div>
          ) : (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="text-start px-4 py-2.5 font-bold">الصنف</th>
                  <th className="text-end px-4 py-2.5 font-bold">المتاح (تمن كيلو)</th>
                  <th className="text-end px-4 py-2.5 font-bold">الحد الأدنى</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.lowStockProducts.map((p) => (
                  <tr key={p.id}>
                    <td className="px-4 py-2.5 font-semibold text-slate-900">{p.name_ar}</td>
                    <td className="px-4 py-2.5 text-end font-mono-num text-red-700 font-bold">
                      {p.stock_units} ({p.stock_units * 125} جم)
                    </td>
                    <td className="px-4 py-2.5 text-end font-mono-num text-slate-500">
                      {p.low_stock_threshold}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">أحدث الطلبات</h3>
            <button
              type="button"
              onClick={() => onNavigateTab('orders')}
              className="text-xs font-bold text-[#4E3119] hover:underline"
            >
              كل الطلبات
            </button>
          </div>
          {data.recentOrders.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">لا توجد طلبات مسجلة بعد.</div>
          ) : (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="text-start px-4 py-2.5 font-bold">الطلب</th>
                  <th className="text-start px-4 py-2.5 font-bold">العميل</th>
                  <th className="text-start px-4 py-2.5 font-bold">الحالة</th>
                  <th className="text-end px-4 py-2.5 font-bold">الإجمالي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.recentOrders.map((o) => (
                  <tr key={o.id}>
                    <td className="px-4 py-2.5 font-mono-num font-bold text-slate-900">
                      {o.order_number}
                    </td>
                    <td className="px-4 py-2.5 text-slate-700">{o.customer_name}</td>
                    <td className="px-4 py-2.5 text-slate-700">
                      {ORDER_STATUS_LABELS[o.status].ar}
                    </td>
                    <td className="px-4 py-2.5 text-end font-mono-num font-bold text-slate-900">
                      {formatEGP(o.total_piasters, 'ar')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
