import { useEffect, useState } from 'react';
import { Download, Plus, Trash2 } from 'lucide-react';
import { api } from '../../lib/api';
import {
  EXPENSE_CATEGORY_LABELS,
  formatEGP,
  toPiasters,
  type ExpenseCategory,
  type ExpenseRecord,
  type FinancialRecord,
} from '../../shared/types';

export function FinanceTab({ onDashboardNeedsRefresh }: { onDashboardNeedsRefresh: () => void }) {
  const todayStr = new Date().toISOString().slice(0, 10);
  const ninetyDaysAgoStr = new Date(Date.now() - 90 * 86400000).toISOString().slice(0, 10);

  const [from, setFrom] = useState(ninetyDaysAgoStr);
  const [to, setTo] = useState(todayStr);
  const [loading, setLoading] = useState(true);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [ledger, setLedger] = useState<FinancialRecord[]>([]);
  const [expenseByCat, setExpenseByCat] = useState<
    Array<{ category: ExpenseCategory; total_piasters: number }>
  >([]);
  const [pnl, setPnl] = useState({
    ordersCount: 0,
    revenuePiasters: 0,
    cogsPiasters: 0,
    grossProfitPiasters: 0,
    operatingExpensesPiasters: 0,
    netProfitPiasters: 0,
    totalInflowPiasters: 0,
    totalOutflowPiasters: 0,
    netCashFlowPiasters: 0,
  });

  // Add Expense form
  const [expTitle, setExpTitle] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseCategory>('packaging');
  const [expAmountEgp, setExpAmountEgp] = useState('');
  const [expDate, setExpDate] = useState(todayStr);
  const [expNotes, setExpNotes] = useState('');

  // Add Manual Income form
  const [incTitle, setIncTitle] = useState('');
  const [incAmountEgp, setIncAmountEgp] = useState('');
  const [incDate, setIncDate] = useState(todayStr);

  const loadFinance = async () => {
    setLoading(true);
    try {
      const res = await api.getFinance(from, to);
      setExpenses(res.expenses);
      setLedger(res.ledger);
      setExpenseByCat(res.expenseByCategory);
      setPnl(res.pnl);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFinance();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from, to]);

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = toPiasters(Number(expAmountEgp));
    if (amt <= 0) return;
    await api.createExpense({
      category: expCategory,
      title: expTitle,
      amount_piasters: amt,
      payment_method: 'cash',
      expense_date: expDate,
      notes: expNotes,
    });
    setExpTitle('');
    setExpAmountEgp('');
    setExpNotes('');
    await loadFinance();
    onDashboardNeedsRefresh();
  };

  const handleDeleteExpense = async (id: number) => {
    await api.deleteExpense(id);
    await loadFinance();
    onDashboardNeedsRefresh();
  };

  const handleAddIncome = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = toPiasters(Number(incAmountEgp));
    if (amt <= 0) return;
    await api.createIncome({
      title: incTitle,
      amount_piasters: amt,
      payment_method: 'cash',
      record_date: incDate,
    });
    setIncTitle('');
    setIncAmountEgp('');
    await loadFinance();
    onDashboardNeedsRefresh();
  };

  return (
    <div className="space-y-6">
      {/* Header & Date Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">
            المصروفات والتقارير المالية والأرباح والخسائر
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            تقرير الأرباح والخسائر (P&L) وحركة الخزينة والتدفقات النقدية لأي فترة زمنية.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="min-h-[38px] px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono-num"
          />
          <span className="text-xs text-slate-500">إلى</span>
          <input
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="min-h-[38px] px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono-num"
          />
          <a
            href={`/api/admin/finance/export?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`}
            className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold inline-flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير CSV</span>
          </a>
        </div>
      </div>

      {/* P&L Statement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            قائمة الدخل والأرباح والخسائر (P&L) للفترة
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1">
              <span className="text-slate-600">إجمالي المبيعات ({pnl.ordersCount} طلب)</span>
              <span className="font-mono-num font-bold text-slate-900">
                {formatEGP(pnl.revenuePiasters, 'ar')}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-600">(-) تكلفة البضاعة المباعة والشحن الفعلي</span>
              <span className="font-mono-num text-red-700">
                {formatEGP(pnl.cogsPiasters, 'ar')}
              </span>
            </div>
            <div className="flex justify-between py-2 border-y border-slate-100 font-bold">
              <span className="text-slate-900">(=) مجمل الربح (Gross Profit)</span>
              <span className="font-mono-num text-emerald-700">
                {formatEGP(pnl.grossProfitPiasters, 'ar')}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-600">(-) المصروفات التشغيلية</span>
              <span className="font-mono-num text-amber-700">
                {formatEGP(pnl.operatingExpensesPiasters, 'ar')}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-extrabold">
              <span className="text-slate-900">(=) صافي الربح (Net Profit)</span>
              <span
                className={`font-mono-num ${
                  pnl.netProfitPiasters >= 0 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {formatEGP(pnl.netProfitPiasters, 'ar')}
              </span>
            </div>
          </div>
        </div>

        {/* Cash Flow & Expense Breakdown */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            حركة الخزينة والتدفقات النقدية
          </h3>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
              <div className="text-[11px] text-emerald-800">إجمالي الداخل</div>
              <div className="text-sm font-extrabold font-mono-num text-emerald-900 mt-1">
                {formatEGP(pnl.totalInflowPiasters, 'ar')}
              </div>
            </div>
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="text-[11px] text-red-800">إجمالي الخارج</div>
              <div className="text-sm font-extrabold font-mono-num text-red-900 mt-1">
                {formatEGP(pnl.totalOutflowPiasters, 'ar')}
              </div>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="text-[11px] text-slate-600">صافي التدفق</div>
              <div className="text-sm font-extrabold font-mono-num text-slate-900 mt-1">
                {formatEGP(pnl.netCashFlowPiasters, 'ar')}
              </div>
            </div>
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="font-bold text-slate-700">توزيع المصروفات حسب التصنيف:</div>
            {expenseByCat.length === 0 ? (
              <p className="text-slate-400">لا توجد مصروفات في هذه الفترة.</p>
            ) : (
              expenseByCat.map((c) => (
                <div key={c.category} className="flex justify-between text-slate-700">
                  <span>{EXPENSE_CATEGORY_LABELS[c.category]?.ar || c.category}</span>
                  <span className="font-mono-num font-bold">
                    {formatEGP(c.total_piasters, 'ar')}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Add Expense & Manual Income */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={handleAddExpense}
          className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold text-slate-900">تسجيل مصروف جديد</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">البند / الوصف *</label>
              <input
                type="text"
                required
                value={expTitle}
                onChange={(e) => setExpTitle(e.target.value)}
                placeholder="مثال: أكياس تغليف أو شحن"
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">التصنيف</label>
              <select
                value={expCategory}
                onChange={(e) => setExpCategory(e.target.value as ExpenseCategory)}
                className="w-full min-h-[38px] px-2 border border-slate-200 rounded-lg bg-white"
              >
                {(Object.keys(EXPENSE_CATEGORY_LABELS) as ExpenseCategory[]).map((cat) => (
                  <option key={cat} value={cat}>
                    {EXPENSE_CATEGORY_LABELS[cat].ar}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">المبلغ (ج.م) *</label>
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={expAmountEgp}
                onChange={(e) => setExpAmountEgp(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">التاريخ</label>
              <input
                type="date"
                required
                value={expDate}
                onChange={(e) => setExpDate(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
          </div>
          <input
            type="text"
            value={expNotes}
            onChange={(e) => setExpNotes(e.target.value)}
            placeholder="ملاحظات إضافية (اختياري)"
            className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
          />
          <button
            type="submit"
            className="min-h-[40px] px-4 py-2 rounded-lg bg-[#4E3119] text-white font-bold inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>حفظ المصروف</span>
          </button>
        </form>

        <form
          onSubmit={handleAddIncome}
          className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs"
        >
          <h3 className="text-sm font-bold text-slate-900">تسجيل إيراد أو إيداع نقدي خارج الطلبات</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">البيان *</label>
              <input
                type="text"
                required
                value={incTitle}
                onChange={(e) => setIncTitle(e.target.value)}
                placeholder="مثال: بيع مباشر بالمحل أو إيداع رأس مال"
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">المبلغ (ج.م) *</label>
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={incAmountEgp}
                onChange={(e) => setIncAmountEgp(e.target.value)}
                className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
              />
            </div>
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">التاريخ</label>
            <input
              type="date"
              required
              value={incDate}
              onChange={(e) => setIncDate(e.target.value)}
              className="w-full min-h-[38px] px-3 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>
          <button
            type="submit"
            className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل حركة دخل</span>
          </button>
        </form>
      </div>

      {/* Expenses List & Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 font-bold text-sm text-slate-900">
            سجل المصروفات ({expenses.length})
          </div>
          {loading ? (
            <div className="p-6 text-center text-xs text-slate-400">جاري التحميل...</div>
          ) : expenses.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">لا توجد مصروفات مسجلة.</div>
          ) : (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="text-start px-3 py-2">التاريخ</th>
                  <th className="text-start px-3 py-2">البند</th>
                  <th className="text-end px-3 py-2">المبلغ</th>
                  <th className="px-2 py-2"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses.map((ex) => (
                  <tr key={ex.id}>
                    <td className="px-3 py-2 font-mono-num text-slate-500">{ex.expense_date}</td>
                    <td className="px-3 py-2">
                      <div className="font-semibold text-slate-900">{ex.title}</div>
                      <div className="text-[11px] text-slate-500">
                        {EXPENSE_CATEGORY_LABELS[ex.category]?.ar}
                      </div>
                    </td>
                    <td className="px-3 py-2 text-end font-mono-num font-bold text-red-700">
                      {formatEGP(ex.amount_piasters, 'ar')}
                    </td>
                    <td className="px-2 py-2 text-end">
                      <button
                        type="button"
                        onClick={() => handleDeleteExpense(ex.id)}
                        className="p-1.5 text-slate-400 hover:text-red-700"
                        title="حذف المصروف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 font-bold text-sm text-slate-900">
            دفتر الحركات النقدية ({ledger.length})
          </div>
          {ledger.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">لا توجد حركات نقدية.</div>
          ) : (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="text-start px-3 py-2">التاريخ</th>
                  <th className="text-start px-3 py-2">البيان</th>
                  <th className="text-end px-3 py-2">المبلغ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledger.map((row) => (
                  <tr key={row.id}>
                    <td className="px-3 py-2 font-mono-num text-slate-500">{row.record_date}</td>
                    <td className="px-3 py-2 text-slate-900 font-medium">{row.title}</td>
                    <td
                      className={`px-3 py-2 text-end font-mono-num font-bold ${
                        row.record_type === 'inflow' ? 'text-emerald-700' : 'text-red-700'
                      }`}
                    >
                      {row.record_type === 'inflow' ? '+' : '-'}
                      {formatEGP(row.amount_piasters, 'ar')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
