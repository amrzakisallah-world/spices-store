import { useState } from 'react';
import { Plus, Search, Pencil, Trash2, Upload, X } from 'lucide-react';
import { api } from '../../lib/api';
import {
  formatEGP,
  fromPiasters,
  toPiasters,
  type Category,
  type Product,
} from '../../shared/types';
import { ResilientImage } from '../ResilientImage';

interface ProductsTabProps {
  products: Product[];
  categories: Category[];
  onRefresh: () => void;
}

export function ProductsTab({ products, categories, onRefresh }: ProductsTabProps) {
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploadingId, setUploadingId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState('');

  // Form fields
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [categoryId, setCategoryId] = useState<number>(categories[0]?.id || 1);
  const [descriptionAr, setDescriptionAr] = useState('');
  const [sellingEgp, setSellingEgp] = useState('50');
  const [costEgp, setCostEgp] = useState('35');
  const [stockUnits, setStockUnits] = useState('30');
  const [lowThreshold, setLowThreshold] = useState('12');
  const [isActive, setIsActive] = useState(1);
  const [isFeatured, setIsFeatured] = useState(0);
  const [isNew, setIsNew] = useState(0);

  const openCreate = () => {
    setEditing(null);
    setNameAr('');
    setNameEn('');
    setCategoryId(categories[0]?.id || 1);
    setDescriptionAr('');
    setSellingEgp('50');
    setCostEgp('35');
    setStockUnits('30');
    setLowThreshold('12');
    setIsActive(1);
    setIsFeatured(0);
    setIsNew(1);
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setNameAr(p.name_ar);
    setNameEn(p.name_en);
    setCategoryId(p.category_id);
    setDescriptionAr(p.description_ar);
    setSellingEgp(String(fromPiasters(p.selling_price_piasters)));
    setCostEgp(String(fromPiasters(p.cost_price_piasters)));
    setStockUnits(String(p.stock_units));
    setLowThreshold(String(p.low_stock_threshold));
    setIsActive(p.is_active);
    setIsFeatured(p.is_featured);
    setIsNew(p.is_new);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setFeedback('');
    try {
      const payload = {
        name_ar: nameAr,
        name_en: nameEn,
        category_id: Number(categoryId),
        description_ar: descriptionAr,
        selling_price_piasters: toPiasters(Number(sellingEgp)),
        cost_price_piasters: toPiasters(Number(costEgp)),
        stock_units: Math.max(0, Math.round(Number(stockUnits))),
        low_stock_threshold: Math.max(0, Math.round(Number(lowThreshold))),
        is_active: isActive,
        is_featured: isFeatured,
        is_new: isNew,
      };
      if (editing) {
        await api.updateProduct(editing.id, payload);
        setFeedback(`تم تحديث "${nameAr}" بنجاح`);
      } else {
        await api.createProduct(payload);
        setFeedback(`تمت إضافة "${nameAr}" للمتجر بنجاح`);
      }
      setModalOpen(false);
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'حدث خطأ أثناء الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (p: Product) => {
    try {
      const res = await api.deleteProduct(p.id);
      setFeedback(
        res.softDeleted
          ? res.message || `تم إيقاف "${p.name_ar}" عن المتجر.`
          : `تم حذف "${p.name_ar}" نهائياً.`
      );
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر حذف المنتج');
    }
  };

  const handleUploadImage = async (product: Product, file: File) => {
    setUploadingId(product.id);
    setFeedback('');
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('تعذر قراءة الملف'));
        reader.readAsDataURL(file);
      });
      await api.uploadProductImage(product.id, dataUrl, product.name_ar);
      setFeedback(`تم رفع صورة جديدة لـ "${product.name_ar}"`);
      onRefresh();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'تعذر رفع الصورة');
    } finally {
      setUploadingId(null);
    }
  };

  const filtered = products.filter((p) => {
    if (catFilter !== 'all' && String(p.category_id) !== catFilter) return false;
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return p.name_ar.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">
            إدارة المنتجات والأسعار والمخزون ({products.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            الأسعار والتكاليف بوحدة التمن كيلو (125 جم). أي تعديل في السعر يتم حفظه تلقائياً في سجل التاريخ السعري.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="min-h-[42px] px-4 py-2 rounded-lg bg-[#4E3119] hover:bg-[#3A2310] text-white text-xs font-bold inline-flex items-center gap-2 whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة منتج جديد</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-slate-900 text-white text-xs font-semibold flex items-center justify-between">
          <span>{feedback}</span>
          <button type="button" onClick={() => setFeedback('')}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search & Category Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث باسم الصنف أو الكود..."
            className="w-full min-h-[42px] ps-9 pe-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
          />
        </div>
        <select
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="min-h-[42px] px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
        >
          <option value="all">كل التصنيفات</option>
          {categories.map((c) => (
            <option key={c.id} value={String(c.id)}>
              {c.name_ar}
            </option>
          ))}
        </select>
      </div>

      {/* Product Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-xs min-w-[780px]">
          <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
            <tr>
              <th className="text-start px-4 py-3 font-bold">المنتج</th>
              <th className="text-start px-3 py-3 font-bold">التصنيف</th>
              <th className="text-end px-3 py-3 font-bold">سعر البيع (125 جم)</th>
              <th className="text-end px-3 py-3 font-bold">تكلفة الشراء</th>
              <th className="text-end px-3 py-3 font-bold">هامش الربح</th>
              <th className="text-end px-3 py-3 font-bold">المخزون (تمن)</th>
              <th className="text-start px-3 py-3 font-bold">الحالة</th>
              <th className="text-end px-4 py-3 font-bold">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((p) => {
              const margin = p.selling_price_piasters - p.cost_price_piasters;
              const marginPct =
                p.selling_price_piasters > 0
                  ? Math.round((margin / p.selling_price_piasters) * 100)
                  : 0;
              const low = p.stock_units <= p.low_stock_threshold;

              return (
                <tr key={p.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <ResilientImage
                        src={p.primary_image}
                        alt={p.name_ar}
                        className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0"
                      />
                      <div>
                        <div className="font-bold text-slate-900">{p.name_ar}</div>
                        <div className="text-[11px] text-slate-500 font-mono-num">{p.sku}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-slate-600">{p.category_name_ar}</td>
                  <td className="px-3 py-2.5 text-end font-mono-num font-bold text-slate-900">
                    {formatEGP(p.selling_price_piasters, 'ar')}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num text-slate-600">
                    {formatEGP(p.cost_price_piasters, 'ar')}
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num">
                    <span className={margin >= 0 ? 'text-emerald-700 font-semibold' : 'text-red-700'}>
                      {formatEGP(margin, 'ar')} ({marginPct}%)
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-end font-mono-num">
                    <span className={low ? 'text-red-700 font-bold' : 'text-slate-900'}>
                      {p.stock_units}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className={p.is_active ? 'text-emerald-700 font-semibold' : 'text-slate-400'}>
                      {p.is_active ? 'نشط' : 'موقوف'}
                    </span>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-1.5">
                      <label
                        className="p-2 rounded border border-slate-200 hover:bg-slate-100 cursor-pointer text-slate-700"
                        title="رفع صورة للمنتج"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          className="hidden"
                          disabled={uploadingId === p.id}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) handleUploadImage(p, f);
                          }}
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => openEdit(p)}
                        className="p-2 rounded border border-slate-200 hover:bg-slate-100 text-slate-700"
                        title="تعديل"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(p)}
                        className="p-2 rounded border border-slate-200 hover:bg-red-50 text-red-700"
                        title="حذف / إيقاف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editing ? `تعديل: ${editing.name_ar}` : 'إضافة منتج جديد'}
              </h3>
              <button type="button" onClick={() => setModalOpen(false)}>
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-5 space-y-3.5 max-h-[80vh] overflow-y-auto text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">الاسم بالعربية *</label>
                  <input
                    type="text"
                    required
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">الاسم بالإنجليزية</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">التصنيف *</label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg bg-white"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name_ar}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">سعر البيع (ج.م)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required
                    value={sellingEgp}
                    onChange={(e) => setSellingEgp(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تكلفة الشراء (ج.م)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required
                    value={costEgp}
                    onChange={(e) => setCostEgp(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">المخزون (تمن)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={stockUnits}
                    onChange={(e) => setStockUnits(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">حد التنبيه</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={lowThreshold}
                    onChange={(e) => setLowThreshold(e.target.value)}
                    className="w-full min-h-[40px] px-3 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الوصف</label>
                <textarea
                  rows={2}
                  value={descriptionAr}
                  onChange={(e) => setDescriptionAr(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="flex flex-wrap gap-4 pt-1 text-xs font-semibold text-slate-700">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive === 1}
                    onChange={(e) => setIsActive(e.target.checked ? 1 : 0)}
                  />
                  <span>نشط بالمتجر</span>
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured === 1}
                    onChange={(e) => setIsFeatured(e.target.checked ? 1 : 0)}
                  />
                  <span>صنف مميز</span>
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isNew === 1}
                    onChange={(e) => setIsNew(e.target.checked ? 1 : 0)}
                  />
                  <span>صنف جديد</span>
                </label>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-700"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-lg bg-[#4E3119] text-white text-xs font-bold"
                >
                  {saving ? 'جاري الحفظ...' : 'حفظ المنتج'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
