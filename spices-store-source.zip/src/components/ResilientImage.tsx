import { useState } from 'react';
import { Sparkles } from 'lucide-react';

interface ResilientImageProps {
  src?: string | null;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export function ResilientImage({ src, alt, className = '', fallbackLabel }: ResilientImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#F3ECE0] to-[#E6D9C3] text-[#6B4B2A] ${className}`}
        role="img"
        aria-label={alt}
      >
        <Sparkles className="w-7 h-7 opacity-60 mb-1.5" strokeWidth={1.5} />
        <span className="text-xs font-medium px-3 text-center line-clamp-2">
          {fallbackLabel || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      loading="lazy"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
