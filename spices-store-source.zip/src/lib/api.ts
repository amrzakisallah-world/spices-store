import type {
  Category,
  DashboardSummary,
  ExpenseCategory,
  ExpenseRecord,
  FinancialRecord,
  OrderRecord,
  OrderStatus,
  PaymentMethod,
  Product,
  StorePublicConfig,
  Supplier,
  SupplierPriceRecord,
} from '../shared/types';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {}),
    },
    ...options,
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    const message =
      typeof data === 'object' && data !== null && 'error' in data
        ? String((data as { error: string }).error)
        : `خطأ في الاتصال (${res.status})`;
    throw new Error(message);
  }

  return data as T;
}

export const api = {
  // Public
  getPublicConfig: () => request<StorePublicConfig>('/api/public/config'),
  getCategories: () => request<{ categories: Category[] }>('/api/public/categories'),
  getProducts: (params?: { q?: string; category?: string; featured?: boolean }) => {
    const sp = new URLSearchParams();
    if (params?.q) sp.set('q', params.q);
    if (params?.category && params.category !== 'all') sp.set('category', params.category);
    if (params?.featured) sp.set('featured', '1');
    const qs = sp.toString();
    return request<{ products: Product[] }>(`/api/public/products${qs ? `?${qs}` : ''}`);
  },
  getProductDetail: (id: number) => request<{ product: Product }>(`/api/public/products/${id}`),
  createOrder: (payload: {
    customer_name: string;
    customer_phone: string;
    delivery_area: string;
    delivery_address: string;
    delivery_notes?: string;
    payment_method: PaymentMethod;
    items: Array<{ product_id: number; weight_grams: number; quantity: number }>;
    website_url?: string;
  }) =>
    request<{
      order: {
        order_number: string;
        tracking_code: string;
        status: OrderStatus;
        subtotal_piasters: number;
        delivery_fee_piasters: number;
        total_piasters: number;
        payment_method: PaymentMethod;
      };
    }>('/api/public/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  trackOrder: (code: string, phone: string) =>
    request<{ order: OrderRecord }>(
      `/api/public/orders/track?code=${encodeURIComponent(code)}&phone=${encodeURIComponent(phone)}`
    ),

  // Auth
  login: (email: string, password: string) =>
    request<{ user: { id: number; name: string; email: string; role: string } }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  getMe: () =>
    request<{ user: { id: number; name: string; email: string; role: string } }>('/api/auth/me'),
  changePassword: (current_password: string, new_password: string) =>
    request<{ ok: boolean }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ current_password, new_password }),
    }),
  resetPasswordWithKey: (payload: {
    email: string;
    recovery_key: string;
    new_password: string;
  }) =>
    request<{ ok: boolean }>('/api/auth/reset-with-key', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Admin
  getDashboard: () => request<DashboardSummary>('/api/admin/dashboard'),
  getAdminCategories: () => request<{ categories: Category[] }>('/api/admin/categories'),
  createCategory: (payload: { name_ar: string; name_en: string; description_ar?: string }) =>
    request<{ id: number }>('/api/admin/categories', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getAdminProducts: () => request<{ products: Product[] }>('/api/admin/products'),
  createProduct: (payload: {
    name_ar: string;
    name_en?: string;
    category_id: number;
    description_ar?: string;
    selling_price_piasters: number;
    cost_price_piasters: number;
    stock_units: number;
    low_stock_threshold: number;
    is_active: number;
    is_featured: number;
    is_new: number;
    image_url?: string;
  }) =>
    request<{ id: number }>('/api/admin/products', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateProduct: (
    id: number,
    payload: {
      name_ar: string;
      name_en?: string;
      category_id: number;
      description_ar?: string;
      selling_price_piasters: number;
      cost_price_piasters: number;
      stock_units: number;
      low_stock_threshold: number;
      is_active: number;
      is_featured: number;
      is_new: number;
      price_change_reason?: string;
    }
  ) =>
    request<{ ok: boolean }>(`/api/admin/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteProduct: (id: number) =>
    request<{ ok: boolean; softDeleted: boolean; message?: string }>(`/api/admin/products/${id}`, {
      method: 'DELETE',
    }),
  uploadProductImage: (id: number, data_url: string, alt_text?: string) =>
    request<{ image_url: string }>(`/api/admin/products/${id}/upload-image`, {
      method: 'POST',
      body: JSON.stringify({ data_url, alt_text }),
    }),

  getAdminOrders: (params?: { status?: string; q?: string }) => {
    const sp = new URLSearchParams();
    if (params?.status && params.status !== 'all') sp.set('status', params.status);
    if (params?.q) sp.set('q', params.q);
    const qs = sp.toString();
    return request<{ orders: OrderRecord[] }>(`/api/admin/orders${qs ? `?${qs}` : ''}`);
  },
  updateOrder: (
    id: number,
    payload: {
      status: OrderStatus;
      delivery_actual_cost_piasters?: number;
      discount_piasters?: number;
      delivery_notes?: string;
    }
  ) =>
    request<{ ok: boolean }>(`/api/admin/orders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  recordOrderPayment: (
    id: number,
    payload: {
      amount_piasters: number;
      method: PaymentMethod;
      reference_number?: string;
      notes?: string;
    }
  ) =>
    request<{ ok: boolean; paid_piasters: number; payment_status: string }>(
      `/api/admin/orders/${id}/payments`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),

  getFinance: (from: string, to: string) =>
    request<{
      range: { from: string; to: string };
      expenses: ExpenseRecord[];
      ledger: FinancialRecord[];
      expenseByCategory: Array<{ category: ExpenseCategory; total_piasters: number }>;
      pnl: {
        ordersCount: number;
        revenuePiasters: number;
        cogsPiasters: number;
        grossProfitPiasters: number;
        operatingExpensesPiasters: number;
        netProfitPiasters: number;
        totalInflowPiasters: number;
        totalOutflowPiasters: number;
        netCashFlowPiasters: number;
      };
    }>(`/api/admin/finance?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`),
  createExpense: (payload: {
    category: ExpenseCategory;
    title: string;
    amount_piasters: number;
    payment_method: string;
    supplier_id?: number | null;
    notes?: string;
    expense_date: string;
  }) =>
    request<{ id: number }>('/api/admin/expenses', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  deleteExpense: (id: number) =>
    request<{ ok: boolean }>(`/api/admin/expenses/${id}`, { method: 'DELETE' }),
  createIncome: (payload: {
    title: string;
    amount_piasters: number;
    payment_method: string;
    record_date: string;
    notes?: string;
  }) =>
    request<{ id: number }>('/api/admin/income', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getSuppliersData: () =>
    request<{
      suppliers: Array<
        Supplier & {
          purchases_count: number;
          total_purchased_piasters: number;
          unpaid_piasters: number;
        }
      >;
      purchases: Array<{
        id: number;
        supplier_id: number;
        supplier_name: string;
        supplier_code: string;
        invoice_number: string;
        purchase_date: string;
        subtotal_piasters: number;
        shipping_cost_piasters: number;
        total_piasters: number;
        paid_piasters: number;
        status: string;
        notes: string;
        items: Array<{
          id: number;
          product_name_ar: string;
          quantity_units: number;
          unit_weight_grams: number;
          unit_cost_piasters: number;
          line_total_piasters: number;
        }>;
      }>;
      prices: SupplierPriceRecord[];
    }>('/api/admin/suppliers'),
  createSupplier: (payload: {
    name: string;
    phone?: string;
    address?: string;
    city?: string;
    notes?: string;
  }) =>
    request<{ id: number }>('/api/admin/suppliers', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  logSupplierPrice: (payload: {
    supplier_id: number;
    product_id: number;
    unit_weight_grams: number;
    cost_piasters: number;
    recorded_date: string;
    source_note: string;
    update_product_cost: boolean;
  }) =>
    request<{ id: number }>('/api/admin/supplier-prices', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  createSupplierPurchase: (payload: {
    supplier_id: number;
    invoice_number?: string;
    purchase_date: string;
    shipping_cost_piasters: number;
    paid_piasters: number;
    notes?: string;
    items: Array<{
      product_id: number;
      quantity_units: number;
      unit_weight_grams: number;
      unit_cost_piasters: number;
    }>;
  }) =>
    request<{ id: number }>('/api/admin/supplier-purchases', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  paySupplierPurchase: (id: number, amount_piasters: number) =>
    request<{ ok: boolean }>(`/api/admin/supplier-purchases/${id}/pay`, {
      method: 'POST',
      body: JSON.stringify({ amount_piasters }),
    }),

  getSettings: () =>
    request<{
      settings: Record<string, string>;
      demoCounts: { orders: number; expenses: number; purchases: number };
    }>('/api/admin/settings'),
  updateSettings: (payload: {
    store_name_ar: string;
    store_name_en: string;
    whatsapp_number: string;
    store_phone: string;
    store_address: string;
    default_delivery_fee_piasters: number;
    free_delivery_threshold_piasters: number;
  }) =>
    request<{ ok: boolean }>('/api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  clearDemoData: () => request<{ ok: boolean }>('/api/admin/clear-demo', { method: 'POST' }),
};
