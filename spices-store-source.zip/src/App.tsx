import { useEffect, useState } from 'react';
import { api } from './lib/api';
import type { Language } from './shared/types';
import { Storefront } from './components/store/Storefront';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminDashboard } from './components/admin/AdminDashboard';

function isAdminUrl(): boolean {
  return (
    window.location.pathname.startsWith('/admin') ||
    window.location.hash.startsWith('#/admin')
  );
}

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [route, setRoute] = useState<'store' | 'admin'>(() =>
    isAdminUrl() ? 'admin' : 'store'
  );
  const [adminUser, setAdminUser] = useState<{
    id: number;
    name: string;
    email: string;
    role: string;
  } | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    const syncRoute = () => {
      setRoute(isAdminUrl() ? 'admin' : 'store');
    };
    window.addEventListener('popstate', syncRoute);
    window.addEventListener('hashchange', syncRoute);
    return () => {
      window.removeEventListener('popstate', syncRoute);
      window.removeEventListener('hashchange', syncRoute);
    };
  }, []);

  useEffect(() => {
    let active = true;
    api
      .getMe()
      .then((res) => {
        if (active) setAdminUser(res.user);
      })
      .catch(() => {
        if (active) setAdminUser(null);
      })
      .finally(() => {
        if (active) setCheckingAuth(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const navigateTo = (target: 'store' | 'admin') => {
    const nextPath = target === 'admin' ? '/admin' : '/';
    if (window.location.pathname !== nextPath || window.location.hash) {
      window.history.pushState({}, '', nextPath);
    }
    setRoute(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (route === 'admin') {
    if (checkingAuth) {
      return (
        <div className="min-h-screen bg-[#FAF7F2] flex items-center justify-center text-sm font-bold text-[#4E3119]">
          جاري التحقق من جلسة الإدارة...
        </div>
      );
    }

    if (!adminUser) {
      return (
        <AdminLogin
          onSuccess={(u) => setAdminUser(u)}
          onBackToStore={() => navigateTo('store')}
        />
      );
    }

    return (
      <AdminDashboard
        user={adminUser}
        onLogout={() => {
          setAdminUser(null);
          navigateTo('store');
        }}
        onBackToStore={() => navigateTo('store')}
      />
    );
  }

  return (
    <Storefront
      lang={lang}
      onToggleLang={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
    />
  );
}
