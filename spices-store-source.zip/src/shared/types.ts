export type Language = 'ar' | 'en';

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export type PaymentMethod = 'cod' | 'instapay' | 'vodafone_cash' | 'bank_transfer';

export type PaymentStatus = 'unpaid' | 'partial' | 'paid';

export type ExpenseCategory =
  | 'inventory_purchase'
  | 'packaging'
  | 'delivery_shipping'
  | 'marketing'
  | 'rent_utilities'
  | 'salaries'
  | 'other';

export interface WeightOption {
  grams: number;
  multiplier: number; // relative to base 125g unit
  labelAr: string;
  labelEn: string;
}

export const WEIGHT_OPTIONS: WeightOption[] = [
  { grams: 125, multiplier: 1, labelAr: '125 جم (تمن كيلو)', labelEn: '125g (1/8 kg)' },
  { grams: 250, multiplier: 2, labelAr: '250 جم (ربع كيلو)', labelEn: '250g (1/4 kg)' },
  { grams: 500, multiplier: 4, labelAr: '500 جم (نص كيلو)', labelEn: '500g (1/2 kg)' },
  { grams: 1000, multiplier: 8, labelAr: '1 كجم (كيلو كامل)', labelEn: '1 kg' },
];

export interface Category {
  id: number;
  slug: string;
  name_ar: string;
  name_en: string;
  description_ar: string;
  sort_order: number;
  is_active: number;
}

export interface ProductImage {
  id: number;
  product_id: number;
  image_url: string;
  alt_text: string;
  is_primary: number;
  sort_order: number;
}

export interface Product {
  id: number;
  sku: string;
  slug: string;
  name_ar: string;
  name_en: string;
  category_id: number;
  category_name_ar?: string;
  category_name_en?: string;
  description_ar: string;
  description_en: string;
  unit_label_ar: string;
  base_weight_grams: number;
  selling_price_piasters: number;
  cost_price_piasters: number;
  stock_units: number; // in 125g base units
  low_stock_threshold: number;
  is_active: number;
  is_featured: number;
  is_new: number;
  primary_image?: string | null;
  images?: ProductImage[];
  created_at: string;
  updated_at: string;
}

export interface CartItem {
  productId: number;
  sku: string;
  nameAr: string;
  nameEn: string;
  imageUrl: string | null;
  weightGrams: number;
  variantLabelAr: string;
  variantLabelEn: string;
  unitPricePiasters: number;
  quantity: number;
  baseMultiplier: number; // number of 125g units per 1 item
}

export interface StorePublicConfig {
  store_name_ar: string;
  store_name_en: string;
  whatsapp_number: string;
  store_phone: string;
  store_address: string;
  default_delivery_fee_piasters: number;
  free_delivery_threshold_piasters: number;
}

export interface OrderItemRecord {
  id: number;
  order_id: number;
  product_id: number | null;
  product_name_ar: string;
  variant_label_ar: string;
  weight_grams: number;
  quantity: number;
  unit_price_piasters: number;
  unit_cost_piasters: number;
  line_total_piasters: number;
  line_cost_piasters: number;
}

export interface OrderRecord {
  id: number;
  order_number: string;
  tracking_code: string;
  customer_id: number | null;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  delivery_area: string;
  delivery_notes: string;
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_status: PaymentStatus;
  subtotal_piasters: number;
  delivery_fee_piasters: number;
  delivery_actual_cost_piasters: number;
  discount_piasters: number;
  total_piasters: number;
  total_cost_piasters: number;
  paid_piasters: number;
  is_demo: number;
  created_at: string;
  updated_at: string;
  items?: OrderItemRecord[];
}

export interface Supplier {
  id: number;
  name: string;
  code: string;
  phone: string;
  address: string;
  city: string;
  notes: string;
  is_active: number;
  created_at: string;
}

export interface SupplierPriceRecord {
  id: number;
  supplier_id: number;
  supplier_name?: string;
  supplier_code?: string;
  product_id: number;
  product_name_ar?: string;
  selling_price_piasters?: number;
  current_cost_piasters?: number;
  unit_weight_grams: number;
  cost_piasters: number;
  previous_cost_piasters?: number | null;
  recorded_date: string;
  source_note: string;
  created_at: string;
}

export interface ExpenseRecord {
  id: number;
  category: ExpenseCategory;
  title: string;
  amount_piasters: number;
  payment_method: string;
  supplier_id: number | null;
  supplier_name?: string | null;
  notes: string;
  expense_date: string;
  is_demo: number;
  created_at: string;
}

export interface FinancialRecord {
  id: number;
  record_type: 'inflow' | 'outflow';
  source_type: 'order_payment' | 'expense' | 'supplier_payment' | 'manual_income';
  source_id: number | null;
  title: string;
  amount_piasters: number;
  payment_method: string;
  record_date: string;
  notes: string;
  is_demo: number;
  created_at: string;
}

export interface DashboardSummary {
  periods: {
    today: PeriodMetrics;
    week: PeriodMetrics;
    month: PeriodMetrics;
    year: PeriodMetrics;
    all_time: PeriodMetrics;
  };
  prevMonthComparison: {
    revenueDeltaPct: number | null;
    profitDeltaPct: number | null;
    ordersDeltaPct: number | null;
  };
  outstandingReceivablesPiasters: number;
  supplierPayablesPiasters: number;
  cashBalancePiasters: number;
  inventoryValuationCostPiasters: number;
  inventoryValuationRetailPiasters: number;
  lowStockProducts: Product[];
  recentOrders: OrderRecord[];
  dailySeries: Array<{
    date: string;
    revenuePiasters: number;
    costPiasters: number;
    expensesPiasters: number;
    netProfitPiasters: number;
    ordersCount: number;
  }>;
  alerts: Array<{
    level: 'warning' | 'info' | 'danger';
    titleAr: string;
    detailAr: string;
    actionTab?: string;
  }>;
}

export interface PeriodMetrics {
  ordersCount: number;
  completedOrdersCount: number;
  cancelledOrdersCount: number;
  revenuePiasters: number; // delivered / active sales excluding cancelled
  cogsPiasters: number; // actual recorded product cost + actual delivery cost
  grossProfitPiasters: number; // revenue - cogs
  operatingExpensesPiasters: number;
  netProfitPiasters: number; // grossProfit - operatingExpenses
  cashCollectedPiasters: number;
}

export function formatEGP(piasters: number, lang: Language = 'ar'): string {
  const value = (piasters || 0) / 100;
  const formatted = value.toLocaleString('en-US', {
    minimumFractionDigits: value % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });
  return lang === 'ar' ? `${formatted} ج.م` : `${formatted} EGP`;
}

export function toPiasters(egp: number): number {
  return Math.round((Number(egp) || 0) * 100);
}

export function fromPiasters(piasters: number): number {
  return Math.round(piasters || 0) / 100;
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, { ar: string; en: string; tone: string }> = {
  pending: { ar: 'قيد المراجعة', en: 'Pending', tone: 'amber' },
  confirmed: { ar: 'تم التأكيد', en: 'Confirmed', tone: 'blue' },
  preparing: { ar: 'جاري التجهيز والتعبئة', en: 'Preparing', tone: 'indigo' },
  out_for_delivery: { ar: 'خرج للتوصيل', en: 'Out for Delivery', tone: 'purple' },
  delivered: { ar: 'تم التسليم', en: 'Delivered', tone: 'green' },
  cancelled: { ar: 'ملغي', en: 'Cancelled', tone: 'red' },
};

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, { ar: string; en: string }> = {
  cod: { ar: 'الدفع عند الاستلام', en: 'Cash on Delivery' },
  instapay: { ar: 'إنستا باي (InstaPay)', en: 'InstaPay' },
  vodafone_cash: { ar: 'فودافون كاش', en: 'Vodafone Cash' },
  bank_transfer: { ar: 'تحويل بنكي', en: 'Bank Transfer' },
};

export const EXPENSE_CATEGORY_LABELS: Record<ExpenseCategory, { ar: string; en: string }> = {
  inventory_purchase: { ar: 'مشتريات بضاعة وموردين', en: 'Inventory Purchases' },
  packaging: { ar: 'أكياس وعبوات وتغليف', en: 'Packaging & Bags' },
  delivery_shipping: { ar: 'شحن ومندوب توصيل', en: 'Delivery & Shipping' },
  marketing: { ar: 'إعلانات وتسويق', en: 'Marketing & Ads' },
  rent_utilities: { ar: 'إيجار وكهرباء ومرافق', en: 'Rent & Utilities' },
  salaries: { ar: 'رواتب وعمالة', en: 'Salaries & Labor' },
  other: { ar: 'مصروفات تشغيلية أخرى', en: 'Other Expenses' },
};
